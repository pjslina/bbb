-- Initialize primary PostgreSQL database
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_logins (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    user_agent TEXT
);

-- Insert sample data
INSERT INTO users (username, email, status) VALUES
    ('alice', 'alice@example.com', 'active'),
    ('bob', 'bob@example.com', 'active'),
    ('charlie', 'charlie@example.com', 'inactive'),
    ('diana', 'diana@example.com', 'active'),
    ('eve', 'eve@example.com', 'active')
ON CONFLICT (username) DO NOTHING;

INSERT INTO user_logins (user_id, login_time, ip_address) VALUES
    (1, NOW() - INTERVAL '1 day', '192.168.1.1'),
    (1, NOW() - INTERVAL '2 days', '192.168.1.1'),
    (2, NOW() - INTERVAL '1 day', '192.168.1.2'),
    (3, NOW() - INTERVAL '3 days', '192.168.1.3'),
    (4, NOW() - INTERVAL '1 day', '192.168.1.4')
ON CONFLICT DO NOTHING;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);
CREATE INDEX IF NOT EXISTS idx_logins_user_id ON user_logins(user_id);
CREATE INDEX IF NOT EXISTS idx_logins_time ON user_logins(login_time);
