-- Initialize OpenGauss analytics database
CREATE TABLE IF NOT EXISTS retention_cohorts (
    id SERIAL PRIMARY KEY,
    cohort_date DATE NOT NULL,
    total_users INTEGER NOT NULL,
    day_1_retention DECIMAL(5,2),
    day_7_retention DECIMAL(5,2),
    day_30_retention DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample analytics data
INSERT INTO retention_cohorts (cohort_date, total_users, day_1_retention, day_7_retention, day_30_retention) VALUES
    ('2024-01-01', 1000, 45.5, 30.2, 15.8),
    ('2024-01-08', 1200, 48.3, 32.1, 16.5),
    ('2024-01-15', 1100, 46.8, 31.5, 16.2),
    ('2024-01-22', 1300, 50.1, 33.8, 17.1),
    ('2024-01-29', 1250, 49.2, 33.0, 16.8)
ON CONFLICT DO NOTHING;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_cohorts_date ON retention_cohorts(cohort_date);
