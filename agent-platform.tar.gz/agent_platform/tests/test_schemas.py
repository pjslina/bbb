"""Tests for schema validation."""

import pytest
from pydantic import ValidationError

from app.models.schemas import (
    ChatMessage, MessageRole, IntentType, ChatRequest,
    SQLTemplate, ToolParameter,
)


class TestChatMessage:
    def test_create_message(self):
        msg = ChatMessage(role=MessageRole.USER, content="Hello")
        assert msg.role == MessageRole.USER
        assert msg.content == "Hello"

    def test_invalid_role(self):
        with pytest.raises(ValidationError):
            ChatMessage(role="invalid", content="test")


class TestChatRequest:
    def test_valid_request(self):
        req = ChatRequest(message="Hello")
        assert req.message == "Hello"
        assert req.stream is True
        assert req.session_id is not None

    def test_empty_message(self):
        with pytest.raises(ValidationError):
            ChatRequest(message="")

    def test_message_too_long(self):
        with pytest.raises(ValidationError):
            ChatRequest(message="x" * 10001)


class TestSQLTemplate:
    def test_valid_template(self):
        template = SQLTemplate(
            template_id="test.query",
            description="Test query",
            sql_pattern="SELECT * FROM users WHERE id = :user_id",
            parameters=[
                ToolParameter(name="user_id", type="integer", description="User ID", required=True),
            ],
            allowed_databases=["primary"],
        )
        assert template.template_id == "test.query"
        assert template.read_only is True

    def test_dangerous_sql_rejected(self):
        with pytest.raises(ValidationError):
            SQLTemplate(
                template_id="test.dangerous",
                description="Dangerous",
                sql_pattern="DROP TABLE users",
                parameters=[],
                allowed_databases=["primary"],
            )

    def test_multiple_statements_rejected(self):
        with pytest.raises(ValidationError):
            SQLTemplate(
                template_id="test.multi",
                description="Multi",
                sql_pattern="SELECT 1; DROP TABLE users",
                parameters=[],
                allowed_databases=["primary"],
            )
