"""Tests for database router."""

import pytest

from app.db.router import DatabaseRouter, QueryType


class TestDatabaseRouter:
    def setup_method(self):
        self.router = DatabaseRouter()

    def test_classify_select(self):
        query_type = self.router.classify_query("SELECT * FROM users")
        assert query_type == QueryType.READ

    def test_classify_insert(self):
        query_type = self.router.classify_query("INSERT INTO users VALUES (1)")
        assert query_type == QueryType.WRITE

    def test_classify_update(self):
        query_type = self.router.classify_query("UPDATE users SET name = 'test'")
        assert query_type == QueryType.WRITE

    def test_classify_delete(self):
        query_type = self.router.classify_query("DELETE FROM users WHERE id = 1")
        assert query_type == QueryType.WRITE

    def test_classify_with(self):
        query_type = self.router.classify_query("WITH cte AS (SELECT 1) SELECT * FROM cte")
        assert query_type == QueryType.READ

    def test_route_read_default(self):
        route = self.router.route(scenario="default", sql="SELECT * FROM users")
        assert route.read_only is True
        assert "read" in route.reason.lower()

    def test_route_write_forced_primary(self):
        route = self.router.route(scenario="default", sql="INSERT INTO users VALUES (1)")
        assert route.read_only is False
        assert route.pool_name == "primary"

    def test_register_scenario(self):
        self.router.register_scenario("custom", "opengauss")
        assert self.router.SCENARIO_MAP["custom"] == "opengauss"

    def test_get_routing_table(self):
        table = self.router.get_routing_table()
        assert "default" in table
        assert "user_data" in table
