"""Tests for SQL template registry."""

import pytest

from app.db.schemas import get_sql_registry, SQLTemplateRegistry
from app.models.schemas import SQLTemplate, ToolParameter


class TestSQLTemplateRegistry:
    def setup_method(self):
        self.registry = SQLTemplateRegistry()

    def test_get_existing_template(self):
        template = self.registry.get("user.get_by_id")
        assert template is not None
        assert template.template_id == "user.get_by_id"

    def test_get_nonexistent_template(self):
        template = self.registry.get("nonexistent")
        assert template is None

    def test_list_templates(self):
        templates = self.registry.list_templates()
        assert len(templates) > 0

    def test_get_for_database(self):
        templates = self.registry.get_for_database("primary")
        assert len(templates) > 0
        for t in templates:
            assert "primary" in t.allowed_databases

    def test_validate_parameters_valid(self):
        is_valid, error = self.registry.validate_parameters(
            "user.get_by_id",
            {"user_id": 123},
        )
        assert is_valid is True
        assert error == ""

    def test_validate_parameters_missing(self):
        is_valid, error = self.registry.validate_parameters(
            "user.get_by_id",
            {},
        )
        assert is_valid is False
        assert "Missing required" in error

    def test_validate_parameters_unknown_template(self):
        is_valid, error = self.registry.validate_parameters(
            "unknown",
            {},
        )
        assert is_valid is False
        assert "Unknown template" in error

    def test_render_template(self):
        sql, params = self.registry.render("user.get_by_id", {"user_id": 123})
        assert "SELECT" in sql
        assert "users" in sql
        assert params == (123,)
        assert "$1" in sql

    def test_render_with_default(self):
        sql, params = self.registry.render("user.list", {
            "status": "active",
            "limit": 10,
            "offset": 0,
        })
        assert "LIMIT" in sql
        assert 10 in params

    def test_render_adds_limit(self):
        sql, params = self.registry.render("user.search", {"search_term": "alice"})
        assert "LIMIT" in sql.upper()


class TestSQLTemplateSecurity:
    def test_no_raw_string_interpolation(self):
        """Verify that render uses parameter binding, not string formatting."""
        registry = SQLTemplateRegistry()
        sql, params = registry.render("user.search", {"search_term": "alice'; DROP TABLE users; --"})

        # The SQL should contain parameter placeholder, not the raw string
        assert "alice" not in sql
        assert "$1" in sql
        assert params[0] == "alice'; DROP TABLE users; --"
