"""Tests for agent guardrails."""

import time
import pytest

from app.agent.guardrails import Guardrails


class TestGuardrails:
    def setup_method(self):
        self.guardrails = Guardrails()

    def test_iteration_limit_pass(self):
        passed, error = self.guardrails.check_iteration_limit(5)
        assert passed is True
        assert error == ""

    def test_iteration_limit_fail(self):
        passed, error = self.guardrails.check_iteration_limit(10)
        assert passed is False
        assert "Maximum iterations" in error

    def test_tool_call_limit_pass(self):
        passed, error = self.guardrails.check_tool_call_limit(3)
        assert passed is True

    def test_tool_call_limit_fail(self):
        passed, error = self.guardrails.check_tool_call_limit(5)
        assert passed is False
        assert "Maximum tool calls" in error

    def test_token_budget_pass(self):
        passed, error = self.guardrails.check_token_budget(5000)
        assert passed is True

    def test_token_budget_fail(self):
        passed, error = self.guardrails.check_token_budget(8001)
        assert passed is False
        assert "Token budget" in error

    def test_timeout_pass(self):
        start = time.time()
        passed, error = self.guardrails.check_timeout(start)
        assert passed is True

    def test_timeout_fail(self):
        start = time.time() - 200
        passed, error = self.guardrails.check_timeout(start)
        assert passed is False
        assert "Timeout" in error

    def test_content_safety_pass(self):
        passed, error = self.guardrails.check_content_safety("SELECT * FROM users")
        assert passed is True

    def test_content_safety_fail(self):
        passed, error = self.guardrails.check_content_safety("DROP TABLE users")
        assert passed is False
        assert "dangerous" in error

    def test_validate_all_pass(self):
        state = {
            "session_id": "test",
            "current_iteration": 3,
            "tool_call_count": 2,
            "response_tokens": 1000,
        }
        passed, error = self.guardrails.validate_all(state, time.time())
        assert passed is True

    def test_validate_all_fail_iteration(self):
        state = {
            "session_id": "test",
            "current_iteration": 15,
            "tool_call_count": 0,
            "response_tokens": 0,
        }
        passed, error = self.guardrails.validate_all(state, time.time())
        assert passed is False
        assert "iterations" in error
