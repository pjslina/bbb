# Agent Platform

Production-grade single-agent AI platform with dual streaming support, multi-database capabilities, and comprehensive observability.

## Features

- **Dual Streaming**: SSE and WebSocket support for real-time communication
- **LangGraph Agent**: Stateful execution graph with observable nodes
- **Multi-Database**: PostgreSQL (primary/secondary) + OpenGauss with connection pooling
- **Safe SQL**: Template-based queries with parameter binding (LLM never writes raw SQL)
- **Memory Management**: Redis-based conversation history with automatic compression
- **Tool System**: Pluggable tools with schema validation and intelligent routing
- **LLM Fallback**: Primary (Qwen) → Secondary (GLM) with circuit breaker
- **Guardrails**: Max iterations, timeouts, tool call limits, token budgets
- **Observability**: Structured logging, OpenTelemetry tracing, health checks

## Quick Start

```bash
# 1. Configure environment
cp .env.example .env
# Edit .env with your LLM API keys

# 2. Start all services
docker-compose up -d

# 3. Verify health
curl http://localhost:8000/api/v1/health

# 4. Test chat
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "How many users are active?", "stream": false}'
```

## Architecture

See [docs/architecture.md](docs/architecture.md) for detailed architecture documentation.

## API Documentation

See [docs/api.md](docs/api.md) for complete API reference.

## Deployment

See [docs/deployment.md](docs/deployment.md) for production deployment guide.

## Project Structure

```
agent-platform/
├── app/
│   ├── core/           # Config, logging, tracing
│   ├── models/         # Pydantic schemas
│   ├── llm/            # LLM client with fallback
│   ├── memory/         # Redis storage, compression
│   ├── db/             # Connection pools, routing, SQL templates
│   ├── tools/          # Tool registry, router, implementations
│   ├── agent/          # LangGraph state, nodes, guardrails
│   ├── api/            # FastAPI routes, streaming
│   └── main.py         # Application entry point
├── deploy/             # Docker init scripts, Prometheus config
├── docs/               # Architecture, API, deployment docs
├── tests/              # Unit tests
├── config.yaml         # Application configuration
├── docker-compose.yml  # Full stack orchestration
├── Dockerfile          # Multi-stage build
├── requirements.txt    # Python dependencies
└── .env.example        # Environment template
```

## Tech Stack

- **Framework**: FastAPI + Uvicorn
- **Agent**: LangGraph (StateGraph)
- **LLM**: OpenAI-compatible API (Qwen / GLM)
- **Database**: asyncpg + SQLAlchemy (PostgreSQL, OpenGauss)
- **Cache**: Redis (aioredis)
- **Observability**: OpenTelemetry + structlog
- **Container**: Docker + Docker Compose

## Testing

```bash
# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=app --cov-report=html
```

## License

MIT
