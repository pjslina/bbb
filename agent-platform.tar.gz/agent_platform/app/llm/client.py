"""Unified LLM client with fallback support.

Supports Qwen, GLM, and any OpenAI-compatible API.
Implements retry logic, streaming, and circuit breaker pattern.
"""

import asyncio
from typing import AsyncIterator, Dict, List, Optional, Any, Union
from dataclasses import dataclass

import httpx
from openai import AsyncOpenAI, APIError, RateLimitError, APITimeoutError
from tenacity import (
    retry, stop_after_attempt, wait_exponential, 
    retry_if_exception_type, before_sleep_log
)

from app.core.config import settings, LLMConfig
from app.core.logger import get_logger
from app.core.trace import create_span

logger = get_logger(__name__)


@dataclass
class LLMResponse:
    """Standardized LLM response."""
    content: str
    model: str
    usage: Dict[str, int]
    finish_reason: str
    raw_response: Any = None


class CircuitBreaker:
    """Simple circuit breaker for LLM calls."""

    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 30):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failures = 0
        self.last_failure_time: Optional[float] = None
        self.state = "closed"  # closed, open, half-open

    def can_execute(self) -> bool:
        if self.state == "closed":
            return True
        if self.state == "open":
            if self.last_failure_time and (
                asyncio.get_event_loop().time() - self.last_failure_time > self.recovery_timeout
            ):
                self.state = "half-open"
                return True
            return False
        return True  # half-open

    def record_success(self):
        self.failures = 0
        self.state = "closed"

    def record_failure(self):
        self.failures += 1
        self.last_failure_time = asyncio.get_event_loop().time()
        if self.failures >= self.failure_threshold:
            self.state = "open"


class LLMClient:
    """Unified LLM client with primary/fallback support."""

    def __init__(self):
        self.primary_config = settings.llm_primary
        self.fallback_config = settings.llm_fallback

        self.primary_client = self._create_client(self.primary_config)
        self.fallback_client = self._create_client(self.fallback_config)

        self.primary_breaker = CircuitBreaker()
        self.fallback_breaker = CircuitBreaker()

        logger.info(
            "llm_client_initialized",
            primary_model=self.primary_config.model,
            fallback_model=self.fallback_config.model,
        )

    def _create_client(self, config: LLMConfig) -> AsyncOpenAI:
        """Create OpenAI-compatible client."""
        http_client = httpx.AsyncClient(
            timeout=config.timeout,
            limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
        )
        return AsyncOpenAI(
            base_url=config.base_url,
            api_key=config.api_key,
            http_client=http_client,
        )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((RateLimitError, APITimeoutError, APIError)),
        before_sleep=before_sleep_log(logger, "warning"),
    )
    async def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[str] = None,
        stream: bool = False,
    ) -> Union[LLMResponse, AsyncIterator[str]]:
        """Send chat completion request with fallback."""

        with create_span("llm.chat", {"model": model or self.primary_config.model}):
            # Try primary
            if self.primary_breaker.can_execute():
                try:
                    result = await self._chat_with_client(
                        self.primary_client,
                        self.primary_config,
                        messages,
                        model,
                        temperature,
                        max_tokens,
                        tools,
                        tool_choice,
                        stream,
                    )
                    self.primary_breaker.record_success()
                    return result
                except Exception as e:
                    self.primary_breaker.record_failure()
                    logger.warning(
                        "primary_llm_failed",
                        error=str(e),
                        model=self.primary_config.model,
                    )

            # Fallback
            if self.fallback_breaker.can_execute():
                logger.info("falling_back_to_secondary_llm", fallback_model=self.fallback_config.model)
                try:
                    result = await self._chat_with_client(
                        self.fallback_client,
                        self.fallback_config,
                        messages,
                        model,
                        temperature,
                        max_tokens,
                        tools,
                        tool_choice,
                        stream,
                    )
                    self.fallback_breaker.record_success()
                    return result
                except Exception as e:
                    self.fallback_breaker.record_failure()
                    logger.error("fallback_llm_failed", error=str(e))
                    raise

            raise RuntimeError("All LLM providers are unavailable")

    async def _chat_with_client(
        self,
        client: AsyncOpenAI,
        config: LLMConfig,
        messages: List[Dict[str, str]],
        model: Optional[str],
        temperature: Optional[float],
        max_tokens: Optional[int],
        tools: Optional[List[Dict]],
        tool_choice: Optional[str],
        stream: bool,
    ) -> Union[LLMResponse, AsyncIterator[str]]:
        """Execute chat with specific client."""

        request_params = {
            "model": model or config.model,
            "messages": messages,
            "temperature": temperature or config.temperature,
            "max_tokens": max_tokens or config.max_tokens,
            "stream": stream,
        }

        if tools:
            request_params["tools"] = tools
        if tool_choice:
            request_params["tool_choice"] = tool_choice

        if stream:
            return self._stream_response(client, request_params)

        response = await client.chat.completions.create(**request_params)

        return LLMResponse(
            content=response.choices[0].message.content or "",
            model=response.model,
            usage={
                "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                "total_tokens": response.usage.total_tokens if response.usage else 0,
            },
            finish_reason=response.choices[0].finish_reason or "stop",
            raw_response=response,
        )

    async def _stream_response(
        self,
        client: AsyncOpenAI,
        params: Dict[str, Any],
    ) -> AsyncIterator[str]:
        """Stream response chunks."""
        response = await client.chat.completions.create(**params)
        async for chunk in response:
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    async def close(self):
        """Close all clients."""
        await self.primary_client.close()
        await self.fallback_client.close()


# Singleton instance
_llm_client: Optional[LLMClient] = None


async def get_llm_client() -> LLMClient:
    """Get or create LLM client singleton."""
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client
