"""Pydantic models for API requests/responses and internal state.

All models use strict validation and clear documentation.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, field_validator


class MessageRole(str, Enum):
    """Message roles in conversation."""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class IntentType(str, Enum):
    """Recognized user intents."""
    GENERAL_QUERY = "general_query"
    DATA_QUERY = "data_query"
    API_CALL = "api_call"
    ANALYSIS = "analysis"
    CLARIFICATION = "clarification"
    GREETING = "greeting"
    UNKNOWN = "unknown"


class ToolType(str, Enum):
    """Tool categories."""
    DATABASE = "database"
    API = "api"
    CALCULATION = "calculation"
    SEARCH = "search"


class ChatMessage(BaseModel):
    """Single chat message."""
    role: MessageRole
    content: str
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ConversationState(BaseModel):
    """Conversation state for LangGraph."""
    session_id: str
    messages: List[ChatMessage] = Field(default_factory=list)
    intent: Optional[IntentType] = None
    selected_tools: List[str] = Field(default_factory=list)
    tool_results: List[Dict[str, Any]] = Field(default_factory=list)
    current_iteration: int = 0
    tool_call_count: int = 0
    response: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None
    finished: bool = False


class ToolParameter(BaseModel):
    """Tool parameter schema."""
    name: str
    type: str
    description: str
    required: bool = True
    default: Optional[Any] = None
    enum: Optional[List[Any]] = None


class ToolSchema(BaseModel):
    """Tool definition schema."""
    name: str
    description: str
    type: ToolType
    parameters: List[ToolParameter] = Field(default_factory=list)
    timeout: int = 30
    retry_count: int = 2
    enabled: bool = True


class ToolRequest(BaseModel):
    """Tool execution request."""
    tool_name: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    request_id: str = Field(default_factory=lambda: str(uuid4()))


class ToolResponse(BaseModel):
    """Tool execution response."""
    request_id: str
    tool_name: str
    success: bool
    data: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    metadata: Dict[str, Any] = Field(default_factory=dict)


class StreamingEvent(BaseModel):
    """SSE/WebSocket streaming event."""
    event_type: str  # "start", "intent", "tool_call", "tool_result", "thinking", "chunk", "complete", "error"
    data: Any
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    node: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ChatRequest(BaseModel):
    """Chat API request."""
    session_id: Optional[str] = None
    message: str = Field(..., min_length=1, max_length=10000)
    context: Optional[Dict[str, Any]] = None
    stream: bool = True

    @field_validator("session_id", mode="before")
    @classmethod
    def validate_session_id(cls, v):
        if v is None:
            return str(uuid4())
        return v


class ChatResponse(BaseModel):
    """Chat API response."""
    session_id: str
    message: str
    intent: Optional[IntentType] = None
    tools_used: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tokens_used: int = 0
    execution_time_ms: float = 0.0


class HealthStatus(BaseModel):
    """Health check response."""
    status: str
    version: str
    components: Dict[str, str] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class SQLTemplate(BaseModel):
    """Safe SQL template definition.

    LLM never constructs raw SQL. It selects from predefined templates
    and provides parameters that are safely bound.
    """
    template_id: str
    description: str
    sql_pattern: str
    parameters: List[ToolParameter]
    allowed_databases: List[str]
    max_rows: int = 1000
    read_only: bool = True

    @field_validator("sql_pattern")
    @classmethod
    def validate_sql_pattern(cls, v: str) -> str:
        """Ensure SQL pattern uses parameterized placeholders."""
        # Only allow named parameters like :param_name
        import re
        # Check for dangerous patterns
        dangerous = [
            r";\s*\w+",  # Multiple statements
            r"DROP\s+",
            r"DELETE\s+FROM\s+\w+\s*$",  # Unqualified DELETE
            r"UPDATE\s+\w+\s+SET",  # UPDATE without WHERE check
        ]
        for pattern in dangerous:
            if re.search(pattern, v, re.IGNORECASE):
                raise ValueError(f"SQL pattern contains dangerous construct: {pattern}")
        return v


class DatabaseRoute(BaseModel):
    """Database routing decision."""
    pool_name: str
    reason: str
    read_only: bool = True


class SessionSummary(BaseModel):
    """Compressed session summary."""
    session_id: str
    summary: str
    key_points: List[str] = Field(default_factory=list)
    message_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
