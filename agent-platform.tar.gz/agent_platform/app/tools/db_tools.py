"""Database tools.

Tools for executing safe SQL templates.
LLM never writes raw SQL - it selects templates and provides parameters.
"""

from typing import Any, Dict, Optional

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.db.manager import get_db_manager, DatabaseManager
from app.models.schemas import ToolSchema, ToolParameter, ToolType

logger = get_logger(__name__)


async def db_query(template_id: str, params: Dict[str, Any], scenario: str = "default") -> Dict[str, Any]:
    """Execute a predefined SQL query template.

    Args:
        template_id: Registered SQL template ID
        params: Template parameters
        scenario: Database routing scenario
    """
    with create_span("tool.db_query", {"template": template_id, "scenario": scenario}):
        manager = await get_db_manager()
        return await manager.execute_template(template_id, params, scenario)


async def db_analytics(
    template_id: str,
    params: Dict[str, Any],
    scenario: str = "analytics",
) -> Dict[str, Any]:
    """Execute analytics query on OpenGauss.

    Args:
        template_id: Analytics SQL template ID
        params: Template parameters
        scenario: Database routing scenario (default: analytics)
    """
    with create_span("tool.db_analytics", {"template": template_id}):
        manager = await get_db_manager()
        return await manager.execute_template(template_id, params, scenario)


async def list_templates(database: Optional[str] = None) -> Dict[str, Any]:
    """List available SQL templates.

    Args:
        database: Filter by database name
    """
    with create_span("tool.list_templates"):
        manager = await get_db_manager()
        templates = await manager.list_templates(database)
        return {
            "templates": templates,
            "count": len(templates),
        }


# Tool schemas
DB_QUERY_TOOL = ToolSchema(
    name="db_query",
    description="Execute a predefined SQL query template. Use this for all database queries. "
                "First call list_templates to see available templates, then call db_query with template_id and parameters.",
    type=ToolType.DATABASE,
    parameters=[
        ToolParameter(name="template_id", type="string", description="SQL template ID (e.g., 'user.get_by_id')", required=True),
        ToolParameter(name="params", type="object", description="Template parameters as JSON object", required=True),
        ToolParameter(name="scenario", type="string", description="Routing scenario", required=False, default="default"),
    ],
    timeout=30,
)

DB_ANALYTICS_TOOL = ToolSchema(
    name="db_analytics",
    description="Execute analytics queries on the analytics database (OpenGauss). "
                "Use for reporting, cohort analysis, and business intelligence.",
    type=ToolType.DATABASE,
    parameters=[
        ToolParameter(name="template_id", type="string", description="Analytics template ID", required=True),
        ToolParameter(name="params", type="object", description="Template parameters", required=True),
        ToolParameter(name="scenario", type="string", description="Routing scenario", required=False, default="analytics"),
    ],
    timeout=30,
)

LIST_TEMPLATES_TOOL = ToolSchema(
    name="list_templates",
    description="List all available SQL query templates",
    type=ToolType.DATABASE,
    parameters=[
        ToolParameter(name="database", type="string", description="Filter by database name", required=False),
    ],
    timeout=5,
)
