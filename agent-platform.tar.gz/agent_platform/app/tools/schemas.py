"""Tool schema definitions and validation.

Tools are defined with JSON Schema-compatible parameter definitions.
LLM receives tool schemas and decides which tools to call.
"""

from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field

from app.models.schemas import ToolSchema, ToolParameter, ToolType


@dataclass
class ToolDefinition:
    """Complete tool definition with execution function."""
    schema: ToolSchema
    handler: Callable[..., Any]
    metadata: Dict[str, Any] = field(default_factory=dict)


class ToolSchemaBuilder:
    """Builder for creating tool schemas programmatically."""

    @staticmethod
    def build_openai_tool(schema: ToolSchema) -> Dict[str, Any]:
        """Convert ToolSchema to OpenAI function calling format."""
        properties = {}
        required = []

        for param in schema.parameters:
            prop = {
                "type": param.type,
                "description": param.description,
            }
            if param.enum:
                prop["enum"] = param.enum
            properties[param.name] = prop

            if param.required:
                required.append(param.name)

        return {
            "type": "function",
            "function": {
                "name": schema.name,
                "description": schema.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        }

    @staticmethod
    def build_langchain_tool(schema: ToolSchema) -> Dict[str, Any]:
        """Convert ToolSchema to LangChain tool format."""
        return {
            "name": schema.name,
            "description": schema.description,
            "args_schema": {
                "title": schema.name,
                "type": "object",
                "properties": {
                    p.name: {
                        "type": p.type,
                        "description": p.description,
                    }
                    for p in schema.parameters
                },
                "required": [p.name for p in schema.parameters if p.required],
            },
        }
