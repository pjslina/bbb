"""Tool router - intelligent tool selection.

Uses LLM to decide which tools to call based on user intent,
or routes directly based on intent classification.
"""

import json
from typing import Any, Dict, List, Optional

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.llm.client import get_llm_client
from app.models.schemas import IntentType
from app.tools.registry import get_tool_registry, ToolRegistry

logger = get_logger(__name__)


class ToolRouter:
    """Routes requests to appropriate tools based on intent and context."""

    def __init__(self):
        self._registry: Optional[ToolRegistry] = None

    def _get_registry(self) -> ToolRegistry:
        if self._registry is None:
            self._registry = get_tool_registry()
        return self._registry

    async def select_tools(
        self,
        intent: IntentType,
        user_message: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[str]:
        """Select tools based on intent.

        Uses a hybrid approach:
        1. Intent-based pre-filtering
        2. LLM-based tool selection for ambiguous cases
        """
        with create_span("tool_router.select", {"intent": intent.value}):
            registry = self._get_registry()

            # Intent-based routing
            intent_tool_map = {
                IntentType.DATA_QUERY: ["db_query", "db_analytics"],
                IntentType.API_CALL: ["api_call"],
                IntentType.ANALYSIS: ["db_analytics", "db_query"],
                IntentType.GENERAL_QUERY: [],
                IntentType.GREETING: [],
                IntentType.CLARIFICATION: [],
                IntentType.UNKNOWN: [],
            }

            candidate_tools = intent_tool_map.get(intent, [])

            # Filter to only enabled tools that exist
            available = []
            for tool_name in candidate_tools:
                if registry.get(tool_name) and registry.is_enabled(tool_name):
                    available.append(tool_name)

            # For data queries, use LLM to select specific template
            if intent == IntentType.DATA_QUERY and available:
                selected = await self._llm_select_template(user_message, context)
                if selected:
                    return [selected]

            logger.info(
                "tools_selected",
                intent=intent.value,
                tools=available,
            )

            return available

    async def _llm_select_template(
        self,
        user_message: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """Use LLM to select the most appropriate SQL template."""
        try:
            from app.db.schemas import get_sql_registry

            registry = get_sql_registry()
            templates = registry.list_templates()

            if not templates:
                return None

            # Build selection prompt
            template_descriptions = []
            for t in templates:
                params = ", ".join([f"{p.name}({p.type})" for p in t.parameters])
                template_descriptions.append(
                    f"- {t.template_id}: {t.description} [params: {params}]"
                )

            prompt = f"""根据用户请求，选择最合适的SQL模板ID。只返回模板ID，不要解释。

可用模板：
{chr(10).join(template_descriptions)}

用户请求：{user_message}

最合适的模板ID是："""

            client = await get_llm_client()
            response = await client.chat(
                messages=[
                    {"role": "system", "content": "你是一个数据库查询路由助手。只返回模板ID。"},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=50,
                temperature=0.1,
            )

            template_id = response.content.strip().split()[0] if hasattr(response, 'content') else str(response).strip().split()[0]

            # Validate
            if registry.get(template_id):
                logger.info("llm_selected_template", template=template_id)
                return template_id

            return None

        except Exception as e:
            logger.warning("llm_template_selection_failed", error=str(e))
            return None

    async def route_and_execute(
        self,
        tool_name: str,
        params: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Route tool call to appropriate handler and execute."""
        with create_span("tool_router.execute", {"tool": tool_name}):
            registry = self._get_registry()
            return await registry.execute(tool_name, params)


# Singleton
_router_instance: Optional[ToolRouter] = None


def get_tool_router() -> ToolRouter:
    """Get tool router singleton."""
    global _router_instance
    if _router_instance is None:
        _router_instance = ToolRouter()
    return _router_instance
