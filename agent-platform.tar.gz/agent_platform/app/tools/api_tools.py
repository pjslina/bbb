"""API-based tools.

Tools that call external HTTP APIs.
All API calls are async with timeout and retry.
"""

import asyncio
from typing import Any, Dict, Optional

import httpx

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.models.schemas import ToolSchema, ToolParameter, ToolType

logger = get_logger(__name__)


class APIToolClient:
    """HTTP client for API tools."""

    def __init__(self):
        self.client = httpx.AsyncClient(
            timeout=30,
            limits=httpx.Limits(max_connections=50, max_keepalive_connections=20),
        )

    async def close(self):
        await self.client.aclose()

    async def get(self, url: str, headers: Optional[Dict] = None, params: Optional[Dict] = None) -> Dict:
        """HTTP GET request."""
        with create_span("api.get", {"url": url}):
            response = await self.client.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response.json()

    async def post(self, url: str, headers: Optional[Dict] = None, json_data: Optional[Dict] = None) -> Dict:
        """HTTP POST request."""
        with create_span("api.post", {"url": url}):
            response = await self.client.post(url, headers=headers, json=json_data)
            response.raise_for_status()
            return response.json()


_api_client: Optional[APIToolClient] = None


async def get_api_client() -> APIToolClient:
    """Get API client singleton."""
    global _api_client
    if _api_client is None:
        _api_client = APIToolClient()
    return _api_client


# Tool implementations

async def weather_query(city: str, days: int = 1) -> Dict[str, Any]:
    """Query weather information for a city.

    This is a mock implementation. In production, replace with real weather API.
    """
    with create_span("tool.weather", {"city": city}):
        # Mock response for demonstration
        await asyncio.sleep(0.1)
        return {
            "city": city,
            "days": days,
            "forecast": [
                {"date": "2024-01-01", "temp": 22, "condition": "Sunny"},
            ],
            "source": "mock",
        }


async def search_knowledge(query: str, limit: int = 5) -> Dict[str, Any]:
    """Search knowledge base.

    Mock implementation for demonstration.
    """
    with create_span("tool.search", {"query": query}):
        await asyncio.sleep(0.1)
        return {
            "query": query,
            "results": [
                {"title": f"Result {i}", "snippet": f"Snippet for {query}"}
                for i in range(limit)
            ],
            "total": limit,
        }


async def calculator(expression: str) -> Dict[str, Any]:
    """Evaluate mathematical expression safely.

    Uses eval with restricted globals for safety.
    """
    with create_span("tool.calculator", {"expr": expression}):
        try:
            # Safe eval with restricted builtins
            allowed_names = {
                "abs": abs, "round": round, "max": max, "min": min,
                "sum": sum, "pow": pow, "len": len,
            }
            result = eval(expression, {"__builtins__": {}}, allowed_names)
            return {
                "expression": expression,
                "result": result,
            }
        except Exception as e:
            return {
                "expression": expression,
                "error": str(e),
            }


# Tool schemas for registration
WEATHER_TOOL = ToolSchema(
    name="weather_query",
    description="Get weather information for a specified city",
    type=ToolType.API,
    parameters=[
        ToolParameter(name="city", type="string", description="City name", required=True),
        ToolParameter(name="days", type="integer", description="Number of forecast days", required=False, default=1),
    ],
    timeout=10,
)

SEARCH_TOOL = ToolSchema(
    name="search_knowledge",
    description="Search the knowledge base for relevant information",
    type=ToolType.API,
    parameters=[
        ToolParameter(name="query", type="string", description="Search query", required=True),
        ToolParameter(name="limit", type="integer", description="Max results", required=False, default=5),
    ],
    timeout=10,
)

CALCULATOR_TOOL = ToolSchema(
    name="calculator",
    description="Evaluate mathematical expressions",
    type=ToolType.CALCULATION,
    parameters=[
        ToolParameter(name="expression", type="string", description="Math expression to evaluate", required=True),
    ],
    timeout=5,
)
