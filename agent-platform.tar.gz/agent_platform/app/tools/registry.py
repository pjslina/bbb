"""Tool registry - central repository for all available tools.

Tools are registered at startup and can be dynamically added.
Supports hot-reloading and version management.
"""

import asyncio
import time
from typing import Any, Callable, Dict, List, Optional

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.models.schemas import ToolSchema, ToolType
from app.tools.schemas import ToolDefinition, ToolSchemaBuilder

logger = get_logger(__name__)


class ToolRegistry:
    """Central tool registry with lifecycle management."""

    def __init__(self):
        self._tools: Dict[str, ToolDefinition] = {}
        self._schemas: Dict[str, Dict[str, Any]] = {}
        self._enabled: Dict[str, bool] = {}
        self._call_counts: Dict[str, int] = {}
        self._max_concurrent = settings.tools.max_concurrent if hasattr(settings.tools, 'max_concurrent') else 10
        self._semaphore = asyncio.Semaphore(self._max_concurrent)

    def register(
        self,
        schema: ToolSchema,
        handler: Callable[..., Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Register a new tool."""
        with create_span("tool.register", {"tool": schema.name}):
            if schema.name in self._tools:
                logger.warning("tool_overwrite", tool=schema.name)

            self._tools[schema.name] = ToolDefinition(
                schema=schema,
                handler=handler,
                metadata=metadata or {},
            )
            self._schemas[schema.name] = ToolSchemaBuilder.build_openai_tool(schema)
            self._enabled[schema.name] = schema.enabled
            self._call_counts[schema.name] = 0

            logger.info(
                "tool_registered",
                tool=schema.name,
                type=schema.type.value,
                params=len(schema.parameters),
            )

    def unregister(self, name: str) -> None:
        """Unregister a tool."""
        if name in self._tools:
            del self._tools[name]
            del self._schemas[name]
            del self._enabled[name]
            del self._call_counts[name]
            logger.info("tool_unregistered", tool=name)

    def get(self, name: str) -> Optional[ToolDefinition]:
        """Get tool definition."""
        return self._tools.get(name)

    def get_schema(self, name: str) -> Optional[Dict[str, Any]]:
        """Get OpenAI-format tool schema."""
        return self._schemas.get(name)

    def list_tools(self, enabled_only: bool = True) -> List[str]:
        """List all registered tool names."""
        if enabled_only:
            return [name for name, tool in self._tools.items() if self._enabled.get(name, False)]
        return list(self._tools.keys())

    def list_schemas(self, enabled_only: bool = True) -> List[Dict[str, Any]]:
        """List all tool schemas in OpenAI format."""
        tools = []
        for name, schema in self._schemas.items():
            if not enabled_only or self._enabled.get(name, False):
                tools.append(schema)
        return tools

    def get_by_type(self, tool_type: ToolType) -> List[ToolDefinition]:
        """Get tools by type."""
        return [
            tool for tool in self._tools.values()
            if tool.schema.type == tool_type and self._enabled.get(tool.schema.name, False)
        ]

    def is_enabled(self, name: str) -> bool:
        """Check if tool is enabled."""
        return self._enabled.get(name, False)

    def enable(self, name: str) -> None:
        """Enable a tool."""
        if name in self._enabled:
            self._enabled[name] = True
            logger.info("tool_enabled", tool=name)

    def disable(self, name: str) -> None:
        """Disable a tool."""
        if name in self._enabled:
            self._enabled[name] = False
            logger.info("tool_disabled", tool=name)

    async def execute(self, name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool with concurrency control."""
        tool = self.get(name)
        if not tool:
            return {
                "success": False,
                "error": f"Tool not found: {name}",
            }

        if not self.is_enabled(name):
            return {
                "success": False,
                "error": f"Tool is disabled: {name}",
            }

        async with self._semaphore:
            with create_span("tool.execute", {"tool": name}):
                start_time = time.time()
                self._call_counts[name] += 1

                try:
                    # Set timeout for tool execution
                    result = await asyncio.wait_for(
                        self._execute_handler(tool, params),
                        timeout=tool.schema.timeout,
                    )

                    execution_time = (time.time() - start_time) * 1000

                    logger.info(
                        "tool_executed",
                        tool=name,
                        duration_ms=round(execution_time, 2),
                    )

                    return {
                        "success": True,
                        "tool": name,
                        "data": result,
                        "execution_time_ms": round(execution_time, 2),
                    }

                except asyncio.TimeoutError:
                    logger.error("tool_timeout", tool=name, timeout=tool.schema.timeout)
                    return {
                        "success": False,
                        "error": f"Tool execution timed out after {tool.schema.timeout}s",
                    }
                except Exception as e:
                    logger.error("tool_execution_failed", tool=name, error=str(e))
                    return {
                        "success": False,
                        "error": str(e),
                    }

    async def _execute_handler(self, tool: ToolDefinition, params: Dict[str, Any]) -> Any:
        """Execute tool handler."""
        result = tool.handler(**params)
        if asyncio.iscoroutine(result):
            return await result
        return result

    def get_stats(self) -> Dict[str, Any]:
        """Get tool usage statistics."""
        return {
            "total_tools": len(self._tools),
            "enabled_tools": sum(1 for v in self._enabled.values() if v),
            "call_counts": dict(self._call_counts),
        }


# Singleton
_registry_instance: Optional[ToolRegistry] = None


def get_tool_registry() -> ToolRegistry:
    """Get tool registry singleton."""
    global _registry_instance
    if _registry_instance is None:
        _registry_instance = ToolRegistry()
    return _registry_instance
