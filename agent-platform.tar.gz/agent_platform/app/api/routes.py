"""FastAPI routes for agent API.

Provides REST endpoints for:
- Chat (SSE streaming)
- WebSocket chat
- Health checks
- Session management
- Tool management
"""

import asyncio
import time
import uuid
from typing import Any, Dict, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks, Depends
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.logger import get_logger, set_request_id
from app.core.trace import create_span
from app.models.schemas import ChatRequest, ChatResponse, HealthStatus, StreamingEvent
from app.memory.manager import get_memory_manager
from app.agent.graph import get_agent
from app.agent.state import create_initial_state
from app.agent.guardrails import get_guardrails, TimeoutExecutor
from app.tools.registry import get_tool_registry
from app.db.manager import get_db_manager
from app.api.streaming import (
    UnifiedStream,
    SSEStream,
    create_sse_response,
    WebSocketStream,
)

logger = get_logger(__name__)
router = APIRouter()


async def run_agent_with_streaming(
    session_id: str,
    user_message: str,
    stream: UnifiedStream,
    context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Run agent with streaming events.

    This is the core execution function that drives the state machine
    and emits events to the stream.
    """
    start_time = time.time()
    guardrails = get_guardrails()

    try:
        # Save user message to memory
        memory = await get_memory_manager()
        await memory.append_user_message(session_id, user_message)

        # Emit start event
        await stream.emit("start", {"session_id": session_id}, node="start")

        # Create initial state
        state = create_initial_state(session_id, user_message)
        state["metadata"] = context or {}
        state["max_iterations"] = settings.agent.max_iterations

        # Get compiled agent
        agent = get_agent()

        # Run agent with timeout
        executor = TimeoutExecutor(settings.agent.timeout)

        # Stream events from agent execution
        final_state = None
        async for event in agent.astream(state, config={"recursion_limit": settings.agent.max_iterations + 5}):
            node_name = list(event.keys())[0] if event else "unknown"
            node_state = event.get(node_name, {})

            # Emit node events
            stream_events = node_state.get("stream_events", [])
            for evt in stream_events:
                await stream.emit(
                    evt.get("event_type", "unknown"),
                    evt.get("data", {}),
                    node=node_name,
                )

            # Check for errors
            if node_state.get("error"):
                await stream.emit("error", {"message": node_state["error"]}, node=node_name)

            # Check guardrails
            passed, error = guardrails.validate_all(node_state, start_time)
            if not passed:
                await stream.emit("error", {"message": error, "type": "guardrail"}, node="guardrail")
                break

            final_state = node_state

        execution_time = (time.time() - start_time) * 1000

        # Build response
        response_text = final_state.get("response", "") if final_state else ""
        if not response_text and final_state and final_state.get("error"):
            response_text = f"执行出错: {final_state['error']}"
        elif not response_text:
            response_text = "抱歉，我暂时无法处理您的请求。"

        result = {
            "session_id": session_id,
            "response": response_text,
            "intent": final_state.get("intent", "unknown").value if final_state and final_state.get("intent") else None,
            "tools_used": final_state.get("selected_tools", []) if final_state else [],
            "execution_time_ms": round(execution_time, 2),
            "iterations": final_state.get("current_iteration", 0) if final_state else 0,
        }

        await stream.emit("complete", result, node="end")

        return result

    except asyncio.TimeoutError:
        logger.error("agent_timeout", session_id=session_id, timeout=settings.agent.timeout)
        await stream.emit("error", {
            "message": f"请求超时（{settings.agent.timeout}秒）",
            "type": "timeout",
        }, node="guardrail")
        return {
            "session_id": session_id,
            "response": "请求处理超时，请稍后重试或简化您的问题。",
            "error": "timeout",
        }
    except Exception as e:
        logger.error("agent_execution_failed", session_id=session_id, error=str(e))
        await stream.emit("error", {
            "message": str(e),
            "type": "execution_error",
        }, node="error")
        return {
            "session_id": session_id,
            "response": "抱歉，处理您的请求时发生错误。",
            "error": str(e),
        }


@router.post("/chat")
async def chat(request: ChatRequest, background_tasks: BackgroundTasks):
    """Chat endpoint with SSE streaming.

    Returns a streaming response with Server-Sent Events.
    Each event contains the execution state and final response.
    """
    request_id_val = str(uuid.uuid4())
    set_request_id(request_id_val)

    with create_span("api.chat", {"session": request.session_id}):
        logger.info(
            "chat_request",
            session_id=request.session_id,
            message_length=len(request.message),
            stream=request.stream,
        )

        if request.stream:
            # Create SSE stream
            unified_stream, sse_stream = UnifiedStream.create_sse()

            # Run agent in background
            async def run_and_close():
                try:
                    await run_agent_with_streaming(
                        request.session_id,
                        request.message,
                        unified_stream,
                        request.context,
                    )
                finally:
                    await unified_stream.close()

            # Start agent execution
            asyncio.create_task(run_and_close())

            return create_sse_response(sse_stream)
        else:
            # Non-streaming: run synchronously and return JSON
            unified_stream = UnifiedStream("memory")
            result = await run_agent_with_streaming(
                request.session_id,
                request.message,
                unified_stream,
                request.context,
            )

            return JSONResponse(content=result)


@router.websocket("/ws/chat")
async def websocket_chat(websocket: WebSocket):
    """WebSocket chat endpoint.

    Supports bidirectional communication with streaming events.
    """
    await websocket.accept()

    request_id_val = str(uuid.uuid4())
    set_request_id(request_id_val)

    with create_span("api.ws_chat"):
        logger.info("websocket_connected", client=websocket.client.host if websocket.client else "unknown")

        stream = UnifiedStream.create_websocket(websocket)

        try:
            while True:
                # Receive message
                data = await websocket.receive_json()

                session_id = data.get("session_id", str(uuid.uuid4()))
                message = data.get("message", "")
                context = data.get("context")

                if not message:
                    await stream.emit("error", {"message": "Message is required"})
                    continue

                # Run agent
                await run_agent_with_streaming(
                    session_id,
                    message,
                    stream,
                    context,
                )

        except WebSocketDisconnect:
            logger.info("websocket_disconnected")
        except Exception as e:
            logger.error("websocket_error", error=str(e))
            await stream.emit("error", {"message": str(e)})
        finally:
            await stream.close()


@router.get("/health")
async def health_check() -> HealthStatus:
    """Health check endpoint.

    Checks all critical components.
    """
    with create_span("api.health"):
        components = {}

        # Check database
        try:
            db_manager = await get_db_manager()
            db_health = await db_manager.health_check()
            for name, status in db_health.items():
                components[f"db_{name}"] = "healthy" if status else "unhealthy"
        except Exception as e:
            components["db"] = f"error: {str(e)}"

        # Check tools
        try:
            registry = get_tool_registry()
            stats = registry.get_stats()
            components["tools"] = f"{stats['enabled_tools']}/{stats['total_tools']} enabled"
        except Exception as e:
            components["tools"] = f"error: {str(e)}"

        # Overall status
        all_healthy = all("error" not in v and v != "unhealthy" for v in components.values())
        status = "healthy" if all_healthy else "degraded"

        return HealthStatus(
            status=status,
            version=settings.app_name,
            components=components,
        )


@router.delete("/sessions/{session_id}")
async def clear_session(session_id: str):
    """Clear a conversation session."""
    with create_span("api.clear_session", {"session": session_id}):
        memory = await get_memory_manager()
        await memory.clear_session(session_id)
        logger.info("session_cleared", session_id=session_id)
        return {"status": "success", "session_id": session_id}


@router.get("/sessions/{session_id}/stats")
async def session_stats(session_id: str):
    """Get session statistics."""
    with create_span("api.session_stats", {"session": session_id}):
        memory = await get_memory_manager()
        stats = await memory.get_session_stats(session_id)
        return stats


@router.get("/tools")
async def list_tools():
    """List all available tools."""
    with create_span("api.list_tools"):
        registry = get_tool_registry()
        return {
            "tools": registry.list_schemas(enabled_only=True),
            "stats": registry.get_stats(),
        }


@router.get("/templates")
async def list_sql_templates(database: Optional[str] = None):
    """List available SQL templates."""
    with create_span("api.list_templates"):
        db_manager = await get_db_manager()
        templates = await db_manager.list_templates(database)
        return {"templates": templates}
