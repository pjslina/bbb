"""API module - FastAPI routes and streaming."""
