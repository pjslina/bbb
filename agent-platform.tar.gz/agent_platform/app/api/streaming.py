"""Streaming support for SSE and WebSocket.

Unified streaming interface that supports both protocols
with consistent event formatting.
"""

import asyncio
import json
from typing import Any, AsyncIterator, Dict, Optional

from fastapi import WebSocket
from starlette.responses import StreamingResponse

from app.core.logger import get_logger
from app.core.trace import create_span
from app.models.schemas import StreamingEvent

logger = get_logger(__name__)


class StreamingAdapter:
    """Adapter for unified streaming across SSE and WebSocket."""

    @staticmethod
    def format_sse_event(event: Dict[str, Any]) -> str:
        """Format event as SSE data."""
        return f"data: {json.dumps(event, ensure_ascii=False, default=str)}\n\n"

    @staticmethod
    def format_ws_event(event: Dict[str, Any]) -> Dict[str, Any]:
        """Format event for WebSocket (already dict)."""
        return event


class SSEStream:
    """Server-Sent Events stream generator."""

    def __init__(self):
        self.queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue()
        self.closed = False

    async def send(self, event: Dict[str, Any]) -> None:
        """Send event to stream."""
        if not self.closed:
            await self.queue.put(event)

    async def close(self) -> None:
        """Close the stream."""
        self.closed = True
        await self.queue.put(None)  # Sentinel

    async def __aiter__(self) -> AsyncIterator[str]:
        """Async iterator for SSE response."""
        while True:
            try:
                event = await asyncio.wait_for(self.queue.get(), timeout=300)
                if event is None:  # Sentinel
                    break
                yield StreamingAdapter.format_sse_event(event)
            except asyncio.TimeoutError:
                yield StreamingAdapter.format_sse_event({
                    "event_type": "error",
                    "data": {"message": "Stream timeout"},
                })
                break


class WebSocketStream:
    """WebSocket stream wrapper."""

    def __init__(self, websocket: WebSocket):
        self.websocket = websocket
        self.closed = False

    async def send(self, event: Dict[str, Any]) -> None:
        """Send event via WebSocket."""
        if not self.closed:
            await self.websocket.send_json(event)

    async def close(self) -> None:
        """Close WebSocket connection."""
        self.closed = True
        await self.websocket.close()


class UnifiedStream:
    """Unified stream that works with both SSE and WebSocket."""

    def __init__(self, stream_type: str = "sse"):
        self.stream_type = stream_type
        self._sse_stream: Optional[SSEStream] = None
        self._ws_stream: Optional[WebSocketStream] = None
        self._events: list = []

    @classmethod
    def create_sse(cls) -> tuple["UnifiedStream", SSEStream]:
        """Create SSE stream pair."""
        stream = cls("sse")
        stream._sse_stream = SSEStream()
        return stream, stream._sse_stream

    @classmethod
    def create_websocket(cls, websocket: WebSocket) -> "UnifiedStream":
        """Create WebSocket stream."""
        stream = cls("websocket")
        stream._ws_stream = WebSocketStream(websocket)
        return stream

    async def emit(self, event_type: str, data: Any, node: Optional[str] = None) -> None:
        """Emit an event to the stream."""
        event = {
            "event_type": event_type,
            "data": data,
            "node": node,
            "timestamp": __import__("datetime").datetime.utcnow().isoformat(),
        }

        self._events.append(event)

        if self.stream_type == "sse" and self._sse_stream:
            await self._sse_stream.send(event)
        elif self.stream_type == "websocket" and self._ws_stream:
            await self._ws_stream.send(event)

    async def emit_chunk(self, content: str, node: Optional[str] = None) -> None:
        """Emit a content chunk (for streaming LLM output)."""
        await self.emit("chunk", {"content": content}, node)

    async def emit_error(self, message: str, node: Optional[str] = None) -> None:
        """Emit an error event."""
        await self.emit("error", {"message": message}, node)

    async def close(self) -> None:
        """Close the stream."""
        if self.stream_type == "sse" and self._sse_stream:
            await self._sse_stream.close()
        elif self.stream_type == "websocket" and self._ws_stream:
            await self._ws_stream.close()

    def get_events(self) -> list:
        """Get all emitted events."""
        return self._events


def create_sse_response(stream: SSEStream) -> StreamingResponse:
    """Create FastAPI StreamingResponse for SSE."""
    return StreamingResponse(
        stream,
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
