"""FastAPI application entry point.

Initializes all components and starts the server.
Supports graceful shutdown and lifecycle management.
"""

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from app.core.config import settings
from app.core.logger import setup_logging, get_logger
from app.core.trace import setup_tracing
from app.memory.redis_store import get_redis_store
from app.db.pool import get_pool_manager
from app.tools.registry import get_tool_registry
from app.tools.api_tools import (
    WEATHER_TOOL, SEARCH_TOOL, CALCULATOR_TOOL,
    weather_query, search_knowledge, calculator,
)
from app.tools.db_tools import (
    DB_QUERY_TOOL, DB_ANALYTICS_TOOL, LIST_TEMPLATES_TOOL,
    db_query, db_analytics, list_templates,
)
from app.api.routes import router

logger = get_logger(__name__)


async def initialize_tools():
    """Register all tools at startup."""
    registry = get_tool_registry()

    # Register API tools
    registry.register(WEATHER_TOOL, weather_query)
    registry.register(SEARCH_TOOL, search_knowledge)
    registry.register(CALCULATOR_TOOL, calculator)

    # Register DB tools
    registry.register(DB_QUERY_TOOL, db_query)
    registry.register(DB_ANALYTICS_TOOL, db_analytics)
    registry.register(LIST_TEMPLATES_TOOL, list_templates)

    logger.info(
        "tools_initialized",
        total=registry.get_stats()["total_tools"],
        enabled=registry.get_stats()["enabled_tools"],
    )


async def initialize_components():
    """Initialize all application components."""
    logger.info("initializing_components")

    # Setup logging
    setup_logging()

    # Setup tracing
    setup_tracing()

    # Initialize Redis
    redis_store = await get_redis_store()
    await redis_store.connect()

    # Initialize database pools
    pool_manager = await get_pool_manager()

    # Initialize tools
    await initialize_tools()

    logger.info("components_initialized")


async def shutdown_components():
    """Gracefully shutdown all components."""
    logger.info("shutting_down_components")

    # Close Redis
    try:
        redis_store = await get_redis_store()
        await redis_store.disconnect()
    except Exception as e:
        logger.error("redis_shutdown_error", error=str(e))

    # Close database pools
    try:
        pool_manager = await get_pool_manager()
        await pool_manager.close()
    except Exception as e:
        logger.error("db_shutdown_error", error=str(e))

    logger.info("components_shutdown_complete")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    await initialize_components()
    yield
    await shutdown_components()


def create_app() -> FastAPI:
    """Create and configure FastAPI application."""
    app = FastAPI(
        title=settings.app_name,
        description="Production-grade AI Agent Platform with dual streaming support",
        version="1.0.0",
        docs_url="/docs" if settings.debug else None,
        redoc_url="/redoc" if settings.debug else None,
        lifespan=lifespan,
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # GZip compression
    app.add_middleware(GZipMiddleware, minimum_size=1000)

    # Include API routes
    app.include_router(router, prefix="/api/v1")

    # Root endpoint
    @app.get("/")
    async def root():
        return {
            "name": settings.app_name,
            "version": "1.0.0",
            "status": "running",
            "docs": "/docs" if settings.debug else None,
        }

    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        workers=settings.workers,
        log_level=settings.observability.log_level.lower(),
        access_log=False,  # Use structlog instead
    )
