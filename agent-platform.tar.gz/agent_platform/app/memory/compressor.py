"""Conversation compression and summarization.

Implements token-based truncation and LLM-powered summarization
to keep conversation context within limits.
"""

import asyncio
from typing import Dict, List, Optional, Any

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.llm.client import get_llm_client

logger = get_logger(__name__)


class TokenEstimator:
    """Simple token estimator (approximation)."""

    @staticmethod
    def estimate(text: str) -> int:
        """Estimate token count (rough approximation: 1 token ≈ 0.75 English chars or 0.5 CJK chars)."""
        if not text:
            return 0
        # Simple heuristic: average 4 chars per token for mixed content
        return max(1, len(text) // 4)

    @staticmethod
    def estimate_messages(messages: List[Dict[str, str]]) -> int:
        """Estimate total tokens for message list."""
        total = 0
        for msg in messages:
            content = msg.get("content", "")
            total += TokenEstimator.estimate(content)
            # Add overhead per message
            total += 4
        return total


class ConversationCompressor:
    """Compress conversation history to fit token limits."""

    def __init__(self):
        self.config = settings.memory
        self.token_limit = self.config.token_limit
        self.summary_threshold = self.config.summary_threshold
        self.compression_ratio = self.config.compression_ratio

    async def compress(
        self,
        messages: List[Dict[str, str]],
        session_id: str,
        existing_summary: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Compress messages if they exceed token limit.

        Returns:
            Dict with "messages" (compressed list) and "summary" (updated summary)
        """
        with create_span("memory.compress", {"session_id": session_id}):
            total_tokens = TokenEstimator.estimate_messages(messages)

            if total_tokens <= self.token_limit:
                return {
                    "messages": messages,
                    "summary": existing_summary,
                    "compressed": False,
                    "original_tokens": total_tokens,
                }

            logger.info(
                "compressing_conversation",
                session_id=session_id,
                tokens=total_tokens,
                limit=self.token_limit,
            )

            # Strategy: Keep system message + recent messages + summarize older ones
            system_messages = [m for m in messages if m.get("role") == "system"]
            non_system = [m for m in messages if m.get("role") != "system"]

            # Keep last N messages based on compression ratio
            keep_count = max(
                self.summary_threshold,
                int(len(non_system) * self.compression_ratio),
            )

            to_summarize = non_system[:-keep_count] if len(non_system) > keep_count else []
            keep_messages = non_system[-keep_count:] if len(non_system) > keep_count else non_system

            new_summary = existing_summary or ""

            if to_summarize:
                summary_text = await self._generate_summary(to_summarize, existing_summary)
                new_summary = summary_text

            compressed = system_messages + keep_messages

            # Add summary as system message if exists
            if new_summary:
                compressed.insert(0, {
                    "role": "system",
                    "content": f"[历史对话摘要] {new_summary}",
                })

            new_tokens = TokenEstimator.estimate_messages(compressed)

            logger.info(
                "conversation_compressed",
                session_id=session_id,
                original_tokens=total_tokens,
                new_tokens=new_tokens,
                summary_length=len(new_summary) if new_summary else 0,
            )

            return {
                "messages": compressed,
                "summary": new_summary,
                "compressed": True,
                "original_tokens": total_tokens,
                "new_tokens": new_tokens,
            }

    async def _generate_summary(
        self,
        messages: List[Dict[str, str]],
        existing_summary: Optional[str],
    ) -> str:
        """Generate summary of conversation messages using LLM."""
        try:
            client = await get_llm_client()

            # Build summary prompt
            conversation_text = "\n".join([
                f"{m.get('role', 'user')}: {m.get('content', '')}"
                for m in messages
            ])

            prompt = f"""请对以下对话进行简洁的摘要总结，保留关键信息和用户意图：

{conversation_text}

{'之前的摘要：' + existing_summary if existing_summary else ''}

请用2-3句话总结上述对话的核心内容："""

            response = await client.chat(
                messages=[
                    {"role": "system", "content": "你是一个对话摘要助手，请简洁准确地总结对话内容。"},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=200,
                temperature=0.3,
            )

            if isinstance(response, str):
                return response
            return response.content

        except Exception as e:
            logger.warning("summary_generation_failed", error=str(e))
            # Fallback: simple truncation summary
            return self._fallback_summary(messages)

    def _fallback_summary(self, messages: List[Dict[str, str]]) -> str:
        """Generate simple fallback summary without LLM."""
        user_messages = [m for m in messages if m.get("role") == "user"]
        if not user_messages:
            return ""

        # Extract key topics from user messages
        topics = []
        for msg in user_messages[-3:]:  # Last 3 user messages
            content = msg.get("content", "")
            if len(content) > 20:
                topics.append(content[:50] + "...")
            else:
                topics.append(content)

        return "；".join(topics)


# Singleton
_compressor: Optional[ConversationCompressor] = None


async def get_compressor() -> ConversationCompressor:
    """Get compressor singleton."""
    global _compressor
    if _compressor is None:
        _compressor = ConversationCompressor()
    return _compressor
