"""Redis-based storage for conversation history.

Implements async Redis operations with connection pooling,
JSON serialization, and TTL management.
"""

import json
from typing import Any, Dict, List, Optional
from datetime import datetime

import redis.asyncio as redis
from redis.asyncio.connection import ConnectionPool

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span

logger = get_logger(__name__)


class RedisStore:
    """Async Redis store with connection pooling."""

    def __init__(self):
        self.config = settings.redis
        self.memory_config = settings.memory
        self._pool: Optional[ConnectionPool] = None
        self._client: Optional[redis.Redis] = None

    async def connect(self):
        """Initialize Redis connection pool."""
        if self._client is not None:
            return

        try:
            self._pool = ConnectionPool.from_url(
                self.config.url,
                password=self.config.password or None,
                max_connections=self.config.max_connections,
                socket_timeout=self.config.socket_timeout,
                socket_connect_timeout=self.config.socket_connect_timeout,
                decode_responses=True,
            )
            self._client = redis.Redis(connection_pool=self._pool)

            # Health check
            await self._client.ping()
            logger.info("redis_connected", pool_size=self.config.max_connections)
        except Exception as e:
            logger.error("redis_connection_failed", error=str(e))
            raise

    async def disconnect(self):
        """Close Redis connections."""
        if self._pool:
            await self._pool.disconnect()
            self._pool = None
            self._client = None
            logger.info("redis_disconnected")

    def _key(self, session_id: str, suffix: str = "") -> str:
        """Generate Redis key with prefix."""
        base = f"{self.memory_config.key_prefix}:{session_id}"
        return f"{base}:{suffix}" if suffix else base

    async def get_messages(self, session_id: str) -> List[Dict[str, Any]]:
        """Get conversation messages for a session."""
        with create_span("redis.get_messages", {"session_id": session_id}):
            await self.connect()
            key = self._key(session_id, "messages")
            data = await self._client.lrange(key, 0, -1)
            messages = []
            for item in data:
                try:
                    msg = json.loads(item)
                    messages.append(msg)
                except json.JSONDecodeError:
                    logger.warning("invalid_message_format", session_id=session_id)
            return messages

    async def append_message(self, session_id: str, message: Dict[str, Any]) -> None:
        """Append a message to conversation history."""
        with create_span("redis.append_message", {"session_id": session_id}):
            await self.connect()
            key = self._key(session_id, "messages")

            # Ensure timestamp is serializable
            if "timestamp" in message and isinstance(message["timestamp"], datetime):
                message["timestamp"] = message["timestamp"].isoformat()

            await self._client.rpush(key, json.dumps(message, ensure_ascii=False))
            await self._client.expire(key, self.memory_config.session_ttl)

    async def get_summary(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session summary."""
        with create_span("redis.get_summary", {"session_id": session_id}):
            await self.connect()
            key = self._key(session_id, "summary")
            data = await self._client.get(key)
            if data:
                return json.loads(data)
            return None

    async def set_summary(self, session_id: str, summary: Dict[str, Any]) -> None:
        """Set session summary."""
        with create_span("redis.set_summary", {"session_id": session_id}):
            await self.connect()
            key = self._key(session_id, "summary")
            await self._client.setex(
                key,
                self.memory_config.session_ttl,
                json.dumps(summary, ensure_ascii=False),
            )

    async def get_metadata(self, session_id: str) -> Dict[str, Any]:
        """Get session metadata."""
        with create_span("redis.get_metadata", {"session_id": session_id}):
            await self.connect()
            key = self._key(session_id, "metadata")
            data = await self._client.get(key)
            if data:
                return json.loads(data)
            return {}

    async def set_metadata(self, session_id: str, metadata: Dict[str, Any]) -> None:
        """Set session metadata."""
        with create_span("redis.set_metadata", {"session_id": session_id}):
            await self.connect()
            key = self._key(session_id, "metadata")
            await self._client.setex(
                key,
                self.memory_config.session_ttl,
                json.dumps(metadata, ensure_ascii=False),
            )

    async def clear_session(self, session_id: str) -> None:
        """Clear all session data."""
        with create_span("redis.clear_session", {"session_id": session_id}):
            await self.connect()
            pattern = self._key(session_id, "*")
            keys = await self._client.keys(pattern)
            if keys:
                await self._client.delete(*keys)
            logger.info("session_cleared", session_id=session_id)

    async def get_session_ids(self, pattern: str = "*") -> List[str]:
        """Get all session IDs matching pattern."""
        await self.connect()
        keys = await self._client.keys(f"{self.memory_config.key_prefix}:{pattern}")
        session_ids = []
        for key in keys:
            parts = key.split(":")
            if len(parts) >= 2:
                session_ids.append(parts[1])
        return list(set(session_ids))

    async def trim_messages(self, session_id: str, keep_last: int) -> None:
        """Trim message list to keep only last N messages."""
        with create_span("redis.trim_messages", {"session_id": session_id, "keep": keep_last}):
            await self.connect()
            key = self._key(session_id, "messages")
            total = await self._client.llen(key)
            if total > keep_last:
                await self._client.ltrim(key, -keep_last, -1)
                logger.info("messages_trimmed", session_id=session_id, removed=total - keep_last)


# Singleton
_redis_store: Optional[RedisStore] = None


async def get_redis_store() -> RedisStore:
    """Get Redis store singleton."""
    global _redis_store
    if _redis_store is None:
        _redis_store = RedisStore()
        await _redis_store.connect()
    return _redis_store
