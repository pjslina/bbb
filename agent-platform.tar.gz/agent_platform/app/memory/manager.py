"""Conversation memory manager.

Orchestrates Redis storage, message loading, compression,
and context preparation for LLM calls.
"""

from typing import Dict, List, Optional, Any

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.models.schemas import ChatMessage, MessageRole, SessionSummary
from app.memory.redis_store import get_redis_store, RedisStore
from app.memory.compressor import get_compressor, ConversationCompressor

logger = get_logger(__name__)


class MemoryManager:
    """Manages conversation memory lifecycle."""

    def __init__(self):
        self.config = settings.memory
        self._store: Optional[RedisStore] = None
        self._compressor: Optional[ConversationCompressor] = None

    async def _get_store(self) -> RedisStore:
        if self._store is None:
            self._store = await get_redis_store()
        return self._store

    async def _get_compressor(self) -> ConversationCompressor:
        if self._compressor is None:
            self._compressor = await get_compressor()
        return self._compressor

    async def load_history(self, session_id: str) -> List[Dict[str, Any]]:
        """Load conversation history for a session.

        Automatically loads from Redis, decompresses if needed,
        and returns message list ready for LLM context.
        """
        with create_span("memory.load_history", {"session_id": session_id}):
            store = await self._get_store()

            # Load messages
            messages = await store.get_messages(session_id)

            # Load summary
            summary_data = await store.get_summary(session_id)
            existing_summary = summary_data.get("summary", "") if summary_data else None

            # Compress if needed
            compressor = await self._get_compressor()
            result = await compressor.compress(messages, session_id, existing_summary)

            if result["compressed"] and result.get("summary"):
                # Update summary in Redis
                await store.set_summary(session_id, {
                    "summary": result["summary"],
                    "updated_at": __import__("datetime").datetime.utcnow().isoformat(),
                })

            return result["messages"]

    async def save_message(
        self,
        session_id: str,
        role: MessageRole,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Save a message to conversation history."""
        with create_span("memory.save_message", {"session_id": session_id, "role": role}):
            store = await self._get_store()

            message = {
                "role": role.value,
                "content": content,
                "timestamp": __import__("datetime").datetime.utcnow().isoformat(),
                "metadata": metadata or {},
            }

            await store.append_message(session_id, message)

            # Trim if exceeds max history
            await store.trim_messages(session_id, self.config.max_history)

    async def get_context_messages(
        self,
        session_id: str,
        system_prompt: Optional[str] = None,
    ) -> List[Dict[str, str]]:
        """Get full context messages including system prompt and history."""
        with create_span("memory.get_context", {"session_id": session_id}):
            messages = []

            # System prompt
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})

            # Load and compress history
            history = await self.load_history(session_id)
            messages.extend(history)

            return messages

    async def append_user_message(self, session_id: str, content: str) -> None:
        """Append user message."""
        await self.save_message(session_id, MessageRole.USER, content)

    async def append_assistant_message(
        self,
        session_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Append assistant message."""
        await self.save_message(session_id, MessageRole.ASSISTANT, content, metadata)

    async def append_tool_message(
        self,
        session_id: str,
        tool_name: str,
        result: Any,
    ) -> None:
        """Append tool result message."""
        content = f"[Tool: {tool_name}] Result: {str(result)[:500]}"
        await self.save_message(
            session_id,
            MessageRole.TOOL,
            content,
            {"tool_name": tool_name, "result": result},
        )

    async def clear_session(self, session_id: str) -> None:
        """Clear all session data."""
        store = await self._get_store()
        await store.clear_session(session_id)

    async def get_session_stats(self, session_id: str) -> Dict[str, Any]:
        """Get session statistics."""
        store = await self._get_store()
        messages = await store.get_messages(session_id)
        summary = await store.get_summary(session_id)
        metadata = await store.get_metadata(session_id)

        return {
            "session_id": session_id,
            "message_count": len(messages),
            "has_summary": summary is not None,
            "metadata": metadata,
        }


# Singleton
_memory_manager: Optional[MemoryManager] = None


async def get_memory_manager() -> MemoryManager:
    """Get memory manager singleton."""
    global _memory_manager
    if _memory_manager is None:
        _memory_manager = MemoryManager()
    return _memory_manager
