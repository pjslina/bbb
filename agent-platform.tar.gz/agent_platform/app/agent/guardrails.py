"""Agent guardrails - safety controls.

Prevents agent from running away with:
- Max iteration limits
- Timeout enforcement
- Tool call limits
- Token budget enforcement
- Content safety checks
"""

import asyncio
import time
from typing import Any, Dict, Optional

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.models.schemas import IntentType

logger = get_logger(__name__)


class Guardrails:
    """Agent safety guardrails."""

    def __init__(self):
        self.config = settings.agent
        self.max_iterations = self.config.max_iterations
        self.timeout = self.config.timeout
        self.max_tool_calls = self.config.max_tool_calls
        self.max_tokens = self.config.max_tokens_per_conversation

    def check_iteration_limit(self, current: int) -> tuple[bool, str]:
        """Check if iteration limit exceeded."""
        if current >= self.max_iterations:
            return False, f"Maximum iterations ({self.max_iterations}) reached"
        return True, ""

    def check_tool_call_limit(self, count: int) -> tuple[bool, str]:
        """Check if tool call limit exceeded."""
        if count >= self.max_tool_calls:
            return False, f"Maximum tool calls ({self.max_tool_calls}) reached"
        return True, ""

    def check_token_budget(self, tokens: int) -> tuple[bool, str]:
        """Check if token budget exceeded."""
        if tokens >= self.max_tokens:
            return False, f"Token budget ({self.max_tokens}) exceeded"
        return True, ""

    def check_timeout(self, start_time: float) -> tuple[bool, str]:
        """Check if timeout exceeded."""
        elapsed = time.time() - start_time
        if elapsed >= self.timeout:
            return False, f"Timeout ({self.timeout}s) exceeded"
        return True, ""

    def validate_all(
        self,
        state: Dict[str, Any],
        start_time: float,
    ) -> tuple[bool, str]:
        """Run all guardrail checks.

        Returns:
            (passed, error_message)
        """
        with create_span("guardrails.check"):
            checks = [
                self.check_iteration_limit(state.get("current_iteration", 0)),
                self.check_tool_call_limit(state.get("tool_call_count", 0)),
                self.check_token_budget(state.get("response_tokens", 0)),
                self.check_timeout(start_time),
            ]

            for passed, error in checks:
                if not passed:
                    logger.warning(
                        "guardrail_triggered",
                        error=error,
                        session_id=state.get("session_id", "unknown"),
                    )
                    return False, error

            return True, ""

    def check_content_safety(self, content: str) -> tuple[bool, str]:
        """Check content for safety issues.

        Basic implementation - can be extended with more sophisticated checks.
        """
        # Block dangerous SQL patterns (defense in depth)
        dangerous_patterns = [
            "DROP TABLE",
            "DELETE FROM",
            "TRUNCATE TABLE",
            "ALTER TABLE",
            "; DROP",
            "; DELETE",
        ]

        content_upper = content.upper()
        for pattern in dangerous_patterns:
            if pattern in content_upper:
                return False, f"Potentially dangerous content detected: {pattern}"

        return True, ""


class TimeoutExecutor:
    """Execute coroutine with timeout and cancellation."""

    def __init__(self, timeout: int):
        self.timeout = timeout

    async def execute(self, coro) -> Any:
        """Execute coroutine with timeout."""
        try:
            return await asyncio.wait_for(coro, timeout=self.timeout)
        except asyncio.TimeoutError:
            logger.error("execution_timeout", timeout=self.timeout)
            raise TimeoutError(f"Execution timed out after {self.timeout} seconds")


# Singleton
_guardrails: Optional[Guardrails] = None


def get_guardrails() -> Guardrails:
    """Get guardrails singleton."""
    global _guardrails
    if _guardrails is None:
        _guardrails = Guardrails()
    return _guardrails
