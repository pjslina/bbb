"""LangGraph node implementations.

Each node is a pure function that takes state and returns updates.
Nodes are composable and observable.

Graph flow:
start -> intent_recognition -> tool_decision -> [tool_execution or llm_response] -> memory_update -> end
"""

import json
import time
from typing import Any, Dict, List, Optional

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.llm.client import get_llm_client
from app.memory.manager import get_memory_manager
from app.models.schemas import IntentType, StreamingEvent
from app.tools.registry import get_tool_registry
from app.tools.router import get_tool_router
from app.agent.state import AgentState
from app.agent.guardrails import get_guardrails

logger = get_logger(__name__)


# System prompts
INTENT_RECOGNITION_PROMPT = """你是一个意图识别助手。分析用户消息，判断其意图类型。

可选意图：
- general_query: 一般性问答、闲聊、解释概念
- data_query: 需要查询数据库的数据请求
- api_call: 需要调用外部API
- analysis: 需要数据分析、统计、报告
- clarification: 用户要求澄清、重复、解释
- greeting: 问候、打招呼
- unknown: 无法判断

只返回JSON格式：{"intent": "意图类型", "confidence": 0.0-1.0}
不要添加任何其他文字。"""

RESPONSE_PROMPT = """你是一个智能助手。根据对话历史和工具执行结果，生成自然、准确的回复。

规则：
1. 基于事实回答，不要编造信息
2. 如果使用了工具，说明查询结果
3. 如果查询无结果，说明情况
4. 保持友好、专业的语气
5. 使用中文回复

当前对话上下文已包含历史消息和工具结果。"""


async def intent_recognition_node(state: AgentState) -> Dict[str, Any]:
    """Node: Recognize user intent.

    Uses LLM to classify user intent with confidence score.
    """
    with create_span("agent.node.intent_recognition", {"session": state["session_id"]}):
        logger.info("intent_recognition", session_id=state["session_id"])

        user_message = state["messages"][-1].content if state["messages"] else ""

        try:
            client = await get_llm_client()
            response = await client.chat(
                messages=[
                    {"role": "system", "content": INTENT_RECOGNITION_PROMPT},
                    {"role": "user", "content": user_message},
                ],
                max_tokens=100,
                temperature=0.1,
            )

            content = response.content if hasattr(response, 'content') else str(response)

            # Parse JSON response
            try:
                result = json.loads(content.strip())
                intent_str = result.get("intent", "unknown")
                confidence = result.get("confidence", 0.5)
            except json.JSONDecodeError:
                # Fallback: keyword matching
                intent_str = _fallback_intent(user_message)
                confidence = 0.6

            intent = IntentType(intent_str) if intent_str in [i.value for i in IntentType] else IntentType.UNKNOWN

            logger.info(
                "intent_recognized",
                intent=intent.value,
                confidence=confidence,
            )

            return {
                "intent": intent,
                "intent_confidence": confidence,
                "stream_events": [{
                    "event_type": "intent",
                    "data": {"intent": intent.value, "confidence": confidence},
                }],
            }

        except Exception as e:
            logger.error("intent_recognition_failed", error=str(e))
            return {
                "intent": IntentType.UNKNOWN,
                "intent_confidence": 0.0,
                "error": f"Intent recognition failed: {str(e)}",
            }


def _fallback_intent(message: str) -> str:
    """Fallback intent classification by keywords."""
    msg_lower = message.lower()

    if any(w in msg_lower for w in ["你好", "hello", "hi", "hey", "在吗"]):
        return "greeting"

    if any(w in msg_lower for w in ["查询", "查", "数据", "统计", "多少", "列表", "搜索用户"]):
        return "data_query"

    if any(w in msg_lower for w in ["分析", "报表", "趋势", "留存", "活跃"]):
        return "analysis"

    if any(w in msg_lower for w in ["天气", "api", "调用"]):
        return "api_call"

    if any(w in msg_lower for w in ["什么意思", "再说一遍", "不懂", "解释"]):
        return "clarification"

    return "general_query"


async def tool_decision_node(state: AgentState) -> Dict[str, Any]:
    """Node: Decide whether to use tools.

    Based on intent and confidence, decide tool usage.
    """
    with create_span("agent.node.tool_decision", {"session": state["session_id"]}):
        intent = state.get("intent", IntentType.UNKNOWN)
        confidence = state.get("intent_confidence", 0)

        # Tool-requiring intents
        tool_intents = [
            IntentType.DATA_QUERY,
            IntentType.API_CALL,
            IntentType.ANALYSIS,
        ]

        should_use_tool = (
            intent in tool_intents
            and confidence >= 0.5
            and state["tool_call_count"] < settings.agent.max_tool_calls
        )

        logger.info(
            "tool_decision",
            intent=intent.value,
            use_tool=should_use_tool,
            tool_count=state["tool_call_count"],
        )

        return {
            "should_use_tool": should_use_tool,
            "stream_events": [{
                "event_type": "tool_decision",
                "data": {"use_tool": should_use_tool, "intent": intent.value},
            }],
        }


async def tool_execution_node(state: AgentState) -> Dict[str, Any]:
    """Node: Execute selected tools.

    Routes to appropriate tools and collects results.
    """
    with create_span("agent.node.tool_execution", {"session": state["session_id"]}):
        session_id = state["session_id"]
        user_message = state["messages"][-1].content if state["messages"] else ""
        intent = state.get("intent", IntentType.UNKNOWN)

        logger.info("tool_execution", session_id=session_id, intent=intent.value)

        try:
            # Select tools
            router = get_tool_router()
            selected_tools = await router.select_tools(intent, user_message)

            if not selected_tools:
                logger.info("no_tools_selected", intent=intent.value)
                return {
                    "should_use_tool": False,
                    "tool_results": [],
                    "stream_events": [{
                        "event_type": "tool_result",
                        "data": {"message": "No tools needed for this request"},
                    }],
                }

            # Execute tools
            registry = get_tool_registry()
            results = []

            for tool_name in selected_tools:
                # For db_query, extract template and params from message
                if tool_name in ["db_query", "db_analytics"]:
                    result = await _execute_db_tool(tool_name, user_message, intent)
                else:
                    result = await registry.execute(tool_name, {"query": user_message})

                results.append(result)

                # Save tool result to memory
                memory = await get_memory_manager()
                await memory.append_tool_message(
                    session_id,
                    tool_name,
                    result,
                )

            return {
                "selected_tools": selected_tools,
                "tool_results": results,
                "tool_call_count": state["tool_call_count"] + len(selected_tools),
                "should_use_tool": False,  # Reset after execution
                "stream_events": [{
                    "event_type": "tool_result",
                    "data": {"tools": selected_tools, "results": results},
                }],
            }

        except Exception as e:
            logger.error("tool_execution_failed", error=str(e))
            return {
                "error": f"Tool execution failed: {str(e)}",
                "should_use_tool": False,
                "stream_events": [{
                    "event_type": "error",
                    "data": {"message": str(e)},
                }],
            }


async def _execute_db_tool(tool_name: str, user_message: str, intent: IntentType) -> Dict[str, Any]:
    """Execute database tool with LLM parameter extraction."""
    from app.db.schemas import get_sql_registry
    from app.tools.db_tools import db_query, db_analytics

    registry = get_sql_registry()

    # Use LLM to select template
    router = get_tool_router()
    template_id = await router._llm_select_template(user_message)

    if not template_id:
        return {
            "success": False,
            "error": "Could not determine appropriate SQL template",
        }

    template = registry.get(template_id)
    if not template:
        return {
            "success": False,
            "error": f"Template not found: {template_id}",
        }

    # Use LLM to extract parameters
    params = await _extract_params(user_message, template)

    # Execute
    if tool_name == "db_analytics":
        return await db_analytics(template_id, params, "analytics")
    else:
        return await db_query(template_id, params, "default")


async def _extract_params(user_message: str, template) -> Dict[str, Any]:
    """Extract parameters from user message using LLM."""
    try:
        client = await get_llm_client()

        param_descriptions = []
        for p in template.parameters:
            param_descriptions.append(f"- {p.name} ({p.type}): {p.description}")

        prompt = f"""从用户消息中提取以下参数的值。只返回JSON格式。

需要的参数：
{chr(10).join(param_descriptions)}

用户消息：{user_message}

返回格式：{{"param_name": "value", ...}}
如果参数无法确定，使用null或默认值。"""

        response = await client.chat(
            messages=[
                {"role": "system", "content": "你是一个参数提取助手。只返回JSON。"},
                {"role": "user", "content": prompt},
            ],
            max_tokens=200,
            temperature=0.1,
        )

        content = response.content if hasattr(response, 'content') else str(response)

        try:
            params = json.loads(content.strip())
            # Filter to only known parameters
            known = {p.name for p in template.parameters}
            return {k: v for k, v in params.items() if k in known}
        except json.JSONDecodeError:
            return {}

    except Exception as e:
        logger.warning("param_extraction_failed", error=str(e))
        return {}


async def llm_response_node(state: AgentState) -> Dict[str, Any]:
    """Node: Generate LLM response.

    Generates final response based on conversation context and tool results.
    """
    with create_span("agent.node.llm_response", {"session": state["session_id"]}):
        session_id = state["session_id"]

        # Build context messages
        memory = await get_memory_manager()
        context_messages = await memory.get_context_messages(
            session_id,
            system_prompt=RESPONSE_PROMPT,
        )

        # Add tool results to context
        tool_results = state.get("tool_results", [])
        if tool_results:
            tool_context = "\n[工具执行结果]\n"
            for i, result in enumerate(tool_results):
                tool_context += f"工具{i+1}: {json.dumps(result, ensure_ascii=False, default=str)}\n"

            # Add as system context
            context_messages.append({
                "role": "system",
                "content": tool_context,
            })

        # Add current user message if not already in context
        if not any(m.get("role") == "user" for m in context_messages[-2:]):
            user_msg = state["messages"][-1].content if state["messages"] else ""
            context_messages.append({"role": "user", "content": user_msg})

        try:
            client = await get_llm_client()
            response = await client.chat(
                messages=context_messages,
                max_tokens=settings.llm_primary.max_tokens,
                temperature=settings.llm_primary.temperature,
            )

            content = response.content if hasattr(response, 'content') else str(response)
            tokens = response.usage.get("total_tokens", 0) if hasattr(response, 'usage') else 0

            logger.info(
                "response_generated",
                session_id=session_id,
                tokens=tokens,
                response_length=len(content),
            )

            return {
                "response": content,
                "response_tokens": state.get("response_tokens", 0) + tokens,
                "messages": [AIMessage(content=content)],
                "stream_events": [{
                    "event_type": "complete",
                    "data": {"response": content, "tokens": tokens},
                }],
            }

        except Exception as e:
            logger.error("response_generation_failed", error=str(e))
            return {
                "error": f"Response generation failed: {str(e)}",
                "response": "抱歉，生成回复时出现问题，请稍后重试。",
                "stream_events": [{
                    "event_type": "error",
                    "data": {"message": str(e)},
                }],
            }


async def memory_update_node(state: AgentState) -> Dict[str, Any]:
    """Node: Update conversation memory.

    Saves assistant response and updates session metadata.
    """
    with create_span("agent.node.memory_update", {"session": state["session_id"]}):
        session_id = state["session_id"]
        response = state.get("response", "")

        if response:
            memory = await get_memory_manager()
            await memory.append_assistant_message(
                session_id,
                response,
                metadata={
                    "intent": state.get("intent", IntentType.UNKNOWN).value,
                    "tools_used": state.get("selected_tools", []),
                    "iteration": state.get("current_iteration", 0),
                },
            )

        return {
            "finished": True,
            "current_iteration": state.get("current_iteration", 0) + 1,
            "stream_events": [{
                "event_type": "end",
                "data": {"session_id": session_id, "finished": True},
            }],
        }


def start_node(state: AgentState) -> Dict[str, Any]:
    """Node: Initialize execution.

    Sets up execution context and validates state.
    """
    logger.info("agent_start", session_id=state["session_id"])

    return {
        "current_iteration": state.get("current_iteration", 0) + 1,
        "stream_events": [{
            "event_type": "start",
            "data": {"session_id": state["session_id"]},
        }],
    }


def end_node(state: AgentState) -> Dict[str, Any]:
    """Node: Finalize execution.

    Cleanup and final state preparation.
    """
    logger.info("agent_end", session_id=state["session_id"])

    return {
        "finished": True,
        "stream_events": [{
            "event_type": "end",
            "data": {"session_id": state["session_id"], "status": "completed"},
        }],
    }
