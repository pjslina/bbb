"""Agent state definitions for LangGraph.

State is the single source of truth for the agent execution.
All nodes read from and write to this state.
"""

from typing import Annotated, Any, Dict, List, Optional, Sequence, TypedDict
import operator

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage

from app.models.schemas import IntentType


class AgentState(TypedDict):
    """Agent state graph state.

    All fields are optional to allow partial updates.
    Messages use add operator for automatic accumulation.
    """
    # Session identification
    session_id: str

    # Conversation messages (accumulated)
    messages: Annotated[Sequence[BaseMessage], operator.add]

    # Intent classification
    intent: Optional[IntentType]
    intent_confidence: float

    # Tool execution
    selected_tools: List[str]
    tool_results: List[Dict[str, Any]]
    tool_call_count: int

    # Execution tracking
    current_iteration: int
    max_iterations: int

    # Response generation
    response: Optional[str]
    response_tokens: int

    # Error handling
    error: Optional[str]

    # Flow control
    finished: bool
    should_use_tool: bool

    # Metadata
    metadata: Dict[str, Any]

    # Streaming
    stream_events: List[Dict[str, Any]]


def create_initial_state(session_id: str, user_message: str) -> AgentState:
    """Create initial state for a new conversation turn."""
    return {
        "session_id": session_id,
        "messages": [HumanMessage(content=user_message)],
        "intent": None,
        "intent_confidence": 0.0,
        "selected_tools": [],
        "tool_results": [],
        "tool_call_count": 0,
        "current_iteration": 0,
        "max_iterations": 10,
        "response": None,
        "response_tokens": 0,
        "error": None,
        "finished": False,
        "should_use_tool": False,
        "metadata": {},
        "stream_events": [],
    }
