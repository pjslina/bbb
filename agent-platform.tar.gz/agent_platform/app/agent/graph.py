"""LangGraph StateGraph builder.

Builds the agent execution graph with all nodes and edges.
Supports conditional routing and guardrail enforcement.
"""

from typing import Any, Dict, Literal

from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.agent.state import AgentState
from app.agent.nodes import (
    start_node,
    intent_recognition_node,
    tool_decision_node,
    tool_execution_node,
    llm_response_node,
    memory_update_node,
    end_node,
)
from app.agent.guardrails import get_guardrails

logger = get_logger(__name__)


def build_agent_graph() -> StateGraph:
    """Build the agent execution graph.

    Graph structure:
        start -> intent_recognition -> tool_decision -> [tool_execution or llm_response] -> memory_update -> end

    Conditional edges:
        - tool_decision -> tool_execution (if should_use_tool)
        - tool_decision -> llm_response (if not should_use_tool)
    """
    with create_span("agent.build_graph"):
        # Create graph with state type
        workflow = StateGraph(AgentState)

        # Add nodes
        workflow.add_node("start", start_node)
        workflow.add_node("intent_recognition", intent_recognition_node)
        workflow.add_node("tool_decision", tool_decision_node)
        workflow.add_node("tool_execution", tool_execution_node)
        workflow.add_node("llm_response", llm_response_node)
        workflow.add_node("memory_update", memory_update_node)
        workflow.add_node("end", end_node)

        # Add edges
        workflow.set_entry_point("start")
        workflow.add_edge("start", "intent_recognition")
        workflow.add_edge("intent_recognition", "tool_decision")

        # Conditional routing from tool_decision
        def route_tool_decision(state: AgentState) -> Literal["tool_execution", "llm_response"]:
            """Route based on tool decision."""
            if state.get("should_use_tool", False) and state.get("tool_call_count", 0) < settings.agent.max_tool_calls:
                return "tool_execution"
            return "llm_response"

        workflow.add_conditional_edges(
            "tool_decision",
            route_tool_decision,
            {
                "tool_execution": "tool_execution",
                "llm_response": "llm_response",
            },
        )

        # After tool execution, go to LLM response
        workflow.add_edge("tool_execution", "llm_response")

        # After LLM response, update memory
        workflow.add_edge("llm_response", "memory_update")

        # After memory update, end
        workflow.add_edge("memory_update", "end")

        # End is terminal
        workflow.add_edge("end", END)

        logger.info("agent_graph_built", nodes=list(workflow.nodes.keys()))

        return workflow


def create_agent():
    """Create compiled agent with checkpointing."""
    graph = build_agent_graph()

    # Add memory checkpointing for state persistence
    checkpointer = MemorySaver()

    # Compile graph
    compiled = graph.compile(checkpointer=checkpointer)

    logger.info("agent_compiled")

    return compiled


# Singleton
_agent = None


def get_agent():
    """Get compiled agent singleton."""
    global _agent
    if _agent is None:
        _agent = create_agent()
    return _agent
