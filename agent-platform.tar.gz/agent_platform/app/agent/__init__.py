"""Agent module - LangGraph-based stateful agent."""
