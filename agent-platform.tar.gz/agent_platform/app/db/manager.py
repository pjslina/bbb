"""Database manager - high-level database operations.

Combines routing, pool management, and safe SQL execution.
Provides a clean interface for tools to execute database queries.
"""

from typing import Any, Dict, List, Optional

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.db.pool import get_pool_manager, PoolManager
from app.db.router import get_router, DatabaseRouter, QueryType
from app.db.schemas import get_sql_registry, SQLTemplateRegistry

logger = get_logger(__name__)


class DatabaseManager:
    """High-level database manager for safe query execution."""

    def __init__(self):
        self._pool_manager: Optional[PoolManager] = None
        self._router: Optional[DatabaseRouter] = None
        self._sql_registry: Optional[SQLTemplateRegistry] = None

    async def _get_pool_manager(self) -> PoolManager:
        if self._pool_manager is None:
            self._pool_manager = await get_pool_manager()
        return self._pool_manager

    def _get_router(self) -> DatabaseRouter:
        if self._router is None:
            self._router = get_router()
        return self._router

    def _get_sql_registry(self) -> SQLTemplateRegistry:
        if self._sql_registry is None:
            self._sql_registry = get_sql_registry()
        return self._sql_registry

    async def execute_template(
        self,
        template_id: str,
        params: Dict[str, Any],
        scenario: str = "default",
    ) -> Dict[str, Any]:
        """Execute a predefined SQL template safely.

        Args:
            template_id: Registered template ID
            params: Template parameters
            scenario: Business scenario for routing

        Returns:
            Query results with metadata
        """
        with create_span("db.execute_template", {"template": template_id, "scenario": scenario}):
            registry = self._get_sql_registry()
            router = self._get_router()
            pool_manager = await self._get_pool_manager()

            # Validate template exists
            template = registry.get(template_id)
            if not template:
                raise ValueError(f"Unknown SQL template: {template_id}")

            # Validate parameters
            is_valid, error = registry.validate_parameters(template_id, params)
            if not is_valid:
                raise ValueError(f"Parameter validation failed: {error}")

            # Route to appropriate database
            route = router.route(scenario=scenario, sql=template.sql_pattern)

            # Check if database is allowed
            if route.pool_name not in template.allowed_databases:
                raise ValueError(
                    f"Template {template_id} not allowed on {route.pool_name}. "
                    f"Allowed: {template.allowed_databases}"
                )

            # Render SQL with parameter binding
            sql, bound_params = registry.render(template_id, params)

            # Enforce read-only for safety
            if template.read_only and not route.read_only:
                logger.warning(
                    "read_only_template_on_write_pool",
                    template=template_id,
                    pool=route.pool_name,
                )

            # Execute
            pool = pool_manager.get_pool(route.pool_name)

            logger.info(
                "executing_sql_template",
                template=template_id,
                pool=route.pool_name,
                read_only=route.read_only,
            )

            try:
                rows = await pool.fetch(sql, *bound_params)

                # Convert records to dicts
                results = []
                for row in rows[:settings.db_max_query_rows]:
                    results.append(dict(row))

                return {
                    "success": True,
                    "template_id": template_id,
                    "pool": route.pool_name,
                    "row_count": len(results),
                    "data": results,
                }

            except Exception as e:
                logger.error(
                    "sql_execution_failed",
                    template=template_id,
                    error=str(e),
                )
                raise

    async def health_check(self) -> Dict[str, Any]:
        """Check all database connections."""
        pool_manager = await self._get_pool_manager()
        return await pool_manager.health_check_all()

    async def list_templates(self, database: Optional[str] = None) -> List[Dict[str, Any]]:
        """List available SQL templates."""
        registry = self._get_sql_registry()

        if database:
            templates = registry.get_for_database(database)
        else:
            templates = registry.list_templates()

        return [
            {
                "template_id": t.template_id,
                "description": t.description,
                "type": "read_only" if t.read_only else "write",
                "allowed_databases": t.allowed_databases,
                "parameters": [
                    {"name": p.name, "type": p.type, "required": p.required}
                    for p in t.parameters
                ],
            }
            for t in templates
        ]


# Singleton
_db_manager: Optional[DatabaseManager] = None


async def get_db_manager() -> DatabaseManager:
    """Get database manager singleton."""
    global _db_manager
    if _db_manager is None:
        _db_manager = DatabaseManager()
    return _db_manager
