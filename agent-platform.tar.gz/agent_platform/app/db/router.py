"""Dynamic database routing.

Routes queries to appropriate database pools based on:
- Query type (read/write)
- Data domain/scenario
- Load balancing
- Pool health
"""

import re
from enum import Enum
from typing import Dict, List, Optional

from app.core.config import settings
from app.core.logger import get_logger
from app.core.trace import create_span
from app.models.schemas import DatabaseRoute

logger = get_logger(__name__)


class QueryType(str, Enum):
    READ = "read"
    WRITE = "write"
    SCHEMA = "schema"


class DatabaseRouter:
    """Dynamic database router with scenario-based routing."""

    # Scenario to pool mapping
    SCENARIO_MAP = {
        "user_data": "primary",
        "analytics": "opengauss",
        "reporting": "secondary",
        "default": "primary",
    }

    # Read-only query patterns
    READ_PATTERNS = [
        r"^\s*SELECT\s+",
        r"^\s*WITH\s+",
        r"^\s*EXPLAIN\s+",
        r"^\s*SHOW\s+",
        r"^\s*DESCRIBE\s+",
    ]

    def __init__(self):
        self.read_patterns = [re.compile(p, re.IGNORECASE) for p in self.READ_PATTERNS]

    def classify_query(self, sql: str) -> QueryType:
        """Classify query as read or write."""
        sql_upper = sql.strip().upper()

        for pattern in self.read_patterns:
            if pattern.match(sql):
                return QueryType.READ

        # Check for write operations
        write_keywords = ["INSERT", "UPDATE", "DELETE", "CREATE", "DROP", "ALTER", "TRUNCATE"]
        for kw in write_keywords:
            if sql_upper.startswith(kw):
                return QueryType.WRITE

        return QueryType.READ  # Default to read for safety

    def route(
        self,
        scenario: str = "default",
        query_type: Optional[QueryType] = None,
        sql: Optional[str] = None,
    ) -> DatabaseRoute:
        """Determine database route for a query.

        Args:
            scenario: Business scenario (user_data, analytics, etc.)
            query_type: Explicit query type
            sql: SQL query string (for auto-classification)

        Returns:
            DatabaseRoute with pool name and reasoning
        """
        with create_span("db.route", {"scenario": scenario}):
            # Auto-classify if needed
            if query_type is None and sql:
                query_type = self.classify_query(sql)
            elif query_type is None:
                query_type = QueryType.READ

            # Get base pool for scenario
            pool_name = self.SCENARIO_MAP.get(scenario, "primary")

            # Route reads to secondary if available
            if query_type == QueryType.READ and pool_name == "primary":
                if "secondary" in settings.db_pools:
                    pool_name = "secondary"
                    reason = f"Read query routed to secondary replica for scenario '{scenario}'"
                else:
                    reason = f"Read query using primary (no replica) for scenario '{scenario}'"
            elif query_type == QueryType.WRITE:
                # Writes always go to primary
                pool_name = "primary"
                reason = f"Write query forced to primary for scenario '{scenario}'"
            else:
                reason = f"Query routed to {pool_name} for scenario '{scenario}'"

            logger.debug(
                "db_route_decision",
                scenario=scenario,
                query_type=query_type.value,
                pool=pool_name,
            )

            return DatabaseRoute(
                pool_name=pool_name,
                reason=reason,
                read_only=(query_type == QueryType.READ),
            )

    def register_scenario(self, scenario: str, pool_name: str):
        """Register a new scenario routing rule."""
        self.SCENARIO_MAP[scenario] = pool_name
        logger.info("scenario_registered", scenario=scenario, pool=pool_name)

    def get_routing_table(self) -> Dict[str, str]:
        """Get current routing table."""
        return dict(self.SCENARIO_MAP)


# Singleton
_router: Optional[DatabaseRouter] = None


def get_router() -> DatabaseRouter:
    """Get router singleton."""
    global _router
    if _router is None:
        _router = DatabaseRouter()
    return _router
