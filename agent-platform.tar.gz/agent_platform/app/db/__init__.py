"""Database module with multi-database support."""
