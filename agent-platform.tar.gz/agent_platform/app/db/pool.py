"""Database connection pool management.

Supports multiple database backends (PostgreSQL, OpenGauss)
with async connection pooling via asyncpg.
"""

import asyncio
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Dict, List, Optional, Any

import asyncpg

from app.core.config import settings, DatabasePoolConfig
from app.core.logger import get_logger
from app.core.trace import create_span

logger = get_logger(__name__)


class ConnectionPool:
    """Managed async database connection pool."""

    def __init__(self, name: str, config: DatabasePoolConfig):
        self.name = name
        self.config = config
        self._pool: Optional[asyncpg.Pool] = None
        self._initialized = False

    async def initialize(self):
        """Initialize the connection pool."""
        if self._initialized:
            return

        with create_span("db.pool.init", {"pool": self.name, "host": self.config.host}):
            try:
                self._pool = await asyncpg.create_pool(
                    host=self.config.host,
                    port=self.config.port,
                    database=self.config.database,
                    user=self.config.user,
                    password=self.config.password,
                    min_size=max(1, self.config.pool_size // 4),
                    max_size=self.config.pool_size,
                    max_inactive_time=self.config.pool_recycle,
                    command_timeout=settings.db_query_timeout,
                    server_settings={
                        "application_name": f"{settings.app_name}:{self.name}",
                    },
                )
                self._initialized = True
                logger.info(
                    "pool_initialized",
                    pool=self.name,
                    host=self.config.host,
                    size=self.config.pool_size,
                )
            except Exception as e:
                logger.error(
                    "pool_init_failed",
                    pool=self.name,
                    error=str(e),
                )
                raise

    async def close(self):
        """Close the connection pool."""
        if self._pool:
            await self._pool.close()
            self._initialized = False
            logger.info("pool_closed", pool=self.name)

    @asynccontextmanager
    async def acquire(self) -> AsyncGenerator[asyncpg.Connection, None]:
        """Acquire a connection from the pool."""
        if not self._initialized:
            await self.initialize()

        conn = None
        try:
            conn = await self._pool.acquire()
            yield conn
        finally:
            if conn:
                await self._pool.release(conn)

    async def execute(self, query: str, *args) -> str:
        """Execute a query."""
        async with self.acquire() as conn:
            return await conn.execute(query, *args)

    async def fetch(self, query: str, *args) -> List[asyncpg.Record]:
        """Fetch all rows."""
        async with self.acquire() as conn:
            return await conn.fetch(query, *args)

    async def fetchrow(self, query: str, *args) -> Optional[asyncpg.Record]:
        """Fetch single row."""
        async with self.acquire() as conn:
            return await conn.fetchrow(query, *args)

    async def fetchval(self, query: str, *args):
        """Fetch single value."""
        async with self.acquire() as conn:
            return await conn.fetchval(query, *args)

    async def health_check(self) -> bool:
        """Check pool health."""
        try:
            async with self.acquire() as conn:
                result = await conn.fetchval("SELECT 1")
                return result == 1
        except Exception as e:
            logger.warning("pool_health_check_failed", pool=self.name, error=str(e))
            return False

    @property
    def is_healthy(self) -> bool:
        return self._initialized and self._pool is not None


class PoolManager:
    """Manages multiple database connection pools."""

    def __init__(self):
        self._pools: Dict[str, ConnectionPool] = {}

    async def initialize(self):
        """Initialize all configured pools."""
        for name, config in settings.db_pools.items():
            pool = ConnectionPool(name, config)
            await pool.initialize()
            self._pools[name] = pool

    async def close(self):
        """Close all pools."""
        for pool in self._pools.values():
            await pool.close()
        self._pools.clear()

    def get_pool(self, name: str) -> ConnectionPool:
        """Get pool by name."""
        if name not in self._pools:
            raise ValueError(f"Unknown database pool: {name}. Available: {list(self._pools.keys())}")
        return self._pools[name]

    def list_pools(self) -> List[str]:
        """List all pool names."""
        return list(self._pools.keys())

    async def health_check_all(self) -> Dict[str, bool]:
        """Health check all pools."""
        results = {}
        for name, pool in self._pools.items():
            results[name] = await pool.health_check()
        return results


# Singleton
_pool_manager: Optional[PoolManager] = None


async def get_pool_manager() -> PoolManager:
    """Get pool manager singleton."""
    global _pool_manager
    if _pool_manager is None:
        _pool_manager = PoolManager()
        await _pool_manager.initialize()
    return _pool_manager
