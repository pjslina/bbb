"""Safe SQL template system.

CRITICAL SECURITY: LLM NEVER constructs raw SQL.
All database queries use predefined templates with parameter binding.
This prevents SQL injection and hallucinated queries.
"""

import re
from typing import Any, Dict, List, Optional

from app.core.config import settings
from app.core.logger import get_logger
from app.models.schemas import SQLTemplate, ToolParameter

logger = get_logger(__name__)


class SQLTemplateRegistry:
    """Registry of safe SQL templates.

    All database queries must be predefined here.
    LLM selects templates by ID and provides parameters only.
    """

    def __init__(self):
        self._templates: Dict[str, SQLTemplate] = {}
        self._register_builtin_templates()

    def _register_builtin_templates(self):
        """Register built-in safe SQL templates."""

        # Template 1: Query user by ID
        self.register(SQLTemplate(
            template_id="user.get_by_id",
            description="Get user information by user ID",
            sql_pattern="SELECT id, username, email, created_at FROM users WHERE id = :user_id LIMIT 1",
            parameters=[
                ToolParameter(name="user_id", type="integer", description="User ID", required=True),
            ],
            allowed_databases=["primary", "secondary"],
            read_only=True,
            max_rows=1,
        ))

        # Template 2: List users with pagination
        self.register(SQLTemplate(
            template_id="user.list",
            description="List users with pagination",
            sql_pattern="""
                SELECT id, username, email, created_at 
                FROM users 
                WHERE (:status IS NULL OR status = :status)
                ORDER BY created_at DESC 
                LIMIT :limit OFFSET :offset
            """,
            parameters=[
                ToolParameter(name="status", type="string", description="User status filter", required=False, default=None),
                ToolParameter(name="limit", type="integer", description="Number of records", required=True),
                ToolParameter(name="offset", type="integer", description="Offset for pagination", required=True),
            ],
            allowed_databases=["primary", "secondary"],
            read_only=True,
            max_rows=100,
        ))

        # Template 3: Count users
        self.register(SQLTemplate(
            template_id="user.count",
            description="Count total users",
            sql_pattern="SELECT COUNT(*) as total FROM users WHERE (:status IS NULL OR status = :status)",
            parameters=[
                ToolParameter(name="status", type="string", description="User status filter", required=False, default=None),
            ],
            allowed_databases=["primary", "secondary"],
            read_only=True,
            max_rows=1,
        ))

        # Template 4: Search users
        self.register(SQLTemplate(
            template_id="user.search",
            description="Search users by username or email",
            sql_pattern="""
                SELECT id, username, email, created_at 
                FROM users 
                WHERE username ILIKE :search_pattern OR email ILIKE :search_pattern
                LIMIT :limit
            """,
            parameters=[
                ToolParameter(name="search_term", type="string", description="Search term", required=True),
                ToolParameter(name="limit", type="integer", description="Max results", required=False, default=10),
            ],
            allowed_databases=["primary", "secondary"],
            read_only=True,
            max_rows=50,
        ))

        # Template 5: Analytics - daily active users
        self.register(SQLTemplate(
            template_id="analytics.dau",
            description="Get daily active users for date range",
            sql_pattern="""
                SELECT 
                    DATE(login_time) as date,
                    COUNT(DISTINCT user_id) as dau
                FROM user_logins
                WHERE login_time BETWEEN :start_date AND :end_date
                GROUP BY DATE(login_time)
                ORDER BY date
            """,
            parameters=[
                ToolParameter(name="start_date", type="string", description="Start date (YYYY-MM-DD)", required=True),
                ToolParameter(name="end_date", type="string", description="End date (YYYY-MM-DD)", required=True),
            ],
            allowed_databases=["opengauss"],
            read_only=True,
            max_rows=365,
        ))

        # Template 6: Analytics - user retention
        self.register(SQLTemplate(
            template_id="analytics.retention",
            description="Get user retention cohort analysis",
            sql_pattern="""
                SELECT 
                    cohort_date,
                    total_users,
                    day_1_retention,
                    day_7_retention,
                    day_30_retention
                FROM retention_cohorts
                WHERE cohort_date BETWEEN :start_date AND :end_date
                ORDER BY cohort_date DESC
            """,
            parameters=[
                ToolParameter(name="start_date", type="string", description="Start date", required=True),
                ToolParameter(name="end_date", type="string", description="End date", required=True),
            ],
            allowed_databases=["opengauss"],
            read_only=True,
            max_rows=100,
        ))

        logger.info("sql_templates_registered", count=len(self._templates))

    def register(self, template: SQLTemplate) -> None:
        """Register a new SQL template."""
        self._templates[template.template_id] = template

    def get(self, template_id: str) -> Optional[SQLTemplate]:
        """Get template by ID."""
        return self._templates.get(template_id)

    def list_templates(self) -> List[SQLTemplate]:
        """List all registered templates."""
        return list(self._templates.values())

    def get_for_database(self, database: str) -> List[SQLTemplate]:
        """Get templates allowed for a specific database."""
        return [
            t for t in self._templates.values()
            if database in t.allowed_databases
        ]

    def validate_parameters(self, template_id: str, params: Dict[str, Any]) -> tuple[bool, str]:
        """Validate parameters against template schema.

        Returns:
            (is_valid, error_message)
        """
        template = self.get(template_id)
        if not template:
            return False, f"Unknown template: {template_id}"

        # Check required parameters
        for param in template.parameters:
            if param.required and param.name not in params:
                return False, f"Missing required parameter: {param.name}"

        # Validate parameter types
        for param in template.parameters:
            if param.name in params:
                value = params[param.name]
                if param.type == "integer" and not isinstance(value, int):
                    try:
                        params[param.name] = int(value)
                    except (ValueError, TypeError):
                        return False, f"Parameter {param.name} must be integer"
                elif param.type == "string" and not isinstance(value, str):
                    params[param.name] = str(value)

        return True, ""

    def render(self, template_id: str, params: Dict[str, Any]) -> tuple[str, tuple]:
        """Render SQL template with parameter binding.

        Returns:
            (sql_string, bound_parameters_tuple)

        IMPORTANT: This returns a parameterized query, not a formatted string.
        Parameters are bound separately to prevent SQL injection.
        """
        template = self.get(template_id)
        if not template:
            raise ValueError(f"Unknown template: {template_id}")

        sql = template.sql_pattern
        bound_params = []

        # Replace named parameters with positional parameters
        # and collect values in order
        param_pattern = re.compile(r":(\w+)")

        def replace_param(match):
            param_name = match.group(1)
            if param_name in params:
                bound_params.append(params[param_name])
                return f"${len(bound_params)}"
            elif any(p.name == param_name and p.default is not None for p in template.parameters):
                default = next(p.default for p in template.parameters if p.name == param_name)
                bound_params.append(default)
                return f"${len(bound_params)}"
            else:
                raise ValueError(f"Missing parameter: {param_name}")

        rendered_sql = param_pattern.sub(replace_param, sql)

        # Add LIMIT if not present and max_rows is set
        if template.max_rows and "LIMIT" not in rendered_sql.upper():
            rendered_sql = rendered_sql.strip().rstrip(";")
            rendered_sql += f" LIMIT {template.max_rows}"

        return rendered_sql, tuple(bound_params)


# Singleton
_registry: Optional[SQLTemplateRegistry] = None


def get_sql_registry() -> SQLTemplateRegistry:
    """Get SQL template registry singleton."""
    global _registry
    if _registry is None:
        _registry = SQLTemplateRegistry()
    return _registry
