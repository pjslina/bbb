"""Core module for agent platform."""
