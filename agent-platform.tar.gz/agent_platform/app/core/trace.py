"""Distributed tracing with OpenTelemetry.

Provides automatic trace propagation, span creation,
and integration with FastAPI middleware.
"""

from contextlib import contextmanager
from typing import Any, Dict, Optional, Generator

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.resources import Resource, SERVICE_NAME
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.trace import Status, StatusCode

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

# Global tracer provider
tracer_provider: Optional[TracerProvider] = None


def setup_tracing() -> TracerProvider:
    """Initialize OpenTelemetry tracing."""
    global tracer_provider

    if tracer_provider is not None:
        return tracer_provider

    resource = Resource.create({
        SERVICE_NAME: settings.app_name,
        "deployment.environment": settings.app_env,
    })

    provider = TracerProvider(resource=resource)

    if settings.observability.tracing_enabled:
        try:
            exporter = OTLPSpanExporter(
                endpoint=settings.observability.tracing_endpoint,
                insecure=True,
            )
            processor = BatchSpanProcessor(
                exporter,
                max_queue_size=2048,
                max_export_batch_size=512,
                schedule_delay_millis=5000,
            )
            provider.add_span_processor(processor)
            logger.info("tracing_initialized", endpoint=settings.observability.tracing_endpoint)
        except Exception as e:
            logger.warning("tracing_init_failed", error=str(e))

    trace.set_tracer_provider(provider)
    tracer_provider = provider
    return provider


def get_tracer(name: str = __name__) -> trace.Tracer:
    """Get a tracer instance."""
    return trace.get_tracer(name)


@contextmanager
def create_span(
    name: str,
    attributes: Optional[Dict[str, Any]] = None,
    kind: trace.SpanKind = trace.SpanKind.INTERNAL,
) -> Generator[trace.Span, None, None]:
    """Create a trace span context manager."""
    tracer = get_tracer()
    with tracer.start_as_current_span(name, kind=kind) as span:
        if attributes:
            for key, value in attributes.items():
                span.set_attribute(key, value)
        try:
            yield span
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            raise


class TraceMixin:
    """Mixin class for adding tracing to any component."""

    def __init__(self):
        self._tracer = get_tracer(self.__class__.__name__)

    @contextmanager
    def trace(self, name: str, **attributes: Any):
        """Create a traced operation."""
        with self._tracer.start_as_current_span(name) as span:
            for key, value in attributes.items():
                span.set_attribute(key, value)
            try:
                yield span
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                raise
