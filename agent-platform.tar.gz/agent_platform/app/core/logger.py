"""Structured logging with OpenTelemetry integration.

Production-grade logging with JSON output, correlation IDs,
and automatic trace context injection.
"""

import logging
import sys
import uuid
from contextvars import ContextVar
from typing import Any, Dict, Optional

import structlog
from structlog.processors import TimeStamper, JSONRenderer

from app.core.config import settings

# Context variable for request correlation ID
request_id: ContextVar[str] = ContextVar("request_id", default="")


def get_request_id() -> str:
    """Get current request correlation ID."""
    rid = request_id.get()
    if not rid:
        rid = str(uuid.uuid4())
        request_id.set(rid)
    return rid


def set_request_id(rid: str) -> None:
    """Set request correlation ID."""
    request_id.set(rid)


class RequestIdFilter(logging.Filter):
    """Inject request_id into log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = get_request_id()
        return True


def setup_logging() -> None:
    """Configure structured logging for production."""
    log_level = getattr(logging, settings.observability.log_level.upper(), logging.INFO)

    # Configure standard library logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=log_level,
    )

    # Add request ID filter to root logger
    root_logger = logging.getLogger()
    root_logger.addFilter(RequestIdFilter())

    # Configure structlog
    shared_processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.stdlib.ExtraAdder(),
    ]

    if settings.observability.log_format == "json":
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    structlog.configure(
        processors=shared_processors + [
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            renderer,
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Get a structured logger instance."""
    logger = structlog.get_logger(name)
    return logger.bind(request_id=get_request_id())


class LogContext:
    """Context manager for adding structured fields to logs."""

    def __init__(self, **kwargs: Any):
        self.kwargs = kwargs
        self.token = None

    def __enter__(self):
        self.token = structlog.contextvars.bind_contextvars(**self.kwargs)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token:
            structlog.contextvars.reset_contextvars(self.token)
        return False
