"""Application configuration management.

Supports environment variables, .env files, and YAML config.
Uses pydantic-settings for validation and type safety.
"""

import os
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Any

import yaml
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class LLMConfig(BaseSettings):
    """LLM provider configuration."""
    provider: str = "qwen"
    base_url: str = ""
    api_key: str = ""
    model: str = "qwen-max"
    max_tokens: int = 4096
    temperature: float = 0.7
    timeout: int = 60
    retry_attempts: int = 3


class DatabasePoolConfig(BaseSettings):
    """Database connection pool configuration."""
    driver: str = "postgresql"
    host: str = "localhost"
    port: int = 5432
    database: str = "agent_db"
    user: str = "agent_user"
    password: str = ""
    pool_size: int = 20
    max_overflow: int = 10
    pool_timeout: int = 30
    pool_recycle: int = 3600


class MemoryConfig(BaseSettings):
    """Memory and conversation configuration."""
    max_history: int = 20
    summary_threshold: int = 10
    token_limit: int = 4000
    compression_ratio: float = 0.5
    session_ttl: int = 86400
    key_prefix: str = "agent:session"


class AgentConfig(BaseSettings):
    """Agent behavior configuration."""
    max_iterations: int = 10
    timeout: int = 120
    max_tool_calls: int = 5
    max_tokens_per_conversation: int = 8000


class RedisConfig(BaseSettings):
    """Redis configuration."""
    url: str = "redis://localhost:6379/0"
    password: Optional[str] = None
    max_connections: int = 50
    socket_timeout: int = 5
    socket_connect_timeout: int = 5


class ObservabilityConfig(BaseSettings):
    """Observability configuration."""
    tracing_enabled: bool = True
    tracing_endpoint: str = "http://localhost:4317"
    sample_rate: float = 1.0
    metrics_enabled: bool = True
    metrics_port: int = 9090
    log_level: str = "INFO"
    log_format: str = "json"


class Settings(BaseSettings):
    """Application settings."""
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # Application
    app_name: str = "agent-platform"
    app_env: str = "production"
    debug: bool = False

    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4
    cors_origins: List[str] = Field(default_factory=lambda: ["*"])

    # LLM
    llm_primary: LLMConfig = Field(default_factory=LLMConfig)
    llm_fallback: LLMConfig = Field(default_factory=LLMConfig)

    # Agent
    agent: AgentConfig = Field(default_factory=AgentConfig)

    # Database
    db_query_timeout: int = 30
    db_max_query_rows: int = 1000
    db_pools: Dict[str, DatabasePoolConfig] = Field(default_factory=dict)

    # Memory
    memory: MemoryConfig = Field(default_factory=MemoryConfig)

    # Redis
    redis: RedisConfig = Field(default_factory=RedisConfig)

    # Observability
    observability: ObservabilityConfig = Field(default_factory=ObservabilityConfig)

    @field_validator("cors_origins", mode="before")
    @classmethod
    def parse_cors_origins(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(",")]
        return v


def load_yaml_config(path: str = "config.yaml") -> Dict[str, Any]:
    """Load YAML configuration file."""
    config_path = Path(path)
    if not config_path.exists():
        return {}

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    # Expand environment variables
    def expand_env_vars(obj):
        if isinstance(obj, dict):
            return {k: expand_env_vars(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [expand_env_vars(v) for v in obj]
        elif isinstance(obj, str):
            return os.path.expandvars(obj)
        return obj

    return expand_env_vars(config)


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    yaml_config = load_yaml_config()

    # Build settings from environment and YAML
    settings = Settings()

    # Override with YAML config if present
    if yaml_config:
        if "app" in yaml_config:
            app_cfg = yaml_config["app"]
            if "name" in app_cfg:
                settings.app_name = app_cfg["name"]

        if "llm" in yaml_config:
            llm_cfg = yaml_config["llm"]
            if "primary" in llm_cfg:
                settings.llm_primary = LLMConfig(**llm_cfg["primary"])
            if "fallback" in llm_cfg:
                settings.llm_fallback = LLMConfig(**llm_cfg["fallback"])

        if "agent" in yaml_config:
            settings.agent = AgentConfig(**yaml_config["agent"])

        if "database" in yaml_config and "pools" in yaml_config["database"]:
            pools = {}
            for name, cfg in yaml_config["database"]["pools"].items():
                pools[name] = DatabasePoolConfig(**cfg)
            settings.db_pools = pools

        if "memory" in yaml_config:
            mem_cfg = yaml_config["memory"]
            if "redis" in mem_cfg:
                settings.redis = RedisConfig(**mem_cfg["redis"])
            if "conversation" in mem_cfg:
                settings.memory = MemoryConfig(**mem_cfg["conversation"])

        if "observability" in yaml_config:
            obs_cfg = yaml_config["observability"]
            settings.observability = ObservabilityConfig(**obs_cfg)

    return settings


settings = get_settings()
