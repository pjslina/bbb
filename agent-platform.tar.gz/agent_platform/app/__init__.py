"""Agent Platform - Production-grade AI Agent Application.

Features:
- Dual streaming (SSE + WebSocket)
- LangGraph stateful execution
- Multi-database support (PostgreSQL, OpenGauss)
- Redis-based conversation memory
- Tool system with schema validation
- LLM fallback (Qwen / GLM)
- Full observability with OpenTelemetry
"""

__version__ = "1.0.0"
