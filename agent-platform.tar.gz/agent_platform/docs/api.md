# API Documentation

## Endpoints

### POST /api/v1/chat
Chat endpoint with optional streaming.

**Request Body:**
```json
{
  "session_id": "optional-session-id",
  "message": "Your message here",
  "context": {},
  "stream": true
}
```

**Response (non-streaming):**
```json
{
  "session_id": "session-id",
  "response": "Assistant response",
  "intent": "general_query",
  "tools_used": [],
  "execution_time_ms": 1234
}
```

**Response (streaming - SSE):**
```
data: {"event_type": "start", "data": {"session_id": "..."}}
data: {"event_type": "intent", "data": {"intent": "data_query", "confidence": 0.95}}
data: {"event_type": "tool_decision", "data": {"use_tool": true}}
data: {"event_type": "tool_result", "data": {"tools": ["db_query"], "results": [...]}}
data: {"event_type": "chunk", "data": {"content": "Based on..."}}
data: {"event_type": "complete", "data": {"response": "...", "tokens": 150}}
data: {"event_type": "end", "data": {"status": "completed"}}
```

### WebSocket /ws/chat
Bidirectional streaming chat.

**Send:**
```json
{
  "session_id": "session-id",
  "message": "Your message",
  "context": {}
}
```

**Receive:** Same event format as SSE.

### GET /api/v1/health
Health check endpoint.

**Response:**
```json
{
  "status": "healthy",
  "version": "agent-platform",
  "components": {
    "db_primary": "healthy",
    "db_secondary": "healthy",
    "db_opengauss": "healthy",
    "tools": "6/6 enabled"
  },
  "timestamp": "2024-01-01T00:00:00"
}
```

### DELETE /api/v1/sessions/{session_id}
Clear a conversation session.

### GET /api/v1/sessions/{session_id}/stats
Get session statistics.

### GET /api/v1/tools
List available tools.

### GET /api/v1/templates
List available SQL templates.

## Streaming Events

| Event Type | Description | Node |
|-----------|-------------|------|
| start | Execution started | start |
| intent | Intent recognized | intent_recognition |
| tool_decision | Tool usage decision | tool_decision |
| tool_result | Tool execution result | tool_execution |
| chunk | LLM response chunk | llm_response |
| complete | Final response | llm_response |
| error | Error occurred | any |
| end | Execution completed | end |
