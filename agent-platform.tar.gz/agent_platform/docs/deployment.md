# Deployment Guide

## Prerequisites

- Docker & Docker Compose
- LLM API keys (Qwen / GLM)

## Quick Start

### 1. Clone and Configure

```bash
cd agent-platform
cp .env.example .env
# Edit .env with your API keys
```

### 2. Start Services

```bash
docker-compose up -d
```

This starts:
- Agent Platform (port 8000)
- Redis (port 6379)
- PostgreSQL Primary (port 5432)
- PostgreSQL Secondary (port 5433)
- OpenGauss (port 5434)

### 3. Verify

```bash
curl http://localhost:8000/api/v1/health
```

### 4. Test Chat

```bash
# Non-streaming
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, how many users are there?", "stream": false}'

# Streaming (SSE)
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello", "stream": true}'
```

## Production Deployment

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| LLM_BASE_URL | Primary LLM API URL | - |
| LLM_API_KEY | Primary LLM API key | - |
| LLM_MODEL | Primary model name | qwen-max |
| LLM_FALLBACK_BASE_URL | Fallback LLM URL | - |
| LLM_FALLBACK_API_KEY | Fallback API key | - |
| REDIS_URL | Redis connection URL | redis://localhost:6379/0 |
| DB_PRIMARY_HOST | Primary DB host | localhost |
| DB_PRIMARY_PORT | Primary DB port | 5432 |
| AGENT_MAX_ITERATIONS | Max agent iterations | 10 |
| AGENT_TIMEOUT | Agent timeout (seconds) | 120 |
| AGENT_MAX_TOOL_CALLS | Max tool calls | 5 |

### Scaling

```bash
# Scale workers
docker-compose up -d --scale agent-platform=3

# Or use Kubernetes
kubectl apply -f deploy/k8s/
```

### Monitoring (Optional)

```bash
# Start with monitoring stack
docker-compose --profile monitoring up -d

# Access:
# - Prometheus: http://localhost:9090
# - Jaeger: http://localhost:16686
```

## Database Setup

### PostgreSQL

```sql
-- Create user
CREATE USER agent_user WITH PASSWORD 'agent_pass';

-- Create database
CREATE DATABASE agent_db OWNER agent_user;

-- Grant permissions
GRANT ALL PRIVILEGES ON DATABASE agent_db TO agent_user;
```

### OpenGauss

```sql
-- Create user
CREATE USER gauss_user WITH PASSWORD 'gauss_pass';

-- Create database
CREATE DATABASE analytics_db OWNER gauss_user;

-- Grant permissions
GRANT ALL PRIVILEGES ON DATABASE analytics_db TO gauss_user;
```

## Troubleshooting

### Connection Issues

```bash
# Check database connectivity
docker-compose exec agent-platform python -c "
import asyncio
from app.db.pool import get_pool_manager
async def test():
    pm = await get_pool_manager()
    print(await pm.health_check_all())
asyncio.run(test())
"
```

### Redis Issues

```bash
# Check Redis
docker-compose exec redis redis-cli ping
```

### LLM Issues

Check logs:
```bash
docker-compose logs -f agent-platform
```
