# Agent Platform Architecture

## Overview

Production-grade single-agent platform built with FastAPI, LangGraph, and OpenAI-compatible LLMs.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        Client Layer                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │   REST API  │  │  SSE Stream │  │    WebSocket            │ │
│  │  /api/v1/*  │  │  /chat      │  │    /ws/chat             │ │
│  └──────┬──────┘  └──────┬──────┘  └───────────┬─────────────┘ │
│         └─────────────────┴─────────────────────┘               │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                      FastAPI Application                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │   CORS      │  │   GZip      │  │  Request ID / Trace     │ │
│  │ Middleware  │  │ Middleware  │  │  Middleware             │ │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                    Agent Execution Layer                         │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              LangGraph StateGraph                          │   │
│  │                                                            │   │
│  │   start → intent_recognition → tool_decision              │   │
│  │                                      │                    │   │
│  │                    ┌─────────────────┘                    │   │
│  │                    ▼                                      │   │
│  │         ┌─────────────────┐                             │   │
│  │         │  needs_tool?    │                             │   │
│  │         └────────┬────────┘                             │   │
│  │                  │                                      │   │
│  │      ┌───────────┴───────────┐                         │   │
│  │      ▼                       ▼                         │   │
│  │ tool_execution ──────→ llm_response                    │   │
│  │                              │                         │   │
│  │                              ▼                         │   │
│  │                        memory_update                     │   │
│  │                              │                         │   │
│  │                              ▼                         │   │
│  │                             end                         │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Guardrails: max_iterations | timeout | max_tool_calls | tokens │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                      Service Layer                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │    LLM      │  │   Memory    │  │    Tools                │ │
│  │  Client     │  │  Manager    │  │  Registry / Router      │ │
│  │ (Qwen/GLM)  │  │  (Redis)    │  │                         │ │
│  └──────┬──────┘  └──────┬──────┘  └───────────┬─────────────┘ │
└─────────┼────────────────┼─────────────────────┼───────────────┘
          │                │                     │
┌─────────┼────────────────┼─────────────────────┼───────────────┐
│         ▼                ▼                     ▼                │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │  LLM APIs   │  │   Redis     │  │  Database / API Tools   │ │
│  │  (OpenAI)   │  │   Cluster   │  │                         │ │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. Streaming Layer
- **SSE**: Server-Sent Events for unidirectional streaming
- **WebSocket**: Bidirectional real-time communication
- **UnifiedStream**: Common interface abstracting both protocols

### 2. Agent Graph (LangGraph)
- **StateGraph**: Typed state machine with checkpointing
- **Nodes**: Pure functions (start, intent, tool_decision, tool_execution, llm_response, memory_update, end)
- **Edges**: Conditional routing based on state
- **Guardrails**: Iteration limits, timeouts, token budgets

### 3. Memory System
- **Redis Store**: Async connection pooling, TTL management
- **Compressor**: Token-based truncation + LLM summarization
- **Session Management**: Auto-load history, append context

### 4. Database Layer
- **Pool Manager**: Multiple asyncpg pools (primary, secondary, opengauss)
- **Router**: Dynamic routing by scenario and query type
- **SQL Templates**: Predefined safe queries with parameter binding
- **Security**: LLM never constructs raw SQL

### 5. Tool System
- **Registry**: Hot-pluggable tool registration
- **Router**: Intent-based + LLM-based tool selection
- **Types**: Database, API, Calculation, Search
- **Execution**: Async with concurrency control and timeout

### 6. LLM Client
- **Unified Interface**: OpenAI-compatible API
- **Fallback**: Primary (Qwen) → Secondary (GLM)
- **Circuit Breaker**: Automatic failover on failures
- **Retry**: Exponential backoff with jitter

### 7. Observability
- **Structured Logging**: JSON format with correlation IDs
- **OpenTelemetry**: Distributed tracing with OTLP export
- **Metrics**: Prometheus-compatible (optional)
- **Health Checks**: Component-level status reporting

## Data Flow

### Chat Request (SSE)
1. Client POST /api/v1/chat with message
2. FastAPI creates SSE stream
3. Agent graph executes asynchronously
4. Each node emits events to stream
5. Client receives real-time updates
6. Final response delivered via SSE

### Chat Request (WebSocket)
1. Client connects to /ws/chat
2. Sends JSON message
3. Agent executes and streams events back
4. Connection stays open for multi-turn

### Database Query
1. Intent recognized as DATA_QUERY
2. Tool router selects SQL template
3. LLM extracts parameters from message
4. SQL template rendered with parameter binding
5. Database router selects pool
6. Query executed via asyncpg pool
7. Results returned to LLM for response generation

## Security Considerations

1. **SQL Injection Prevention**: Parameter binding only, no string interpolation
2. **Content Safety**: Dangerous pattern detection in inputs
3. **Rate Limiting**: Tool call limits and iteration caps
4. **Timeout Protection**: All operations have timeouts
5. **Read-Only Enforcement**: Templates enforce read-only where applicable

## Scalability

- **Stateless Design**: Session state in Redis
- **Connection Pooling**: Database and Redis pools
- **Async Everything**: Non-blocking I/O throughout
- **Horizontal Scaling**: Multiple worker processes
- **Load Balancing**: Read replicas for query distribution
