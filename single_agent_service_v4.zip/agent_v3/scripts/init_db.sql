-- ================================================================
-- Single Agent Service — 数据库初始化脚本
-- 适用于 PostgreSQL 14+ 和 OpenGauss 3.x
-- ================================================================

-- ── 用户表 ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          BIGSERIAL    PRIMARY KEY,
    username    VARCHAR(64)  NOT NULL UNIQUE,
    email       VARCHAR(256) NOT NULL UNIQUE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ── 商品表 ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
    id              BIGSERIAL       PRIMARY KEY,
    name            VARCHAR(256)    NOT NULL,
    price           NUMERIC(12, 2)  NOT NULL,
    stock_quantity  INTEGER         NOT NULL DEFAULT 0,
    category        VARCHAR(64),
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- ── 订单表 ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
    id              BIGSERIAL       PRIMARY KEY,
    user_id         BIGINT          NOT NULL REFERENCES users(id),
    status          VARCHAR(32)     NOT NULL DEFAULT 'pending',
    total_amount    NUMERIC(12, 2)  NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
    id          BIGSERIAL       PRIMARY KEY,
    order_id    BIGINT          NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id  BIGINT          NOT NULL REFERENCES products(id),
    quantity    INTEGER         NOT NULL,
    unit_price  NUMERIC(12, 2)  NOT NULL
);

-- ── 大米库存表（大米管理场景）───────────────────────────────────
-- 每个用户一条记录，记录当前库存、阈值、最近购买信息
CREATE TABLE IF NOT EXISTS rice_inventory (
    id                    BIGSERIAL       PRIMARY KEY,
    user_id               VARCHAR(128)    NOT NULL UNIQUE,   -- 支持字符串用户ID
    stock_kg              NUMERIC(8, 2)   NOT NULL DEFAULT 0,
    threshold_kg          NUMERIC(8, 2)   NOT NULL DEFAULT 5, -- 低于此值触发补货提醒
    last_purchased_at     TIMESTAMPTZ,
    last_purchase_qty_kg  NUMERIC(8, 2),
    last_order_id         VARCHAR(64),
    created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- ── 大米购买日志表 ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rice_purchase_logs (
    id            BIGSERIAL       PRIMARY KEY,
    user_id       VARCHAR(128)    NOT NULL,
    order_id      VARCHAR(64)     NOT NULL UNIQUE,
    qty_kg        NUMERIC(8, 2)   NOT NULL,
    price_yuan    NUMERIC(10, 2)  NOT NULL,
    purchased_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    source        VARCHAR(32)     NOT NULL DEFAULT 'manual'  -- manual | auto_purchase
);

-- ── 索引 ─────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_orders_user_id        ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status         ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at     ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_products_category     ON products(category);
CREATE INDEX IF NOT EXISTS idx_rice_inventory_user   ON rice_inventory(user_id);
CREATE INDEX IF NOT EXISTS idx_rice_logs_user        ON rice_purchase_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_rice_logs_purchased   ON rice_purchase_logs(purchased_at DESC);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id  ON order_items(order_id);

-- ── 种子数据 ─────────────────────────────────────────────────────
INSERT INTO users (username, email) VALUES
    ('alice', 'alice@example.com'),
    ('bob',   'bob@example.com')
ON CONFLICT DO NOTHING;

INSERT INTO products (name, price, stock_quantity, category) VALUES
    ('Widget Pro',  29.99, 100, 'electronics'),
    ('Gadget Plus', 49.99,  50, 'electronics'),
    ('Gizmo Basic',  9.99, 200, 'accessories')
ON CONFLICT DO NOTHING;

-- 用户 alice 的大米库存（库存充足示例）
INSERT INTO rice_inventory (user_id, stock_kg, threshold_kg) VALUES
    ('alice', 8.5, 5.0)
ON CONFLICT (user_id) DO NOTHING;

-- 用户 bob 的大米库存（库存不足示例，触发补货场景）
INSERT INTO rice_inventory (user_id, stock_kg, threshold_kg) VALUES
    ('bob', 2.0, 5.0)
ON CONFLICT (user_id) DO NOTHING;
