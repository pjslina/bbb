#!/usr/bin/env bash
# ================================================================
# 生产模式启动脚本（Gunicorn + Uvicorn workers）
# ================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_ROOT"

WORKERS="${WORKERS:-4}"
HOST="${APP_HOST:-0.0.0.0}"
PORT="${APP_PORT:-8000}"

echo "[INFO] 启动生产服务器 (workers=${WORKERS} host=${HOST} port=${PORT})"
exec gunicorn app.main:app \
    --worker-class uvicorn.workers.UvicornWorker \
    --workers        "$WORKERS" \
    --bind           "${HOST}:${PORT}" \
    --timeout        180 \
    --graceful-timeout 30 \
    --keep-alive     5 \
    --access-logfile - \
    --error-logfile  -
