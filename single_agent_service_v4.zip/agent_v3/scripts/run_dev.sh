#!/usr/bin/env bash
# ================================================================
# 开发模式启动脚本（热重载）
# ================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_ROOT"

# 加载 .env
if [ -f ".env" ]; then
    echo "[INFO] 加载 .env 配置"
    set -a; source .env; set +a
fi

# 检查依赖
if ! python -c "import fastapi" 2>/dev/null; then
    echo "[ERROR] 依赖未安装，请先执行: pip install -r requirements.txt"
    exit 1
fi

echo "[INFO] 启动开发服务器 (host=${APP_HOST:-0.0.0.0} port=${APP_PORT:-8000})"
exec uvicorn app.main:app \
    --host "${APP_HOST:-0.0.0.0}" \
    --port "${APP_PORT:-8000}" \
    --reload \
    --reload-dir app \
    --log-level "${LOG_LEVEL:-debug}" \
    --workers 1
