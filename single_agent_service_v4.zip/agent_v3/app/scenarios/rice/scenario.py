"""
大米库存管理场景（Rice Inventory Management）

支持的用户问题类型：
  - "家里还有多少大米？"
  - "大米快没了吗，要不要买？"
  - "帮我买10公斤大米"
  - "上次我是什么时候买大米的？"

调用链路（库存不足时）：
  query_rice_inventory → purchase_rice → update_rice_stock

调用链路（库存充足时）：
  query_rice_inventory → llm_answer（直接告知用户）
"""
from __future__ import annotations
from app.scenarios.base import BaseScenario
from app.scenarios.rice.tools import (
    PurchaseRiceTool,
    QueryRiceInventoryTool,
    UpdateRiceStockTool,
)
from app.tools.base import BaseTool


class RiceInventoryScenario(BaseScenario):

    @property
    def name(self) -> str:
        return "rice_inventory"

    @property
    def description(self) -> str:
        return (
            "大米库存管理：查询家中大米存量、判断是否需要补货、"
            "自动购买大米并更新库存记录。"
        )

    @property
    def intent_labels(self) -> list[str]:
        return [
            "rice_inventory_query",     # 查询库存
            "rice_purchase_decision",   # 询问要不要买
            "rice_purchase_direct",     # 直接要求购买
            "rice_history_query",       # 查购买历史
        ]

    @property
    def tools(self) -> list[BaseTool]:
        return [
            QueryRiceInventoryTool(),
            PurchaseRiceTool(),
            UpdateRiceStockTool(),
        ]

    @property
    def system_prompt_extra(self) -> str:
        return """
【大米场景专属规则】
1. 必须先调用 query_rice_inventory 查询当前库存，不得跳过
2. 仅当 needs_purchase=true（库存低于阈值）时，才调用 purchase_rice
3. purchase_rice 成功后（success=true），必须调用 update_rice_stock 更新库存
4. 用户未明确要求购买时，库存不足应先询问确认，不要直接购买
5. 向用户展示结果时，用自然语言（不要暴露数据库字段名）
"""
