"""
大米库存管理场景 — 工具集

工具列表：
  1. QueryRiceInventoryTool   — 查询库存（读DB）
  2. PurchaseRiceTool         — 购买大米（调外部API）
  3. UpdateRiceStockTool      — 更新库存（写DB）

这三个工具构成完整的"读→判断→写"链路。
LLM 在 tool_router 中根据已有结果决定下一步调用哪个。
"""
from __future__ import annotations

import os
from typing import Any

import httpx

from app.core.exceptions import ToolExecutionError
from app.core.logging import get_logger
from app.db.query import execute_template
from app.tools.base import BaseTool

logger = get_logger(__name__)

RICE_SHOP_API_URL = os.getenv("RICE_SHOP_API_URL", "https://api.example-shop.com/v1/purchase")
RICE_SHOP_API_KEY = os.getenv("RICE_SHOP_API_KEY", "")


# ===========================================================================
# 1. 查询大米库存（读DB）
# ===========================================================================
class QueryRiceInventoryTool(BaseTool):
    """
    查询用户的大米库存。
    返回：剩余数量(kg)、购买阈值(kg)、上次购买时间等。
    """

    @property
    def name(self) -> str:
        return "query_rice_inventory"

    @property
    def description(self) -> str:
        return "查询家中大米的剩余库存数量、历史购买记录，以及建议的补货阈值。"

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {
                            "type": "string",
                            "description": "用户ID，从会话上下文中获取",
                        }
                    },
                    "required": ["user_id"],
                },
            },
        }

    async def execute(self, user_id: str, **_: Any) -> dict[str, Any]:
        rows = await execute_template("query_rice_inventory", {"user_id": user_id})
        if not rows:
            # 用户没有库存记录，返回默认值
            return {
                "user_id": user_id,
                "stock_kg": 0.0,
                "threshold_kg": 5.0,
                "last_purchased_at": None,
                "status": "no_record",
                "needs_purchase": True,
            }
        row = rows[0]
        stock = float(row.get("stock_kg", 0))
        threshold = float(row.get("threshold_kg", 5.0))
        return {
            "user_id": user_id,
            "stock_kg": stock,
            "threshold_kg": threshold,
            "last_purchased_at": str(row.get("last_purchased_at", "")),
            "last_purchase_qty_kg": float(row.get("last_purchase_qty_kg") or 0),
            "needs_purchase": stock < threshold,
            "status": "sufficient" if stock >= threshold else "low",
            "days_remaining_estimate": round(stock / 0.5, 1) if stock > 0 else 0,  # 按0.5kg/天估算
        }


# ===========================================================================
# 2. 购买大米（调外部API）
# ===========================================================================
class PurchaseRiceTool(BaseTool):
    """
    通过电商平台API购买大米。
    只在库存不足时调用（tool_router 根据 QueryRiceInventoryTool 的结果决定）。
    """

    @property
    def name(self) -> str:
        return "purchase_rice"

    @property
    def description(self) -> str:
        return "通过电商平台API购买指定数量的大米，返回订单ID和实际购买数量。"

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {
                            "type": "string",
                            "description": "用户ID",
                        },
                        "qty_kg": {
                            "type": "number",
                            "description": "购买数量（公斤），默认10kg",
                            "default": 10,
                        },
                        "brand": {
                            "type": "string",
                            "description": "大米品牌，如'东北五常大米'，不指定则由平台推荐",
                        },
                        "max_price_yuan": {
                            "type": "number",
                            "description": "每公斤最高单价（元），用于控制预算",
                        },
                    },
                    "required": ["user_id"],
                },
            },
        }

    async def execute(
        self,
        user_id: str,
        qty_kg: float = 10.0,
        brand: str | None = None,
        max_price_yuan: float | None = None,
        **_: Any,
    ) -> dict[str, Any]:
        logger.info("PurchaseRiceTool called", user_id=user_id, qty_kg=qty_kg)

        if RICE_SHOP_API_KEY:
            return await self._call_real_api(user_id, qty_kg, brand, max_price_yuan)
        else:
            return self._mock_purchase(user_id, qty_kg, brand)

    async def _call_real_api(
        self,
        user_id: str,
        qty_kg: float,
        brand: str | None,
        max_price: float | None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "user_id": user_id,
            "item_type": "rice",
            "qty_kg": qty_kg,
        }
        if brand:
            payload["brand"] = brand
        if max_price:
            payload["max_unit_price"] = max_price

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(
                    RICE_SHOP_API_URL,
                    json=payload,
                    headers={"X-API-Key": RICE_SHOP_API_KEY},
                )
                resp.raise_for_status()
                data = resp.json()
                return {
                    "success": True,
                    "order_id": data["order_id"],
                    "qty_kg": data["actual_qty_kg"],
                    "price_yuan": data["total_price_yuan"],
                    "brand": data.get("brand", ""),
                    "estimated_delivery": data.get("estimated_delivery", ""),
                }
        except Exception as exc:
            raise ToolExecutionError(self.name, f"购买API调用失败: {exc}") from exc

    @staticmethod
    def _mock_purchase(user_id: str, qty_kg: float, brand: str | None) -> dict[str, Any]:
        import uuid
        return {
            "success": True,
            "order_id": f"ORDER-{uuid.uuid4().hex[:8].upper()}",
            "qty_kg": qty_kg,
            "price_yuan": round(qty_kg * 8.5, 2),   # 8.5元/kg
            "brand": brand or "东北五常大米",
            "estimated_delivery": "明天下午",
            "source": "mock",
        }


# ===========================================================================
# 3. 更新大米库存（写DB）
# ===========================================================================
class UpdateRiceStockTool(BaseTool):
    """
    将购买的大米数量更新到数据库库存记录。
    必须在 PurchaseRiceTool 成功执行后调用。
    同时写入购买日志。
    """

    @property
    def name(self) -> str:
        return "update_rice_stock"

    @property
    def description(self) -> str:
        return "购买成功后，更新数据库中的大米库存记录，并写入购买日志。"

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {
                            "type": "string",
                            "description": "用户ID",
                        },
                        "order_id": {
                            "type": "string",
                            "description": "购买订单ID（来自 purchase_rice 的返回值）",
                        },
                        "added_kg": {
                            "type": "number",
                            "description": "本次购买增加的大米数量（kg）",
                        },
                        "price_yuan": {
                            "type": "number",
                            "description": "本次购买总价（元）",
                        },
                    },
                    "required": ["user_id", "order_id", "added_kg", "price_yuan"],
                },
            },
        }

    async def execute(
        self,
        user_id: str,
        order_id: str,
        added_kg: float,
        price_yuan: float,
        **_: Any,
    ) -> dict[str, Any]:
        logger.info(
            "UpdateRiceStockTool called",
            user_id=user_id,
            order_id=order_id,
            added_kg=added_kg,
        )

        # 1. 更新库存
        update_result = await execute_template(
            "update_rice_stock",
            {"user_id": user_id, "added_kg": added_kg, "order_id": order_id},
        )

        # 2. 写入购买日志
        await execute_template(
            "insert_rice_purchase_log",
            {
                "user_id": user_id,
                "order_id": order_id,
                "qty_kg": added_kg,
                "price_yuan": price_yuan,
                "source": "auto_purchase",
            },
        )

        return {
            "success": True,
            "user_id": user_id,
            "order_id": order_id,
            "added_kg": added_kg,
            "affected_rows": update_result.get("affected_rows", 0),
            "message": f"库存已更新，新增 {added_kg}kg 大米",
        }
