"""
场景自动扫描与注册。

规则：
  凡是 app/scenarios/<name>/scenario.py 中存在继承 BaseScenario 的类，
  都会在应用启动时自动发现并注册到 ScenarioRegistry。

新增一个业务场景只需：
  1. 在 app/scenarios/ 下创建子目录（如 flight/）
  2. 创建 tools.py（工具实现）
  3. 创建 scenario.py（继承 BaseScenario 的场景类）
  4. 无需修改任何其他文件

注：需在 app/db/query.py 中添加该场景所需的 SQL 模板（如有DB操作）。
"""
from __future__ import annotations

import importlib
import inspect
import pkgutil
from pathlib import Path

from app.core.logging import get_logger
from app.scenarios.base import BaseScenario, scenario_registry

logger = get_logger(__name__)

_SCENARIOS_PKG = "app.scenarios"
_SCENARIOS_DIR = Path(__file__).parent


def discover_and_register_scenarios() -> None:
    """
    扫描 app/scenarios/ 下所有子包，
    找到每个子包中 scenario.py 里继承 BaseScenario 的类，
    实例化并注册到 scenario_registry。
    """
    registered: list[str] = []

    for finder, pkg_name, is_pkg in pkgutil.iter_modules([str(_SCENARIOS_DIR)]):
        if not is_pkg:
            continue                        # 只处理子包（目录），跳过 base.py / loader.py

        module_path = f"{_SCENARIOS_PKG}.{pkg_name}.scenario"
        try:
            module = importlib.import_module(module_path)
        except ModuleNotFoundError:
            # 该子目录没有 scenario.py，跳过
            continue
        except Exception as exc:
            logger.error("场景模块加载失败", module=module_path, error=str(exc))
            continue

        # 在模块中找 BaseScenario 的具体子类（排除 BaseScenario 自身）
        for _, cls in inspect.getmembers(module, inspect.isclass):
            if (
                issubclass(cls, BaseScenario)
                and cls is not BaseScenario
                and cls.__module__ == module.__name__
            ):
                try:
                    instance = cls()
                    scenario_registry.register(instance)
                    registered.append(instance.name)
                except Exception as exc:
                    logger.error("场景注册失败", cls=cls.__name__, error=str(exc))

    logger.info(
        "场景扫描完成",
        total=len(registered),
        scenarios=registered,
    )
