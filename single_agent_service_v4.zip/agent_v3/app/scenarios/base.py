"""
业务场景（Scenario）系统 — 核心抽象层

解决的问题：
  原代码工具、SQL模板、意图标签全部散落在各处，
  新增一个业务场景（如"大米管理"、"天气+酒店"）需要改多处代码。

解决方案：
  每个业务场景封装为一个 Scenario 类，包含：
  - 该场景的意图标签（告诉意图识别节点识别哪些意图）
  - 该场景注册的工具列表（告诉 tool_router 可用工具）
  - 该场景的系统提示词补充（可覆盖默认prompt）
  - 该场景需要的SQL模板（已在 db/query.py 注册）

  ScenarioRegistry 是所有场景的注册中心：
  - main.py 启动时扫描 scenarios/ 目录，自动注册所有场景
  - intent_recognition 节点从注册表获取全部意图标签
  - tool_router 节点从注册表获取工具schema
  - 新增场景只需创建一个 py 文件，无需改其他代码

架构优势：
  - 完全插拔：删除一个场景文件 = 移除该业务能力
  - 零耦合：场景之间互不感知
  - 统一入口：所有工具/意图/prompt 通过注册表统一管理
"""
from __future__ import annotations

import abc
from typing import Any

from app.core.logging import get_logger
from app.tools.base import BaseTool, tool_registry

logger = get_logger(__name__)


class BaseScenario(abc.ABC):
    """
    业务场景基类。

    一个场景 = 一组意图标签 + 一组工具 + 可选提示词补充。

    子类必须实现：
      - name: 场景唯一标识（snake_case）
      - description: 场景描述（用于 LLM 理解何时匹配该场景）
      - intent_labels: 该场景对应的意图标签列表
      - tools: 该场景注册的工具实例列表

    子类可以覆盖：
      - system_prompt_extra: 注入到 intent_recognition 或 tool_router 的额外提示
      - on_register: 注册时的钩子（如预热连接）
    """

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """场景唯一标识，snake_case"""

    @property
    @abc.abstractmethod
    def description(self) -> str:
        """场景描述，帮助 LLM 理解何时路由到此场景"""

    @property
    @abc.abstractmethod
    def intent_labels(self) -> list[str]:
        """该场景对应的意图标签列表（意图识别时使用）"""

    @property
    @abc.abstractmethod
    def tools(self) -> list[BaseTool]:
        """该场景提供的工具实例列表"""

    @property
    def system_prompt_extra(self) -> str:
        """
        注入到 tool_router 系统提示中的场景特有说明。
        用于告诉 LLM 该场景的特殊规则，如"只有库存不足时才调用购买API"。
        默认为空。
        """
        return ""

    async def on_register(self) -> None:
        """注册时调用的异步钩子，可用于预热/初始化"""

    def register_tools(self) -> None:
        """将本场景的工具注册到全局 tool_registry"""
        for tool in self.tools:
            tool_registry.register(tool)
            logger.debug("场景工具已注册", scenario=self.name, tool=tool.name)


class ScenarioRegistry:
    """
    场景注册中心（单例）

    职责：
    1. 持有所有已注册场景
    2. 为 intent_recognition 节点提供完整的意图标签→场景映射
    3. 为 tool_router 节点提供场景特有的 system_prompt_extra
    4. 支持动态注册/注销（热插拔）
    """

    def __init__(self) -> None:
        self._scenarios: dict[str, BaseScenario] = {}
        # 意图标签 → 场景名 的反向索引
        self._intent_to_scenario: dict[str, str] = {}

    def register(self, scenario: BaseScenario) -> None:
        self._scenarios[scenario.name] = scenario
        for label in scenario.intent_labels:
            self._intent_to_scenario[label] = scenario.name
        scenario.register_tools()
        logger.info(
            "场景已注册",
            scenario=scenario.name,
            intents=scenario.intent_labels,
            tools=[t.name for t in scenario.tools],
        )

    def unregister(self, name: str) -> None:
        scenario = self._scenarios.pop(name, None)
        if scenario:
            for label in scenario.intent_labels:
                self._intent_to_scenario.pop(label, None)
            logger.info("场景已注销", scenario=name)

    def get_scenario_for_intent(self, intent: str) -> BaseScenario | None:
        name = self._intent_to_scenario.get(intent)
        if name:
            return self._scenarios.get(name)
        return None

    def all_intent_labels(self) -> list[dict[str, str]]:
        """
        返回所有意图标签及其描述，供 intent_recognition 节点构建 prompt。
        格式：[{"label": "...", "description": "...", "scenario": "..."}]
        """
        result = []
        for scenario in self._scenarios.values():
            for label in scenario.intent_labels:
                result.append({
                    "label": label,
                    "description": scenario.description,
                    "scenario": scenario.name,
                })
        # 加入通用意图
        result.append({"label": "general_chat", "description": "普通对话，无需工具", "scenario": ""})
        result.append({"label": "calculate", "description": "数学计算", "scenario": ""})
        result.append({"label": "unknown", "description": "无法判断", "scenario": ""})
        return result

    def get_prompt_extra(self, intent: str) -> str:
        """获取意图对应场景的 system_prompt_extra"""
        scenario = self.get_scenario_for_intent(intent)
        if scenario:
            return scenario.system_prompt_extra
        return ""

    def all_names(self) -> list[str]:
        return list(self._scenarios.keys())

    def __contains__(self, name: str) -> bool:
        return name in self._scenarios


# 全局单例
scenario_registry = ScenarioRegistry()
