"""天气查询 + 酒店搜索工具（天气&酒店场景）。"""
from __future__ import annotations
import os
from typing import Any
import httpx
from app.core.exceptions import ToolExecutionError
from app.core.logging import get_logger
from app.tools.base import BaseTool

logger = get_logger(__name__)

WEATHER_API_KEY = os.getenv("WEATHER_API_KEY", "")
HOTEL_API_KEY   = os.getenv("HOTEL_API_KEY", "")

OUTDOOR_FRIENDLY = {"晴", "多云", "少云", "Clear", "Sunny", "Partly Cloudy"}


class WeatherTool(BaseTool):
    @property
    def name(self) -> str: return "get_weather"

    @property
    def description(self) -> str:
        return "查询指定城市的当前天气，返回天气状况、温度、湿度及 is_outdoor_friendly 字段。"

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "city": {"type": "string", "description": "城市名，如'北京'"},
                        "date": {"type": "string", "description": "日期 YYYY-MM-DD，默认今天", "default": "today"},
                    },
                    "required": ["city"],
                },
            },
        }

    async def execute(self, city: str, date: str = "today", **_: Any) -> dict[str, Any]:
        if WEATHER_API_KEY:
            return await self._real_api(city, date)
        return self._mock(city)

    async def _real_api(self, city: str, date: str) -> dict[str, Any]:
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                geo = await client.get(
                    "https://geoapi.qweather.com/v2/city/lookup",
                    params={"location": city, "key": WEATHER_API_KEY},
                )
                geo.raise_for_status()
                locs = geo.json().get("location", [])
                if not locs:
                    raise ToolExecutionError(self.name, f"找不到城市: {city}")
                loc_id = locs[0]["id"]
                w = await client.get(
                    "https://api.qweather.com/v7/weather/now",
                    params={"location": loc_id, "key": WEATHER_API_KEY},
                )
                w.raise_for_status()
                now = w.json().get("now", {})
                condition = now.get("text", "未知")
                return {
                    "city": city, "date": date,
                    "condition": condition,
                    "temperature_celsius": float(now.get("temp", 0)),
                    "humidity_percent": float(now.get("humidity", 0)),
                    "is_outdoor_friendly": condition in OUTDOOR_FRIENDLY,
                    "source": "qweather",
                }
        except ToolExecutionError: raise
        except Exception as exc:
            raise ToolExecutionError(self.name, f"天气API失败: {exc}") from exc

    @staticmethod
    def _mock(city: str) -> dict[str, Any]:
        sunny = any(k in city.lower() for k in ["北京", "beijing", "上海", "shanghai"])
        condition = "晴" if sunny else "阴"
        return {
            "city": city, "date": "today",
            "condition": condition,
            "temperature_celsius": 26 if sunny else 16,
            "humidity_percent": 45 if sunny else 80,
            "is_outdoor_friendly": sunny,
            "source": "mock",
        }


class HotelSearchTool(BaseTool):
    @property
    def name(self) -> str: return "search_hotels"

    @property
    def description(self) -> str:
        return "搜索指定城市的酒店，按性价比排序，返回价格、评分、地址等信息。"

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "city":          {"type": "string", "description": "目标城市"},
                        "checkin_date":  {"type": "string", "description": "入住日期 YYYY-MM-DD", "default": "today"},
                        "checkout_date": {"type": "string", "description": "退房日期 YYYY-MM-DD", "default": "tomorrow"},
                        "budget_cny":    {"type": "number", "description": "每晚预算（元），不填不限"},
                        "sort_by":       {"type": "string", "enum": ["value_for_money", "rating", "price_asc"], "default": "value_for_money"},
                    },
                    "required": ["city"],
                },
            },
        }

    async def execute(
        self,
        city: str,
        checkin_date: str = "today",
        checkout_date: str = "tomorrow",
        budget_cny: float | None = None,
        sort_by: str = "value_for_money",
        **_: Any,
    ) -> dict[str, Any]:
        if HOTEL_API_KEY:
            return await self._real_api(city, checkin_date, checkout_date, budget_cny, sort_by)
        return self._mock(city, budget_cny)

    async def _real_api(self, city, checkin, checkout, budget, sort_by) -> dict[str, Any]:
        params: dict[str, Any] = {
            "city": city, "checkIn": checkin, "checkOut": checkout,
            "sortBy": sort_by, "apikey": HOTEL_API_KEY,
        }
        if budget:
            params["maxPrice"] = budget
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                r = await client.get("https://api.example-hotel.com/v1/search", params=params)
                r.raise_for_status()
                data = r.json()
            return {"city": city, "hotels": data.get("hotels", [])[:5], "source": "real_api"}
        except Exception as exc:
            raise ToolExecutionError(self.name, f"酒店API失败: {exc}") from exc

    @staticmethod
    def _mock(city: str, budget: float | None) -> dict[str, Any]:
        hotels = [
            {"name": f"{city}如家酒店", "price_per_night_cny": 298, "rating": 4.3, "value_score": 9.1,
             "address": f"{city}东城区", "amenities": ["WiFi", "24h前台"]},
            {"name": f"{city}汉庭酒店", "price_per_night_cny": 359, "rating": 4.5, "value_score": 9.4,
             "address": f"{city}西城区", "amenities": ["WiFi", "健身房", "早餐"]},
            {"name": f"{city}维也纳酒店", "price_per_night_cny": 489, "rating": 4.6, "value_score": 8.9,
             "address": f"{city}朝阳区", "amenities": ["WiFi", "游泳池", "早餐", "商务中心"]},
        ]
        if budget:
            hotels = [h for h in hotels if h["price_per_night_cny"] <= budget]
        hotels.sort(key=lambda h: h["value_score"], reverse=True)
        return {"city": city, "hotels": hotels, "currency": "CNY", "source": "mock"}
