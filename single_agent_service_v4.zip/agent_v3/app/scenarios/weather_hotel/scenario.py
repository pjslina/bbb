"""天气 + 酒店推荐场景。"""
from __future__ import annotations
from app.scenarios.base import BaseScenario
from app.scenarios.weather_hotel.tools import HotelSearchTool, WeatherTool
from app.tools.base import BaseTool


class WeatherHotelScenario(BaseScenario):

    @property
    def name(self) -> str:
        return "weather_hotel"

    @property
    def description(self) -> str:
        return "查询城市天气，并根据天气情况推荐适合入住的性价比酒店。"

    @property
    def intent_labels(self) -> list[str]:
        return [
            "weather_query",            # 单纯查天气
            "weather_then_hotel",       # 查天气 + 条件性找酒店
            "hotel_search",             # 直接搜酒店
        ]

    @property
    def tools(self) -> list[BaseTool]:
        return [WeatherTool(), HotelSearchTool()]

    @property
    def system_prompt_extra(self) -> str:
        return """
【天气&酒店场景专属规则】
1. 用户询问天气时，先调用 get_weather
2. 若用户要求"晴天才订酒店"等条件，必须在获取天气结果后判断 is_outdoor_friendly
3. is_outdoor_friendly=true 且用户有住宿需求时，才调用 search_hotels
4. is_outdoor_friendly=false 时，直接告知天气情况，不调用酒店工具
5. 推荐酒店时按性价比排序，重点展示价格、评分、地址
"""
