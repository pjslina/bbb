"""SSE 流式对话端点。"""
from __future__ import annotations
import asyncio
from fastapi import APIRouter, Request
from sse_starlette.sse import EventSourceResponse
from app.agent.graph import get_runner
from app.api.models import ChatRequest, StreamEvent
from app.core.config import settings
from app.core.exceptions import AgentBaseError
from app.core.logging import get_logger

logger = get_logger(__name__)
router = APIRouter()


@router.post("/chat/stream", summary="SSE 流式对话")
async def stream_chat(request: Request, body: ChatRequest) -> EventSourceResponse:
    async def generate():
        runner = get_runner()
        session_id = body.session_id
        try:
            yield {"data": StreamEvent(
                type="metadata", session_id=session_id,
                metadata={"model": settings.llm_model, "provider": settings.llm_provider},
            ).model_dump_json()}

            async for token in runner.astream(
                session_id=session_id,
                user_input=body.message,
                user_id=body.user_id,
                extra=body.extra,
            ):
                if await request.is_disconnected():
                    break
                yield {"data": StreamEvent(
                    type="token", data=token, session_id=session_id
                ).model_dump_json()}

            yield {"data": StreamEvent(type="done", session_id=session_id).model_dump_json()}

        except asyncio.TimeoutError:
            yield {"data": StreamEvent(
                type="error",
                data=f"请求超时（{settings.agent_timeout}s）",
                session_id=session_id,
            ).model_dump_json()}
        except AgentBaseError as exc:
            yield {"data": StreamEvent(
                type="error", data=exc.message, session_id=session_id
            ).model_dump_json()}
        except Exception as exc:
            logger.error("SSE意外错误", error=str(exc))
            yield {"data": StreamEvent(
                type="error", data="内部错误", session_id=session_id
            ).model_dump_json()}

    return EventSourceResponse(generate())
