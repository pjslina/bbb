"""WebSocket 双向流式对话端点。"""
from __future__ import annotations
import asyncio
import json
from typing import Any
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.agent.graph import get_runner
from app.core.config import settings
from app.core.exceptions import AgentBaseError
from app.core.logging import get_logger
from app.memory.redis_store import memory_store

logger = get_logger(__name__)
router = APIRouter()
_active: dict[str, WebSocket] = {}


@router.websocket("/ws/{session_id}")
async def ws_chat(websocket: WebSocket, session_id: str) -> None:
    import re
    if not re.match(r"^[\w\-]+$", session_id):
        await websocket.close(code=4000, reason="无效session_id")
        return

    await websocket.accept()
    _active[session_id] = websocket
    logger.info("WebSocket已连接", session_id=session_id)

    try:
        await _send(websocket, {
            "type": "connected", "session_id": session_id,
            "config": {
                "max_tool_calls": settings.agent_max_tool_calls,
                "timeout": settings.agent_timeout,
            },
        })
        while True:
            try:
                raw = await asyncio.wait_for(websocket.receive_text(), timeout=300.0)
            except asyncio.TimeoutError:
                await _send(websocket, {"type": "idle_timeout"})
                break

            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await _send(websocket, {"type": "error", "data": "无效JSON"})
                continue

            msg_type = msg.get("type", "chat")

            if msg_type == "ping":
                await _send(websocket, {"type": "pong"})
            elif msg_type == "clear_session":
                await memory_store.delete_session(session_id)
                await _send(websocket, {"type": "session_cleared"})
            elif msg_type == "chat":
                text = msg.get("message", "").strip()
                if not text:
                    await _send(websocket, {"type": "error", "data": "消息不能为空"})
                    continue
                await _handle_turn(websocket, session_id, text,
                                   msg.get("user_id", ""), msg.get("extra", {}))
    except WebSocketDisconnect:
        logger.info("WebSocket断开", session_id=session_id)
    except Exception as exc:
        logger.error("WebSocket错误", error=str(exc), session_id=session_id)
        try:
            await _send(websocket, {"type": "error", "data": "内部错误"})
        except Exception:
            pass
    finally:
        _active.pop(session_id, None)


async def _handle_turn(
    ws: WebSocket,
    session_id: str,
    user_message: str,
    user_id: str,
    extra: dict[str, Any],
) -> None:
    runner = get_runner()
    await _send(ws, {"type": "metadata", "session_id": session_id,
                     "metadata": {"model": settings.llm_model}})
    try:
        async for token in runner.astream(
            session_id=session_id,
            user_input=user_message,
            user_id=user_id,
            extra=extra,
        ):
            await _send(ws, {"type": "token", "data": token, "session_id": session_id})
        await _send(ws, {"type": "done", "session_id": session_id})
    except asyncio.TimeoutError:
        await _send(ws, {"type": "error", "data": f"超时（{settings.agent_timeout}s）"})
    except AgentBaseError as exc:
        await _send(ws, {"type": "error", "data": exc.message})
    except Exception as exc:
        logger.error("WS轮次错误", error=str(exc))
        await _send(ws, {"type": "error", "data": "内部错误"})


async def _send(ws: WebSocket, data: dict[str, Any]) -> None:
    await ws.send_text(json.dumps(data, ensure_ascii=False))
