"""API 请求/响应 Pydantic 模型。"""
from __future__ import annotations
import re
from typing import Any, Literal, Optional
from pydantic import BaseModel, Field, field_validator


class ChatRequest(BaseModel):
    session_id: str = Field(..., min_length=1, max_length=128)
    message:    str = Field(..., min_length=1, max_length=8192)
    user_id:    str = Field(default="", max_length=128)
    extra:      Optional[dict[str, Any]] = None

    @field_validator("session_id")
    @classmethod
    def _valid_session_id(cls, v: str) -> str:
        if not re.match(r"^[\w\-]+$", v):
            raise ValueError("session_id 只能包含字母、数字、下划线和连字符")
        return v


class ChatResponse(BaseModel):
    session_id:       str
    message:          str
    intent:           str = ""
    intent_confidence: float = 0.0
    tool_calls_count: int = 0


class StreamEvent(BaseModel):
    type:     Literal["token", "done", "error", "metadata"]
    data:     str = ""
    session_id: str = ""
    metadata: Optional[dict[str, Any]] = None


class SessionInfoResponse(BaseModel):
    session_id:    str
    exists:        bool
    message_count: int = 0
    meta:          dict[str, Any] = Field(default_factory=dict)


class HealthResponse(BaseModel):
    status:    Literal["ok", "degraded", "error"]
    service:   str
    env:       str
    databases: dict[str, str] = Field(default_factory=dict)
    redis:     str = "unknown"
    scenarios: list[str] = Field(default_factory=list)
    tools:     list[str] = Field(default_factory=list)
