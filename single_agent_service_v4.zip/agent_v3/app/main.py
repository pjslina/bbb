"""
FastAPI 应用工厂。

启动顺序：
  1. 配置结构化日志
  2. 注册通用工具（Calculator、HttpApi、DatabaseTool）
  3. 扫描并注册所有业务场景（自动发现 scenarios/*/scenario.py）
  4. 初始化数据库连接池
  5. 初始化 Redis 记忆存储
  6. 预热 LLM 适配器
"""
from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.routes import router as rest_router
from app.api.sse import router as sse_router
from app.api.websocket import router as ws_router
from app.core.config import settings
from app.core.exceptions import AgentBaseError
from app.core.logging import get_logger, setup_logging
from app.db.pool import db_manager
from app.llm.adapter import LLMAdapter
from app.memory.redis_store import memory_store
from app.scenarios.loader import discover_and_register_scenarios
from app.tools.common_tools import register_common_tools
from app.tools.db_tool import register_db_tool

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    setup_logging()
    logger.info("Agent服务启动中", env=settings.app_env)

    # 1. 通用工具
    register_common_tools()
    register_db_tool()

    # 2. 场景自动扫描注册（包含各场景的专属工具）
    discover_and_register_scenarios()

    # 3. 数据库连接池
    await db_manager.init()

    # 4. Redis 记忆
    await memory_store.init()

    # 5. LLM 预热
    LLMAdapter.get_instance()

    logger.info("Agent服务就绪", port=settings.app_port)
    yield

    logger.info("Agent服务关闭中")
    await db_manager.close()
    await memory_store.close()
    logger.info("关闭完成")


def create_app() -> FastAPI:
    app = FastAPI(
        title="Single Agent Service",
        version="1.0.0",
        description="生产级单Agent服务，支持多业务场景插拔、双通道流式、多数据库。",
        docs_url="/docs" if not settings.is_production else None,
        redoc_url=None,
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if not settings.is_production else [],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def timing(request: Request, call_next) -> Response:
        start = time.perf_counter()
        resp = await call_next(request)
        resp.headers["X-Process-Time"] = f"{time.perf_counter() - start:.4f}"
        return resp

    @app.exception_handler(AgentBaseError)
    async def agent_error(request: Request, exc: AgentBaseError) -> JSONResponse:
        logger.error("未捕获Agent异常", code=exc.code, msg=exc.message)
        return JSONResponse(500, {"code": exc.code, "message": exc.message})

    @app.exception_handler(Exception)
    async def generic_error(request: Request, exc: Exception) -> JSONResponse:
        logger.error("未捕获异常", error=str(exc), exc_info=True)
        return JSONResponse(500, {"code": "INTERNAL_ERROR", "message": "内部服务器错误"})

    API = "/api/v1"
    app.include_router(rest_router, prefix=API, tags=["对话与会话"])
    app.include_router(sse_router,  prefix=API, tags=["SSE流式"])
    app.include_router(ws_router,             tags=["WebSocket"])

    @app.get("/", include_in_schema=False)
    async def root() -> dict:
        return {"service": settings.app_name, "env": settings.app_env, "status": "ok"}

    return app


app = create_app()
