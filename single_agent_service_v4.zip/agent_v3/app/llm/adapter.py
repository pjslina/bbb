"""统一LLM适配器，支持 Qwen / GLM / OpenAI（OpenAI-compatible接口）。"""
from __future__ import annotations
import asyncio
from typing import Any, AsyncIterator, Sequence
from langchain_core.messages import BaseMessage
from langchain_openai import ChatOpenAI
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential
from app.core.config import settings
from app.core.exceptions import LLMError, LLMTimeoutError
from app.core.logging import get_logger

logger = get_logger(__name__)

_PROVIDER_BASE_URLS = {
    "qwen":   "https://dashscope.aliyuncs.com/compatible-mode/v1",
    "glm":    "https://open.bigmodel.cn/api/paas/v4",
    "openai": "https://api.openai.com/v1",
}
_PROVIDER_MODELS = {
    "qwen":   "qwen-plus",
    "glm":    "glm-4",
    "openai": "gpt-4o",
}


def _base_url() -> str:
    return settings.llm_base_url or _PROVIDER_BASE_URLS.get(settings.llm_provider, "")


def _model() -> str:
    return settings.llm_model or _PROVIDER_MODELS.get(settings.llm_provider, "gpt-4o")


def create_llm(*, streaming: bool = False) -> ChatOpenAI:
    return ChatOpenAI(
        base_url=_base_url(),
        api_key=settings.llm_api_key,
        model=_model(),
        temperature=settings.llm_temperature,
        max_tokens=settings.llm_max_tokens,
        streaming=streaming,
        timeout=settings.llm_timeout,
    )


class LLMAdapter:
    _instance: "LLMAdapter | None" = None

    def __init__(self) -> None:
        self._llm = create_llm(streaming=False)
        self._llm_stream = create_llm(streaming=True)
        logger.info("LLM适配器初始化", provider=settings.llm_provider, model=_model())

    @classmethod
    def get_instance(cls) -> "LLMAdapter":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @retry(
        retry=retry_if_exception_type((ConnectionError, TimeoutError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def ainvoke(
        self,
        messages: Sequence[BaseMessage],
        tools: list[dict[str, Any]] | None = None,
    ) -> Any:
        try:
            llm = self._llm.bind_tools(tools) if tools else self._llm  # type: ignore
            return await asyncio.wait_for(llm.ainvoke(list(messages)), timeout=settings.llm_timeout)
        except asyncio.TimeoutError as e:
            raise LLMTimeoutError() from e
        except Exception as e:
            raise LLMError(str(e)) from e

    async def astream_tokens(self, messages: Sequence[BaseMessage]) -> AsyncIterator[str]:
        try:
            async for chunk in self._llm_stream.astream(list(messages)):
                content = chunk.content  # type: ignore
                if isinstance(content, str) and content:
                    yield content
                elif isinstance(content, list):
                    for part in content:
                        if isinstance(part, dict) and part.get("type") == "text":
                            yield part.get("text", "")
        except asyncio.TimeoutError as e:
            raise LLMTimeoutError() from e
        except Exception as e:
            raise LLMError(str(e)) from e
