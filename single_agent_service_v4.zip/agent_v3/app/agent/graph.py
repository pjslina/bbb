"""
LangGraph StateGraph 构建与 AgentRunner。

图拓扑（含关键循环）：

  START
    └─► intent_recognition
    └─► tool_decision
        ├─► llm_answer          (无工具意图)
        └─► tool_router
            ├─► llm_answer      (LLM判断无需继续调用工具)
            └─► tool_executor
                ├─► llm_answer  (达到调用次数上限)
                └─► tool_router ← 条件链式调用循环
    └─► llm_answer
    └─► memory_update
  END
"""
from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator

from langgraph.graph import END, START, StateGraph

from app.agent.nodes import (
    node_intent_recognition,
    node_llm_answer,
    node_memory_update,
    node_tool_decision,
    node_tool_executor,
    node_tool_router,
    route_after_tool_decision,
    route_after_tool_executor,
    route_after_tool_router,
)
from app.agent.state import AgentState
from app.core.config import settings
from app.core.exceptions import AgentTimeoutError
from app.core.logging import get_logger
from app.memory.redis_store import memory_store

logger = get_logger(__name__)


def build_graph() -> Any:
    builder = StateGraph(AgentState)

    builder.add_node("intent_recognition", node_intent_recognition)
    builder.add_node("tool_decision",      node_tool_decision)
    builder.add_node("tool_router",        node_tool_router)
    builder.add_node("tool_executor",      node_tool_executor)
    builder.add_node("llm_answer",         node_llm_answer)
    builder.add_node("memory_update",      node_memory_update)

    builder.add_edge(START, "intent_recognition")
    builder.add_edge("intent_recognition", "tool_decision")

    builder.add_conditional_edges(
        "tool_decision", route_after_tool_decision,
        {"tool_router": "tool_router", "llm_answer": "llm_answer"},
    )
    builder.add_conditional_edges(
        "tool_router", route_after_tool_router,
        {"tool_executor": "tool_executor", "llm_answer": "llm_answer"},
    )
    # 关键：tool_executor 可以循环回 tool_router
    builder.add_conditional_edges(
        "tool_executor", route_after_tool_executor,
        {"tool_router": "tool_router", "llm_answer": "llm_answer"},
    )
    builder.add_edge("llm_answer",    "memory_update")
    builder.add_edge("memory_update", END)

    compiled = builder.compile()
    logger.info("Agent图编译完成")
    return compiled


_graph: Any = None


def get_graph() -> Any:
    global _graph
    if _graph is None:
        _graph = build_graph()
    return _graph


# ============================================================================
# AgentRunner — API层使用的高级接口
# ============================================================================

class AgentRunner:
    def __init__(self) -> None:
        self._graph = get_graph()

    async def run(
        self,
        session_id: str,
        user_input: str,
        user_id: str = "",
        extra: dict[str, Any] | None = None,
    ) -> str:
        """同步执行一轮，返回完整回答字符串。"""
        state = await self._init_state(session_id, user_input, user_id, extra)
        try:
            result = await asyncio.wait_for(
                self._graph.ainvoke(state),
                timeout=settings.agent_timeout,
            )
        except asyncio.TimeoutError as exc:
            raise AgentTimeoutError(settings.agent_timeout) from exc
        return result.get("final_answer", "")

    async def run_debug(
        self,
        session_id: str,
        user_input: str,
        user_id: str = "",
    ) -> dict[str, Any]:
        """调试模式：返回完整状态快照，含工具调用链路。"""
        state = await self._init_state(session_id, user_input, user_id, {})
        result = await asyncio.wait_for(
            self._graph.ainvoke(state),
            timeout=settings.agent_timeout,
        )
        return {
            "intent":            result.get("intent"),
            "intent_confidence": result.get("intent_confidence"),
            "intent_slots":      result.get("intent_slots", {}),
            "tool_results":      result.get("tool_results", []),
            "tool_call_count":   result.get("tool_call_count", 0),
            "final_answer":      result.get("final_answer", ""),
        }

    async def astream(
        self,
        session_id: str,
        user_input: str,
        user_id: str = "",
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        """
        流式输出：先完整跑工具链，再流式生成最终回答token。
        工具链不流式（保证原子性），仅最终LLM生成阶段流式。
        """
        from app.agent.nodes import LLM_ANSWER_PROMPT, _format_tool_results
        from app.llm.adapter import LLMAdapter
        from langchain_core.messages import HumanMessage, SystemMessage, AIMessage

        state = await self._init_state(session_id, user_input, user_id, extra)

        try:
            result_state = await asyncio.wait_for(
                self._graph.ainvoke(state),
                timeout=settings.agent_timeout,
            )
        except asyncio.TimeoutError as exc:
            raise AgentTimeoutError(settings.agent_timeout) from exc

        # 构建带工具结果的 prompt
        tool_results = result_state.get("tool_results", [])
        tool_context = ""
        if tool_results:
            import json
            lines = [
                f"[{'✓' if tr['status']=='success' else '✗'}工具{i}: {tr['tool']}]\n{tr['result']}"
                for i, tr in enumerate(tool_results, 1)
            ]
            tool_context = "\n\n【工具执行结果】\n" + "\n\n".join(lines)

        messages_to_llm = [
            SystemMessage(content=LLM_ANSWER_PROMPT + tool_context),
            *result_state.get("messages", [])[-8:],
            HumanMessage(content=user_input),
        ]

        llm = LLMAdapter.get_instance()
        accumulated: list[str] = []
        async for token in llm.astream_tokens(messages_to_llm):
            accumulated.append(token)
            yield token

        # 流式结束后保存到记忆
        full_answer = "".join(accumulated)
        await memory_store.append_turn(
            session_id,
            HumanMessage(content=user_input),
            AIMessage(content=full_answer),
        )
        from app.memory.redis_store import maybe_compress_session
        await maybe_compress_session(session_id, memory_store, llm)

    async def _init_state(
        self,
        session_id: str,
        user_input: str,
        user_id: str,
        extra: dict[str, Any] | None,
    ) -> AgentState:
        history = await memory_store.load_history(session_id)
        return AgentState(
            session_id=session_id,
            user_id=user_id,
            user_input=user_input,
            messages=history,
            intent="",
            intent_confidence=0.0,
            intent_slots={},
            tool_calls=[],
            tool_results=[],
            tool_call_count=0,
            final_answer="",
            iteration_count=0,
            should_use_tool=False,
            error=None,
            extra=extra or {},
        )


_runner: AgentRunner | None = None


def get_runner() -> AgentRunner:
    global _runner
    if _runner is None:
        _runner = AgentRunner()
    return _runner
