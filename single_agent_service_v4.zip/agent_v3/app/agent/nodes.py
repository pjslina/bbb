"""
Agent 节点完整实现（重构版）

修复的三个核心缺口：
  缺口1：db/query.py 支持写操作 → 由 DatabaseTool 透明代理，节点无感知
  缺口2：场景化工具体系 → 节点从 scenario_registry / tool_registry 动态读取，
          无需硬编码任何工具名或意图标签
  缺口3：意图识别动态化 → INTENT_SYSTEM_PROMPT 在运行时从 scenario_registry
          拼装全量意图标签，新增场景自动扩展，无需改节点代码

节点流水线：
  intent_recognition → tool_decision → tool_router ⇄ tool_executor → llm_answer → memory_update

关键循环（条件链式调用）：
  tool_executor 执行完毕后回到 tool_router，
  LLM 根据已有工具结果决定是否继续调用下一个工具。
  循环由 agent_max_tool_calls 限制。
"""
from __future__ import annotations

import json
from typing import Any

from langchain_core.messages import (
    AIMessage, HumanMessage, SystemMessage, ToolMessage,
)

from app.agent.state import AgentState
from app.core.config import settings
from app.core.exceptions import AgentMaxIterationsError, LLMError, ToolCallLimitError
from app.core.logging import get_logger
from app.llm.adapter import LLMAdapter
from app.memory.redis_store import maybe_compress_session, memory_store
from app.scenarios.base import scenario_registry
from app.tools.base import tool_registry

logger = get_logger(__name__)


# ============================================================================
# 提示词模板
# ============================================================================

def _build_intent_system_prompt() -> str:
    """
    运行时动态生成意图识别提示词。
    意图标签来自 scenario_registry，新增场景自动出现在此处。
    """
    labels = scenario_registry.all_intent_labels()
    label_lines = "\n".join(
        f"- {item['label']}: {item['description']}"
        for item in labels
    )
    return f"""你是一个意图识别引擎。

将用户的消息精确分类为以下意图之一，并提取相关的结构化参数(slots)。

【可识别意图】
{label_lines}

【输出格式】
只输出合法JSON，不要Markdown，不要任何前缀文字：
{{
  "intent": "<意图标签>",
  "confidence": <0.0到1.0的浮点数>,
  "slots": {{
    "<参数名>": "<参数值>"
  }}
}}

【slots提取规则】
- 提取所有与意图相关的实体，如城市名、用户ID、数量、日期等
- user_id 从对话上下文获取，若无则留空字符串
- 尽量提取完整，即使不确定也要给出最佳猜测"""


def _build_tool_router_prompt(
    intent: str,
    slots: dict[str, Any],
    existing_results: list[dict[str, Any]],
    scenario_extra: str,
) -> str:
    """
    运行时动态生成工具路由提示词。
    包含：已有工具结果摘要、场景专属规则。
    """
    results_text = _format_tool_results(existing_results) or "（本轮尚未执行任何工具）"
    return f"""你是一个工具调用决策引擎。

【用户意图】{intent}
【提取的参数】{json.dumps(slots, ensure_ascii=False)}
【已执行工具及结果】
{results_text}

{scenario_extra}

【决策规则】
1. 分析已有结果，判断还需要哪些信息才能完成用户请求
2. 如果还需要工具，选择一个最合适的工具并调用（每次只调用一个）
3. 如果已有足够信息或条件不满足（如天气不好不需要查酒店），不要调用任何工具
4. 严格遵守场景专属规则（如有）
5. 工具参数要从已有的slots和工具结果中提取，不要编造"""


LLM_ANSWER_PROMPT = """你是一个贴心的家庭助手，帮助用户管理日常事务。

回答要求：
- 用自然的口语化中文回答，不要暴露数据库字段名
- 如果有工具执行结果，基于结果回答，不要编造数据
- 回答要简洁、有用，必要时给出具体建议
- 如果操作成功（如购买、更新），要明确告知结果"""


# ============================================================================
# 节点实现
# ============================================================================

async def node_intent_recognition(state: AgentState) -> dict[str, Any]:
    """
    【缺口3修复核心】
    意图识别：从 scenario_registry 动态拼装全量意图标签。
    新增任何场景后，本节点自动感知，无需修改代码。
    """
    _guard_max_iterations(state)

    llm = LLMAdapter.get_instance()
    user_input = state.get("user_input", "")
    history = state.get("messages", [])

    # 动态构建包含所有场景意图的提示词
    system_prompt = _build_intent_system_prompt()

    messages_to_llm = [
        SystemMessage(content=system_prompt),
        *history[-4:],                      # 最近4条历史提供上下文
        HumanMessage(content=user_input),
    ]

    try:
        response = await llm.ainvoke(messages_to_llm)
        raw = response.content.strip()
        # 去除可能的 markdown 代码块
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        data = json.loads(raw.strip())
    except Exception as exc:
        logger.warning("意图解析失败，降级为general_chat", error=str(exc))
        data = {"intent": "general_chat", "confidence": 0.5, "slots": {}}

    intent = data.get("intent", "unknown")
    # 验证意图是否在已注册范围内
    valid_labels = {item["label"] for item in scenario_registry.all_intent_labels()}
    if intent not in valid_labels:
        logger.warning("意图标签不在注册表中，降级", intent=intent)
        intent = "unknown"

    logger.info(
        "意图识别完成",
        session_id=state.get("session_id"),
        intent=intent,
        confidence=data.get("confidence"),
        slots=data.get("slots", {}),
    )

    return {
        "intent":            intent,
        "intent_confidence": float(data.get("confidence", 0.5)),
        "intent_slots":      data.get("slots", {}),
        "iteration_count":   state.get("iteration_count", 0) + 1,
    }


async def node_tool_decision(state: AgentState) -> dict[str, Any]:
    """
    判断当前意图是否需要工具。
    general_chat、calculate、unknown 不需要工具，直接进入 llm_answer。
    """
    intent = state.get("intent", "unknown")
    tool_call_count = state.get("tool_call_count", 0)

    # 超限保护
    if tool_call_count >= settings.agent_max_tool_calls:
        logger.warning("工具调用已达上限，强制跳过工具", count=tool_call_count)
        return {"should_use_tool": False}

    # 不需要工具的通用意图
    NO_TOOL_INTENTS = {"general_chat", "unknown", "calculate"}
    if intent in NO_TOOL_INTENTS:
        return {"should_use_tool": False}

    # 检查 scenario_registry 是否有该意图对应的场景和工具
    scenario = scenario_registry.get_scenario_for_intent(intent)
    has_tools = scenario is not None and bool(scenario.tools)

    logger.debug("工具决策", intent=intent, should_use_tool=has_tools,
                 scenario=scenario.name if scenario else None)
    return {"should_use_tool": has_tools}


async def node_tool_router(state: AgentState) -> dict[str, Any]:
    """
    【缺口2修复核心】
    工具路由：每轮将已有结果 + 场景规则传给 LLM，动态决策下一个工具。

    - 工具列表来自 tool_registry（由场景注册时填充），完全动态
    - 场景专属规则来自 scenario_registry.get_prompt_extra()
    - 支持条件链式调用（天气→酒店、查库存→购买→更新库存）
    """
    intent = state.get("intent", "unknown")
    slots = state.get("intent_slots", {})
    user_input = state.get("user_input", "")
    existing_results = state.get("tool_results", [])
    tool_call_count = state.get("tool_call_count", 0)

    if tool_call_count >= settings.agent_max_tool_calls:
        return {"tool_calls": []}

    # 获取场景专属提示（包含业务规则，如"库存不足才购买"）
    scenario_extra = scenario_registry.get_prompt_extra(intent)

    system_prompt = _build_tool_router_prompt(
        intent, slots, existing_results, scenario_extra
    )

    llm = LLMAdapter.get_instance()
    all_schemas = tool_registry.all_schemas()   # 动态获取所有已注册工具

    messages_to_llm = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_input),
    ]

    try:
        response = await llm.ainvoke(messages_to_llm, tools=all_schemas)
    except LLMError as exc:
        logger.error("tool_router LLM调用失败", error=str(exc))
        return {"tool_calls": []}

    # 提取工具调用列表
    raw_calls: list[dict[str, Any]] = []
    if hasattr(response, "tool_calls") and response.tool_calls:
        for tc in response.tool_calls:
            raw_calls.append({
                "id":   tc.get("id", ""),
                "name": tc.get("name", ""),
                "args": tc.get("args", {}),
            })

    logger.info(
        "工具路由决策",
        session_id=state.get("session_id"),
        selected=[tc["name"] for tc in raw_calls],
        existing_count=len(existing_results),
        call_count=tool_call_count,
    )

    return {"tool_calls": raw_calls}


async def node_tool_executor(state: AgentState) -> dict[str, Any]:
    """
    执行当前轮次的工具调用（通常每轮1个，保证条件链的原子性）。

    执行完毕后：
      - 结果追加到 tool_results（累积，供后续 tool_router 感知）
      - tool_calls 清空（等待 tool_router 决策下一步）
      - ToolMessage 追加到 messages（供 LLM 在 llm_answer 节点参考）

    【缺口1修复】
    若工具是 DatabaseTool，其内部透明处理 READ 和 WRITE，
    写操作（UPDATE/INSERT）同样在此节点调用，节点代码无需区分。
    """
    tool_calls = state.get("tool_calls", [])
    tool_call_count = state.get("tool_call_count", 0)
    existing_results = list(state.get("tool_results", []))
    messages = list(state.get("messages", []))

    for tc in tool_calls:
        if tool_call_count >= settings.agent_max_tool_calls:
            raise ToolCallLimitError(settings.agent_max_tool_calls)

        tool_name = tc.get("name", "")
        tool_args = tc.get("args", {})
        tool_id   = tc.get("id") or tool_name

        logger.info(
            "执行工具",
            session_id=state.get("session_id"),
            tool=tool_name,
            call_no=tool_call_count + 1,
            args_keys=list(tool_args.keys()),
        )

        try:
            result = await tool_registry.execute(tool_name, **tool_args)
            result_str = json.dumps(result, ensure_ascii=False, default=str)
            status = "success"
        except Exception as exc:
            result_str = json.dumps({"error": str(exc)}, ensure_ascii=False)
            status = "error"
            logger.error("工具执行失败", tool=tool_name, error=str(exc))

        # 累积到 tool_results（关键：tool_router 下一轮会读取所有结果做决策）
        existing_results.append({
            "tool":       tool_name,
            "result":     result_str,
            "status":     status,
            "call_index": tool_call_count,
        })
        tool_call_count += 1

        # 追加到对话历史，让 llm_answer 节点可以引用工具结果
        messages.append(
            ToolMessage(content=result_str, tool_call_id=tool_id, name=tool_name)
        )

    return {
        "tool_results":    existing_results,
        "tool_call_count": tool_call_count,
        "tool_calls":      [],          # 清空，等待 tool_router 下一轮决策
        "messages":        messages,
    }


async def node_llm_answer(state: AgentState) -> dict[str, Any]:
    """
    生成最终自然语言回答。
    整合所有工具结果，用自然语言呈现给用户。
    """
    llm = LLMAdapter.get_instance()
    user_input   = state.get("user_input", "")
    history      = state.get("messages", [])
    tool_results = state.get("tool_results", [])

    # 构建工具结果上下文（注入 system prompt）
    tool_context = ""
    if tool_results:
        lines = []
        for i, tr in enumerate(tool_results, 1):
            status_mark = "✓" if tr["status"] == "success" else "✗"
            lines.append(f"[{status_mark}工具{i}: {tr['tool']}]\n{tr['result']}")
        tool_context = "\n\n【工具执行结果】\n" + "\n\n".join(lines)

    messages_to_llm = [
        SystemMessage(content=LLM_ANSWER_PROMPT + tool_context),
        *history[-8:],
        HumanMessage(content=user_input),
    ]

    try:
        response = await llm.ainvoke(messages_to_llm)
        answer = response.content if hasattr(response, "content") else str(response)
    except LLMError as exc:
        answer = f"抱歉，生成回答时遇到问题：{exc.message}"
        logger.error("llm_answer失败", error=str(exc))

    logger.info("回答生成完成", session_id=state.get("session_id"), length=len(answer))

    return {
        "final_answer": answer,
        "messages":     [AIMessage(content=answer)],
    }


async def node_memory_update(state: AgentState) -> dict[str, Any]:
    """持久化本轮对话到 Redis，并触发摘要压缩（如需要）。"""
    session_id   = state.get("session_id", "")
    user_input   = state.get("user_input", "")
    final_answer = state.get("final_answer", "")

    if session_id and user_input and final_answer:
        await memory_store.append_turn(
            session_id,
            HumanMessage(content=user_input),
            AIMessage(content=final_answer),
        )
        llm = LLMAdapter.get_instance()
        await maybe_compress_session(session_id, memory_store, llm)

    logger.debug("记忆已更新", session_id=session_id)
    return {}


# ============================================================================
# 路由函数（LangGraph conditional_edges 使用）
# ============================================================================

def route_after_tool_decision(state: AgentState) -> str:
    return "tool_router" if state.get("should_use_tool") else "llm_answer"


def route_after_tool_router(state: AgentState) -> str:
    return "tool_executor" if state.get("tool_calls") else "llm_answer"


def route_after_tool_executor(state: AgentState) -> str:
    """
    【条件链式调用的核心路由】
    工具执行后回到 tool_router，让 LLM 决定是否继续。
    tool_router 若返回空 tool_calls，则进入 llm_answer。
    安全限制：超过 max_tool_calls 强制进入 llm_answer。
    """
    count = state.get("tool_call_count", 0)
    if count >= settings.agent_max_tool_calls:
        logger.warning("工具调用已达上限，强制进入llm_answer", count=count)
        return "llm_answer"
    return "tool_router"


# ============================================================================
# 内部工具函数
# ============================================================================

def _guard_max_iterations(state: AgentState) -> None:
    count = state.get("iteration_count", 0)
    if count >= settings.agent_max_iterations:
        raise AgentMaxIterationsError(settings.agent_max_iterations)


def _format_tool_results(results: list[dict[str, Any]]) -> str:
    """将已执行工具结果格式化为 LLM 可读的文本摘要。"""
    if not results:
        return ""
    lines = []
    for r in results:
        try:
            parsed = json.loads(r["result"])
            summary = json.dumps(parsed, ensure_ascii=False)
            if len(summary) > 600:
                summary = summary[:600] + "…（已截断）"
        except Exception:
            summary = r["result"][:300]
        mark = "✓" if r["status"] == "success" else "✗"
        lines.append(f"{mark} {r['tool']}（第{r.get('call_index', '?')+1}次调用）: {summary}")
    return "\n".join(lines)
