"""AgentState — LangGraph 共享状态定义。"""
from __future__ import annotations
from typing import Annotated, Any
from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict


class AgentState(TypedDict, total=False):
    # ── 会话上下文 ───────────────────────────────
    session_id:   str
    user_id:      str

    # ── 对话历史（add_messages reducer：追加而非替换）──
    messages: Annotated[list[BaseMessage], add_messages]

    # ── 当前轮输入 ───────────────────────────────
    user_input: str

    # ── 意图识别结果 ─────────────────────────────
    intent:             str
    intent_confidence:  float
    intent_slots:       dict[str, Any]   # 从用户输入提取的结构化参数

    # ── 工具调用 ─────────────────────────────────
    tool_calls:      list[dict[str, Any]]   # 当前轮待执行的工具调用
    tool_results:    list[dict[str, Any]]   # 所有已执行工具的结果（累积）
    tool_call_count: int                    # 安全限制计数器

    # ── 回答 ─────────────────────────────────────
    final_answer: str

    # ── 安全 / 控制 ───────────────────────────────
    iteration_count: int
    should_use_tool: bool
    error:           str | None

    # ── 透传元数据 ───────────────────────────────
    extra: dict[str, Any]
