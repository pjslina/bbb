"""
Redis 会话记忆存储 — 支持三种部署模式：

  standalone  单机（开发 / 小规模生产）
              REDIS_MODE=standalone
              REDIS_URL=redis://localhost:6379/0

  cluster     官方 Redis Cluster（水平扩展）
              REDIS_MODE=cluster
              REDIS_CLUSTER_NODES=ip1:7001,ip2:7002,ip3:7003

  sentinel    Redis Sentinel 高可用（主从 + 自动故障切换）
              REDIS_MODE=sentinel
              REDIS_SENTINEL_NODES=ip1:26379,ip2:26379,ip3:26379
              REDIS_SENTINEL_MASTER_NAME=mymaster

三种模式对外暴露完全相同的 RedisMemoryStore 接口，
调用方无感知切换。
"""
from __future__ import annotations

import json
from typing import Any, Union

import redis.asyncio as aioredis
from redis.asyncio.cluster import RedisCluster
from redis.asyncio.sentinel import Sentinel
from redis.asyncio.retry import Retry
from redis.backoff import ExponentialBackoff
from redis.exceptions import (
    BusyLoadingError,
    ConnectionError as RedisConnectionError,
    TimeoutError as RedisTimeoutError,
)

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    messages_from_dict,
    messages_to_dict,
)

from app.core.config import settings
from app.core.exceptions import MemoryError
from app.core.logging import get_logger

logger = get_logger(__name__)

# Redis key 模板
_KEY_MSGS    = "session:{sid}:messages"
_KEY_SUMMARY = "session:{sid}:summary"
_KEY_META    = "session:{sid}:meta"

# 会话摘要 prompt
SUMMARISE_PROMPT = """你是一个对话摘要引擎。
用3-5句话概括以下对话的关键信息、用户意图和已完成的操作。
只输出摘要，不要前缀。

对话：
{conversation}"""

# redis.asyncio 统一类型别名
_RedisClient = Union[aioredis.Redis, RedisCluster]

# 遇到这些异常时自动重试
_RETRY_ERRORS = (BusyLoadingError, RedisConnectionError, RedisTimeoutError)


# ──────────────────────────────────────────────────────────────────────────────
# 连接工厂：根据 settings.redis_mode 创建对应客户端
# ──────────────────────────────────────────────────────────────────────────────

def _make_retry() -> Retry:
    """指数退避重试策略：最多3次，初始0.1s，上限2s。"""
    return Retry(ExponentialBackoff(cap=2, base=0.1), retries=3)


def _common_kwargs() -> dict[str, Any]:
    """三种模式共用的连接参数。"""
    return dict(
        password=settings.redis_password or None,
        socket_timeout=settings.redis_socket_timeout,
        socket_connect_timeout=settings.redis_socket_connect_timeout,
        retry_on_timeout=settings.redis_retry_on_timeout,
        retry_on_error=list(_RETRY_ERRORS),
        retry=_make_retry(),
        health_check_interval=settings.redis_health_check_interval,
        decode_responses=True,
    )


async def _create_standalone() -> aioredis.Redis:
    """
    单机模式。
    支持 redis:// 和 rediss://（TLS）两种协议。
    """
    pool = aioredis.ConnectionPool.from_url(
        settings.redis_url,
        max_connections=settings.redis_max_connections,
        **_common_kwargs(),
    )
    client: aioredis.Redis = aioredis.Redis(connection_pool=pool)
    await client.ping()
    logger.info(
        "Redis[standalone] 已连接",
        url=settings.redis_url.split("@")[-1],   # 隐藏密码部分
    )
    return client


async def _create_cluster() -> RedisCluster:
    """
    Cluster 模式。
    只需提供任意一个或多个节点地址，客户端自动发现拓扑。
    注意：Cluster 模式不支持 SELECT db，redis_db 固定为 0。
    """
    nodes = settings.parsed_cluster_nodes()
    if not nodes:
        raise MemoryError("Cluster 模式：REDIS_CLUSTER_NODES 未配置或格式错误")

    startup_nodes = [
        aioredis.cluster.ClusterNode(host=h, port=p)
        for h, p in nodes
    ]

    kwargs = _common_kwargs()
    # Cluster 模式不支持 db 参数，移除
    kwargs.pop("decode_responses", None)

    client: RedisCluster = RedisCluster(
        startup_nodes=startup_nodes,
        password=settings.redis_password or None,
        skip_full_coverage_check=settings.redis_cluster_skip_full_coverage_check,
        read_from_replicas=settings.redis_cluster_read_from_replicas,
        socket_timeout=settings.redis_socket_timeout,
        socket_connect_timeout=settings.redis_socket_connect_timeout,
        retry_on_timeout=settings.redis_retry_on_timeout,
        retry_on_error=list(_RETRY_ERRORS),
        retry=_make_retry(),
        health_check_interval=settings.redis_health_check_interval,
        decode_responses=True,
        max_connections=settings.redis_max_connections,
    )
    await client.initialize()
    await client.ping()
    logger.info(
        "Redis[cluster] 已连接",
        nodes=[f"{h}:{p}" for h, p in nodes],
    )
    return client  # type: ignore[return-value]


async def _create_sentinel() -> aioredis.Redis:
    """
    Sentinel 模式。
    通过 Sentinel 自动发现当前主节点，写操作走主节点，
    read_from_replicas=True 时读操作可分流到从节点。
    """
    sentinel_nodes = settings.parsed_sentinel_nodes()
    if not sentinel_nodes:
        raise MemoryError("Sentinel 模式：REDIS_SENTINEL_NODES 未配置或格式错误")

    # Sentinel 自身的连接参数（注意：这是连 Sentinel 进程的，不是 Redis 实例）
    sentinel_kwargs: dict[str, Any] = {
        "socket_timeout": settings.redis_socket_timeout,
        "socket_connect_timeout": settings.redis_socket_connect_timeout,
        "decode_responses": True,
    }
    # 若 Sentinel 进程自身设了 requirepass
    if settings.redis_sentinel_password:
        sentinel_kwargs["password"] = settings.redis_sentinel_password

    sentinel = Sentinel(
        sentinels=sentinel_nodes,
        sentinel_kwargs=sentinel_kwargs,
        # 连接到实际 Redis 实例（主/从）时使用的参数
        password=settings.redis_password or None,
        socket_timeout=settings.redis_socket_timeout,
        socket_connect_timeout=settings.redis_socket_connect_timeout,
        retry_on_timeout=settings.redis_retry_on_timeout,
        retry_on_error=list(_RETRY_ERRORS),
        retry=_make_retry(),
        health_check_interval=settings.redis_health_check_interval,
        decode_responses=True,
        db=settings.redis_sentinel_db,
    )

    # master_for 返回的是异步 Redis 客户端，自动追踪主节点切换
    client: aioredis.Redis = sentinel.master_for(
        settings.redis_sentinel_master_name,
        redis_class=aioredis.Redis,
        connection_pool_class=aioredis.ConnectionPool,
        max_connections=settings.redis_max_connections,
    )
    await client.ping()
    logger.info(
        "Redis[sentinel] 已连接",
        master=settings.redis_sentinel_master_name,
        sentinels=[f"{h}:{p}" for h, p in sentinel_nodes],
    )
    return client


async def _create_redis_client() -> _RedisClient:
    """
    工厂函数：根据 REDIS_MODE 创建对应客户端。
    调用方只拿到 _RedisClient，无需关心模式。
    """
    mode = settings.redis_mode
    if mode == "standalone":
        return await _create_standalone()
    if mode == "cluster":
        return await _create_cluster()
    if mode == "sentinel":
        return await _create_sentinel()
    raise MemoryError(f"未知 redis_mode: {mode!r}")


# ──────────────────────────────────────────────────────────────────────────────
# RedisMemoryStore
# ──────────────────────────────────────────────────────────────────────────────

class RedisMemoryStore:
    """
    会话记忆存储。

    三种 Redis 模式对上层完全透明：
      - standalone：单机，适合本地开发
      - cluster：Redis Cluster，水平扩展
      - sentinel：主从 + 哨兵，高可用故障自动切换

    公共 API（模式无关）：
      load_history / append_turn / update_messages /
      set_summary / get_message_count / session_exists /
      delete_session / get_meta / set_meta
    """

    _instance: "RedisMemoryStore | None" = None

    def __init__(self) -> None:
        self._client: _RedisClient | None = None

    @classmethod
    def get_instance(cls) -> "RedisMemoryStore":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ── 生命周期 ──────────────────────────────────────────────────

    async def init(self) -> None:
        """应用启动时调用，建立连接并验证可用性。"""
        try:
            self._client = await _create_redis_client()
        except MemoryError:
            raise
        except Exception as exc:
            raise MemoryError(
                f"Redis[{settings.redis_mode}] 连接失败: {exc}"
            ) from exc

    async def close(self) -> None:
        """应用关闭时调用，释放连接池。"""
        if self._client is None:
            return
        try:
            if isinstance(self._client, RedisCluster):
                await self._client.aclose()
            else:
                await self._client.aclose()
            logger.info("Redis 连接已关闭", mode=settings.redis_mode)
        except Exception as exc:
            logger.warning("Redis 关闭时出错", error=str(exc))
        finally:
            self._client = None

    async def ping(self) -> bool:
        """健康检查，返回 True 表示连接正常。"""
        try:
            self._ensure()
            await self._client.ping()   # type: ignore[union-attr]
            return True
        except Exception:
            return False

    # ── 公共 API ──────────────────────────────────────────────────

    async def load_history(self, session_id: str) -> list[BaseMessage]:
        self._ensure()
        messages: list[BaseMessage] = []

        summary = await self._get_summary(session_id)
        if summary:
            messages.append(SystemMessage(content=f"[历史摘要]\n{summary}"))

        raw = await self._client.get(  # type: ignore[union-attr]
            _KEY_MSGS.format(sid=session_id)
        )
        if raw:
            try:
                messages.extend(messages_from_dict(json.loads(raw)))
            except Exception as exc:
                logger.warning(
                    "历史反序列化失败，重置",
                    session_id=session_id,
                    error=str(exc),
                )
        return messages

    async def append_turn(
        self,
        session_id: str,
        human: HumanMessage,
        ai: AIMessage,
    ) -> None:
        self._ensure()
        existing = await self._load_raw(session_id)
        existing.extend([human, ai])
        await self._save_msgs(session_id, existing)

    async def update_messages(
        self,
        session_id: str,
        messages: list[BaseMessage],
    ) -> None:
        self._ensure()
        filtered = [m for m in messages if not isinstance(m, SystemMessage)]
        await self._save_msgs(session_id, filtered)

    async def set_summary(self, session_id: str, summary: str) -> None:
        self._ensure()
        key = _KEY_SUMMARY.format(sid=session_id)
        await self._pipeline_set(key, summary, settings.session_ttl)

    async def get_message_count(self, session_id: str) -> int:
        return len(await self._load_raw(session_id))

    async def session_exists(self, session_id: str) -> bool:
        self._ensure()
        return bool(
            await self._client.exists(  # type: ignore[union-attr]
                _KEY_MSGS.format(sid=session_id)
            )
        )

    async def delete_session(self, session_id: str) -> None:
        self._ensure()
        keys = [
            _KEY_MSGS.format(sid=session_id),
            _KEY_SUMMARY.format(sid=session_id),
            _KEY_META.format(sid=session_id),
        ]
        await self._client.delete(*keys)   # type: ignore[union-attr]

    async def get_meta(self, session_id: str) -> dict[str, Any]:
        self._ensure()
        raw = await self._client.get(  # type: ignore[union-attr]
            _KEY_META.format(sid=session_id)
        )
        return json.loads(raw) if raw else {}

    async def set_meta(self, session_id: str, meta: dict[str, Any]) -> None:
        self._ensure()
        key = _KEY_META.format(sid=session_id)
        await self._pipeline_set(
            key,
            json.dumps(meta, ensure_ascii=False),
            settings.session_ttl,
        )

    # ── 内部方法 ──────────────────────────────────────────────────

    async def _load_raw(self, session_id: str) -> list[BaseMessage]:
        raw = await self._client.get(  # type: ignore[union-attr]
            _KEY_MSGS.format(sid=session_id)
        )
        if not raw:
            return []
        try:
            return messages_from_dict(json.loads(raw))
        except Exception:
            return []

    async def _save_msgs(
        self,
        session_id: str,
        msgs: list[BaseMessage],
    ) -> None:
        key = _KEY_MSGS.format(sid=session_id)
        value = json.dumps(messages_to_dict(msgs), ensure_ascii=False)
        await self._pipeline_set(key, value, settings.session_ttl)

    async def _get_summary(self, session_id: str) -> str:
        result = await self._client.get(  # type: ignore[union-attr]
            _KEY_SUMMARY.format(sid=session_id)
        )
        return result or ""

    async def _pipeline_set(self, key: str, value: str, ttl: int) -> None:
        """
        原子 SET + EXPIRE。

        Cluster 模式：pipeline 不支持跨 slot 操作，
        但 SET + EXPIRE 作用于同一个 key（同一 slot），可以安全使用 pipeline。
        """
        pipe = self._client.pipeline()  # type: ignore[union-attr]
        pipe.set(key, value)
        pipe.expire(key, ttl)
        await pipe.execute()

    def _ensure(self) -> None:
        if self._client is None:
            raise MemoryError(
                "RedisMemoryStore 未初始化，请先调用 await memory_store.init()"
            )


# ──────────────────────────────────────────────────────────────────────────────
# 会话压缩（与模式无关）
# ──────────────────────────────────────────────────────────────────────────────

async def maybe_compress_session(
    session_id: str,
    store: RedisMemoryStore,
    llm: Any,
) -> bool:
    """
    若消息数超过 summary_threshold，自动生成摘要并裁剪历史。
    返回 True 表示发生了压缩。
    """
    count = await store.get_message_count(session_id)
    if count < settings.summary_threshold:
        return False

    messages = await store._load_raw(session_id)
    keep_n = settings.summary_threshold // 2
    to_summarise, to_keep = messages[:-keep_n], messages[-keep_n:]

    lines = []
    for m in to_summarise:
        role = "用户" if isinstance(m, HumanMessage) else "助手"
        lines.append(f"{role}: {m.content}")

    resp = await llm.ainvoke(
        [HumanMessage(content=SUMMARISE_PROMPT.format(conversation="\n".join(lines)))]
    )
    summary = resp.content if hasattr(resp, "content") else str(resp)

    await store.set_summary(session_id, summary)
    await store.update_messages(session_id, to_keep)

    logger.info(
        "会话已压缩",
        session_id=session_id,
        before=count,
        after=len(to_keep),
    )
    return True


# 全局单例
memory_store = RedisMemoryStore.get_instance()
