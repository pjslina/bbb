"""
多数据库连接池管理器。
支持 PostgreSQL（主/从）、OpenGauss，动态场景路由。
"""
from __future__ import annotations
import contextlib
from typing import Any, AsyncIterator
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, create_async_engine
from app.core.config import settings
from app.core.exceptions import DatabaseError, DatabaseRouteError
from app.core.logging import get_logger

logger = get_logger(__name__)

# 场景 → 逻辑DB名 路由表（可在运行时动态修改）
DEFAULT_SCENE_ROUTES: dict[str, str] = {
    "default":           "pg_primary",
    "analytics":         "pg_secondary",
    "opengauss":         "og_primary",
    "opengauss_replica": "og_secondary",
}


class DatabasePoolManager:
    def __init__(self) -> None:
        self._engines: dict[str, AsyncEngine] = {}
        self._scene_routes: dict[str, str] = dict(DEFAULT_SCENE_ROUTES)
        self._initialized = False

    async def init(self) -> None:
        if self._initialized:
            return
        pool_sizes = {
            "pg_primary":   settings.pg_primary_pool_size,
            "pg_secondary": settings.pg_secondary_pool_size,
            "og_primary":   settings.og_primary_pool_size,
        }
        for name, dsn in settings.all_db_dsns.items():
            try:
                engine = create_async_engine(
                    dsn,
                    pool_size=pool_sizes.get(name, 5),
                    max_overflow=settings.pg_primary_max_overflow,
                    pool_pre_ping=True,
                    pool_recycle=1800,
                    echo=not settings.is_production,
                    connect_args=self._connect_args(name),
                )
                self._engines[name] = engine
                logger.info("DB连接池已创建", db=name)
            except Exception as exc:
                raise DatabaseError(f"创建引擎失败[{name}]: {exc}") from exc
        self._initialized = True

    async def close(self) -> None:
        for name, engine in self._engines.items():
            await engine.dispose()
            logger.info("DB连接池已关闭", db=name)
        self._engines.clear()
        self._initialized = False

    def register_route(self, scene: str, db_name: str) -> None:
        """动态注册场景路由"""
        if db_name not in self._engines:
            raise DatabaseError(f"目标DB {db_name!r} 未初始化")
        self._scene_routes[scene] = db_name
        logger.debug("DB路由已注册", scene=scene, db=db_name)

    def resolve_engine(self, scene: str = "default") -> AsyncEngine:
        db_name = self._scene_routes.get(scene)
        if not db_name:
            raise DatabaseRouteError(scene)
        engine = self._engines.get(db_name)
        if not engine:
            fallback = self._engines.get("pg_primary")
            if not fallback:
                raise DatabaseError("没有可用的数据库引擎")
            logger.warning("路由目标DB不存在，降级到pg_primary", scene=scene, db_name=db_name)
            return fallback
        return engine

    @contextlib.asynccontextmanager
    async def connect(self, scene: str = "default") -> AsyncIterator[AsyncConnection]:
        engine = self.resolve_engine(scene)
        async with engine.begin() as conn:
            yield conn

    @staticmethod
    def _connect_args(db_name: str) -> dict[str, Any]:
        base = {"server_settings": {"application_name": settings.app_name}}
        if "og" in db_name:
            base["server_settings"]["statement_timeout"] = "30000"
        return base

    def health(self) -> dict[str, str]:
        return {name: "up" if engine.pool else "unknown"
                for name, engine in self._engines.items()}


db_manager = DatabasePoolManager()
