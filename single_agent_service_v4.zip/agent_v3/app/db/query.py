"""
SQL模板引擎 — 支持完整 CRUD（SELECT / INSERT / UPDATE / DELETE）

安全原则（不变）：
  1. LLM 只能选择模板名称 + 提供参数，永远不能拼写 SQL
  2. 所有参数通过 SQLAlchemy text() 绑定，杜绝注入
  3. 写操作（INSERT/UPDATE/DELETE）额外记录审计日志
  4. 模板按"业务域"分组，便于管理

新增能力：
  - 支持 INSERT / UPDATE / DELETE 模板
  - 每个模板标注 operation_type，用于权限控制和审计
  - 写操作自动开启事务，失败自动回滚
"""
from __future__ import annotations

import re
from enum import Enum
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection

from app.core.exceptions import DatabaseError, SQLInjectionRisk
from app.core.logging import get_logger
from app.db.pool import db_manager

logger = get_logger(__name__)


class OperationType(str, Enum):
    READ = "read"
    WRITE = "write"      # INSERT / UPDATE / DELETE


# ===========================================================================
# SQL 模板注册表
# 格式：{ template_name: {"sql": "...", "op": OperationType, "desc": "..."} }
# ===========================================================================
_TEMPLATES: dict[str, dict[str, Any]] = {

    # ─── 大米库存 ────────────────────────────────────────────────────────────
    "query_rice_inventory": {
        "op": OperationType.READ,
        "desc": "查询用户的大米库存，返回剩余量、购买阈值、最近购买记录",
        "sql": """
            SELECT
                r.user_id,
                r.stock_kg,
                r.threshold_kg,
                r.last_purchased_at,
                r.last_purchase_qty_kg,
                r.updated_at
            FROM rice_inventory r
            WHERE r.user_id = :user_id
            LIMIT 1
        """,
        "params": {"user_id"},
    },

    "update_rice_stock": {
        "op": OperationType.WRITE,
        "desc": "更新大米库存数量（购买成功后调用）",
        "sql": """
            UPDATE rice_inventory
            SET
                stock_kg            = stock_kg + :added_kg,
                last_purchased_at   = NOW(),
                last_purchase_qty_kg = :added_kg,
                last_order_id       = :order_id,
                updated_at          = NOW()
            WHERE user_id = :user_id
        """,
        "params": {"user_id", "added_kg", "order_id"},
    },

    "insert_rice_purchase_log": {
        "op": OperationType.WRITE,
        "desc": "写入大米购买日志记录",
        "sql": """
            INSERT INTO rice_purchase_logs
                (user_id, order_id, qty_kg, price_yuan, purchased_at, source)
            VALUES
                (:user_id, :order_id, :qty_kg, :price_yuan, NOW(), :source)
        """,
        "params": {"user_id", "order_id", "qty_kg", "price_yuan", "source"},
    },

    "query_rice_purchase_history": {
        "op": OperationType.READ,
        "desc": "查询用户的大米购买历史",
        "sql": """
            SELECT order_id, qty_kg, price_yuan, purchased_at, source
            FROM rice_purchase_logs
            WHERE user_id = :user_id
            ORDER BY purchased_at DESC
            LIMIT :limit
        """,
        "params": {"user_id", "limit"},
    },

    # ─── 用户 ────────────────────────────────────────────────────────────────
    "get_user_by_id": {
        "op": OperationType.READ,
        "desc": "按ID查询用户基础信息",
        "sql": """
            SELECT id, username, email, created_at
            FROM users
            WHERE id = :user_id
            LIMIT 1
        """,
        "params": {"user_id"},
    },

    "list_users": {
        "op": OperationType.READ,
        "desc": "分页查询用户列表",
        "sql": """
            SELECT id, username, email, created_at
            FROM users
            ORDER BY created_at DESC
            LIMIT :limit OFFSET :offset
        """,
        "params": {"limit", "offset"},
    },

    # ─── 订单 ────────────────────────────────────────────────────────────────
    "get_orders_by_user": {
        "op": OperationType.READ,
        "desc": "查询用户的订单列表",
        "sql": """
            SELECT o.id, o.status, o.total_amount, o.created_at
            FROM orders o
            WHERE o.user_id = :user_id
              AND o.status = ANY(:statuses)
            ORDER BY o.created_at DESC
            LIMIT :limit
        """,
        "params": {"user_id", "statuses", "limit"},
    },

    "create_order": {
        "op": OperationType.WRITE,
        "desc": "创建新订单",
        "sql": """
            INSERT INTO orders (user_id, status, total_amount, created_at)
            VALUES (:user_id, 'pending', :total_amount, NOW())
            RETURNING id
        """,
        "params": {"user_id", "total_amount"},
    },

    "update_order_status": {
        "op": OperationType.WRITE,
        "desc": "更新订单状态",
        "sql": """
            UPDATE orders
            SET status = :new_status, updated_at = NOW()
            WHERE id = :order_id
              AND user_id = :user_id
        """,
        "params": {"order_id", "user_id", "new_status"},
    },

    # ─── 商品 ────────────────────────────────────────────────────────────────
    "search_products": {
        "op": OperationType.READ,
        "desc": "按分类和关键词搜索商品",
        "sql": """
            SELECT id, name, price, stock_quantity, category
            FROM products
            WHERE (:category IS NULL OR category = :category)
              AND (:keyword IS NULL OR name ILIKE :keyword)
            ORDER BY name
            LIMIT :limit
        """,
        "params": {"category", "keyword", "limit"},
        "nullable_params": {"category", "keyword"},
    },

    "update_product_stock": {
        "op": OperationType.WRITE,
        "desc": "更新商品库存数量",
        "sql": """
            UPDATE products
            SET stock_quantity = stock_quantity + :delta,
                updated_at = NOW()
            WHERE id = :product_id
        """,
        "params": {"product_id", "delta"},
    },

    # ─── 分析 ────────────────────────────────────────────────────────────────
    "daily_sales_summary": {
        "op": OperationType.READ,
        "desc": "查询每日销售汇总（路由到分析库）",
        "sql": """
            SELECT DATE_TRUNC('day', created_at) AS day,
                   COUNT(*) AS order_count,
                   SUM(total_amount) AS revenue
            FROM orders
            WHERE created_at >= :start_date
              AND created_at < :end_date
            GROUP BY 1
            ORDER BY 1
        """,
        "params": {"start_date", "end_date"},
        "scene": "analytics",   # 此模板默认路由到分析库
    },
}

# 危险关键词检测（防御纵深，主防线是模板隔离）
_DANGEROUS = re.compile(
    r"(--|;|/\*|\*/|xp_|exec\b|execute\b|drop\b|truncate\b|alter\b)",
    re.IGNORECASE,
)


def get_template_names(op_type: OperationType | None = None) -> list[str]:
    """返回所有（或指定操作类型的）模板名称，暴露给 LLM tool schema"""
    if op_type is None:
        return list(_TEMPLATES.keys())
    return [k for k, v in _TEMPLATES.items() if v["op"] == op_type]


def get_template_info(name: str) -> dict[str, Any]:
    if name not in _TEMPLATES:
        raise DatabaseError(f"未知SQL模板：{name!r}")
    t = _TEMPLATES[name]
    return {
        "name": name,
        "description": t.get("desc", ""),
        "operation_type": t["op"].value,
        "required_params": list(t["params"]),
        "scene": t.get("scene", "default"),
    }


async def execute_template(
    template_name: str,
    params: dict[str, Any],
    *,
    scene: str | None = None,
) -> list[dict[str, Any]] | dict[str, Any]:
    """
    执行命名SQL模板。

    - READ  → 返回 list[dict]（行列表）
    - WRITE → 返回 dict（rowcount + 可选returning）
    - 写操作自动在事务中执行，异常自动回滚

    Args:
        template_name: 模板名称
        params:        绑定参数
        scene:         路由场景，None=使用模板默认scene

    Returns:
        READ: [{"col": val, ...}, ...]
        WRITE: {"affected_rows": N, "returning": [...]}
    """
    _assert_safe(template_name, "template_name")
    for k, v in params.items():
        if isinstance(v, str):
            _assert_safe(v, f"param:{k}")

    if template_name not in _TEMPLATES:
        raise DatabaseError(f"SQL模板不存在：{template_name!r}")

    tmpl = _TEMPLATES[template_name]
    required = tmpl["params"] - tmpl.get("nullable_params", set())
    missing = required - set(params.keys())
    if missing:
        raise DatabaseError(f"模板 {template_name!r} 缺少必填参数：{missing}")

    # 路由优先级：调用方 scene > 模板默认 scene > "default"
    effective_scene = scene or tmpl.get("scene", "default")
    sql = text(tmpl["sql"])
    op = tmpl["op"]

    logger.info(
        "执行SQL模板",
        template=template_name,
        op=op.value,
        scene=effective_scene,
        params=list(params.keys()),
    )

    try:
        async with db_manager.connect(scene=effective_scene) as conn:
            result = await conn.execute(sql, params)

            if op == OperationType.READ:
                rows = result.mappings().all()
                return [dict(row) for row in rows]
            else:
                # 写操作：收集 RETURNING 行（如有）+ rowcount
                returning_rows: list[dict] = []
                if result.returns_rows:
                    returning_rows = [dict(r) for r in result.mappings().all()]

                logger.info(
                    "写操作完成",
                    template=template_name,
                    affected_rows=result.rowcount,
                    returning=len(returning_rows),
                )
                return {
                    "affected_rows": result.rowcount,
                    "returning": returning_rows,
                }
    except Exception as exc:
        logger.error("SQL模板执行失败", template=template_name, error=str(exc))
        raise DatabaseError(f"查询失败[{template_name}]: {exc}") from exc


def _assert_safe(value: str, context: str) -> None:
    if _DANGEROUS.search(value):
        logger.error("检测到SQL注入风险", context=context)
        raise SQLInjectionRisk()
