"""领域异常层次。所有自定义异常继承 AgentBaseError。"""
from __future__ import annotations


class AgentBaseError(Exception):
    def __init__(self, message: str, code: str = "AGENT_ERROR") -> None:
        super().__init__(message)
        self.message = message
        self.code = code

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code={self.code!r}, msg={self.message!r})"


class LLMError(AgentBaseError):
    def __init__(self, message: str) -> None:
        super().__init__(message, "LLM_ERROR")


class LLMTimeoutError(LLMError):
    def __init__(self) -> None:
        super().__init__("LLM 调用超时")
        self.code = "LLM_TIMEOUT"


class AgentMaxIterationsError(AgentBaseError):
    def __init__(self, max_iter: int) -> None:
        super().__init__(f"Agent 超出最大迭代次数({max_iter})", "MAX_ITERATIONS_EXCEEDED")


class AgentTimeoutError(AgentBaseError):
    def __init__(self, timeout: int) -> None:
        super().__init__(f"Agent 执行超时({timeout}s)", "AGENT_TIMEOUT")


class ToolCallLimitError(AgentBaseError):
    def __init__(self, limit: int) -> None:
        super().__init__(f"工具调用次数达到上限({limit})", "TOOL_CALL_LIMIT")


class ToolNotFoundError(AgentBaseError):
    def __init__(self, tool_name: str) -> None:
        super().__init__(f"工具不存在: {tool_name!r}", "TOOL_NOT_FOUND")


class ToolExecutionError(AgentBaseError):
    def __init__(self, tool_name: str, detail: str) -> None:
        super().__init__(f"工具 {tool_name!r} 执行失败: {detail}", "TOOL_EXECUTION_ERROR")


class DatabaseError(AgentBaseError):
    def __init__(self, message: str) -> None:
        super().__init__(message, "DB_ERROR")


class DatabaseRouteError(DatabaseError):
    def __init__(self, scene: str) -> None:
        super().__init__(f"没有为 scene={scene!r} 配置数据库路由")
        self.code = "DB_ROUTE_ERROR"


class SQLInjectionRisk(DatabaseError):
    def __init__(self) -> None:
        super().__init__("检测到 SQL 注入风险，请使用参数化模板")
        self.code = "SQL_INJECTION_RISK"


class MemoryError(AgentBaseError):
    def __init__(self, message: str) -> None:
        super().__init__(message, "MEMORY_ERROR")


class SessionNotFoundError(AgentBaseError):
    def __init__(self, session_id: str) -> None:
        super().__init__(f"会话不存在: {session_id!r}", "SESSION_NOT_FOUND")
