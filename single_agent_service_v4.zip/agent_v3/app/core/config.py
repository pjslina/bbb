"""集中配置，通过环境变量或 .env 文件加载。"""
from __future__ import annotations

from functools import lru_cache
from typing import Literal, Optional

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # App
    app_name: str = "single-agent"
    app_env: Literal["development", "production"] = "development"
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    log_level: str = "INFO"

    # LLM
    llm_provider: Literal["qwen", "glm", "openai"] = "qwen"
    llm_base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    llm_api_key: str = "sk-xxx"
    llm_model: str = "qwen-plus"
    llm_max_tokens: int = 4096
    llm_temperature: float = 0.7
    llm_timeout: int = 60

    # Redis 模式: standalone | cluster | sentinel
    redis_mode: Literal["standalone", "cluster", "sentinel"] = "standalone"
    redis_password: Optional[str] = None
    redis_max_connections: int = 20
    redis_socket_timeout: float = 5.0
    redis_socket_connect_timeout: float = 3.0
    redis_retry_on_timeout: bool = True
    redis_health_check_interval: int = 30
    redis_db: int = 0
    session_ttl: int = 86400
    summary_threshold: int = 20

    # Standalone
    redis_url: str = "redis://localhost:6379/0"

    # Cluster
    redis_cluster_nodes: str = ""
    redis_cluster_skip_full_coverage_check: bool = False
    redis_cluster_read_from_replicas: bool = False

    # Sentinel
    redis_sentinel_nodes: str = ""
    redis_sentinel_master_name: str = "mymaster"
    redis_sentinel_password: Optional[str] = None
    redis_sentinel_db: int = 0

    # PostgreSQL Primary
    pg_primary_dsn: str = "postgresql+asyncpg://user:password@localhost:5432/agentdb"
    pg_primary_pool_size: int = 10
    pg_primary_max_overflow: int = 20

    # PostgreSQL Secondary
    pg_secondary_dsn: Optional[str] = None
    pg_secondary_pool_size: int = 5

    # OpenGauss
    og_primary_dsn: Optional[str] = None
    og_primary_pool_size: int = 10
    og_secondary_dsn: Optional[str] = None

    # Agent safety
    agent_max_iterations: int = 10
    agent_timeout: int = 120
    agent_max_tool_calls: int = 5

    @field_validator("log_level")
    @classmethod
    def _validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        u = v.upper()
        if u not in allowed:
            raise ValueError(f"log_level must be one of {allowed}")
        return u

    @model_validator(mode="after")
    def _validate_redis_mode_config(self) -> "AppSettings":
        if self.redis_mode == "cluster" and not self.redis_cluster_nodes.strip():
            raise ValueError(
                "redis_mode=cluster 时必须配置 REDIS_CLUSTER_NODES，"
                "格式：host1:port1,host2:port2,..."
            )
        if self.redis_mode == "sentinel" and not self.redis_sentinel_nodes.strip():
            raise ValueError(
                "redis_mode=sentinel 时必须配置 REDIS_SENTINEL_NODES，"
                "格式：host1:port1,host2:port2,..."
            )
        return self

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def all_db_dsns(self) -> dict[str, str]:
        dsns: dict[str, str] = {"pg_primary": self.pg_primary_dsn}
        if self.pg_secondary_dsn:
            dsns["pg_secondary"] = self.pg_secondary_dsn
        if self.og_primary_dsn:
            dsns["og_primary"] = self.og_primary_dsn
        if self.og_secondary_dsn:
            dsns["og_secondary"] = self.og_secondary_dsn
        return dsns

    def parsed_cluster_nodes(self) -> list[tuple[str, int]]:
        return _parse_host_port_list(self.redis_cluster_nodes)

    def parsed_sentinel_nodes(self) -> list[tuple[str, int]]:
        return _parse_host_port_list(self.redis_sentinel_nodes)


def _parse_host_port_list(raw: str) -> list[tuple[str, int]]:
    nodes: list[tuple[str, int]] = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        parts = item.rsplit(":", 1)
        if len(parts) != 2:
            raise ValueError(f"节点格式错误: {item!r}，期望格式：host:port")
        host = parts[0].strip()
        try:
            port = int(parts[1].strip())
        except ValueError:
            raise ValueError(f"端口不是整数: {item!r}")
        if not (1 <= port <= 65535):
            raise ValueError(f"端口范围无效: {port}")
        nodes.append((host, port))
    return nodes


@lru_cache(maxsize=1)
def get_settings() -> AppSettings:
    return AppSettings()


settings: AppSettings = get_settings()
