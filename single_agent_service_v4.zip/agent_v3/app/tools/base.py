"""工具基类与可插拔注册中心。"""
from __future__ import annotations
import abc
import time
from typing import Any
from app.core.exceptions import ToolExecutionError, ToolNotFoundError
from app.core.logging import get_logger

logger = get_logger(__name__)


class BaseTool(abc.ABC):
    @property
    @abc.abstractmethod
    def name(self) -> str: ...

    @property
    @abc.abstractmethod
    def description(self) -> str: ...

    @abc.abstractmethod
    def tool_schema(self) -> dict[str, Any]: ...

    @abc.abstractmethod
    async def execute(self, **kwargs: Any) -> Any: ...


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        self._tools[tool.name] = tool
        logger.info("工具已注册", tool=tool.name)

    def unregister(self, name: str) -> None:
        self._tools.pop(name, None)

    def get(self, name: str) -> BaseTool:
        t = self._tools.get(name)
        if t is None:
            raise ToolNotFoundError(name)
        return t

    def all_schemas(self) -> list[dict[str, Any]]:
        return [t.tool_schema() for t in self._tools.values()]

    def names(self) -> list[str]:
        return list(self._tools.keys())

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    async def execute(self, name: str, **kwargs: Any) -> Any:
        tool = self.get(name)
        start = time.perf_counter()
        try:
            result = await tool.execute(**kwargs)
            logger.info("工具执行完成", tool=name,
                        elapsed_ms=round((time.perf_counter() - start) * 1000, 1))
            return result
        except ToolExecutionError:
            raise
        except Exception as exc:
            raise ToolExecutionError(name, str(exc)) from exc


tool_registry = ToolRegistry()
