"""通用工具：计算器、HTTP API调用。不属于任何具体业务场景，全局注册。"""
from __future__ import annotations
import ast
import operator as op
import os
import re
from typing import Any
from urllib.parse import urlparse

import httpx

from app.core.exceptions import ToolExecutionError
from app.core.logging import get_logger
from app.tools.base import BaseTool, tool_registry

logger = get_logger(__name__)

# ── 计算器 ────────────────────────────────────────────────────────────────────

_OPS: dict[type, Any] = {
    ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul,
    ast.Div: op.truediv, ast.Mod: op.mod, ast.Pow: op.pow,
    ast.FloorDiv: op.floordiv, ast.USub: op.neg, ast.UAdd: op.pos,
}


def _safe_eval(node: ast.AST) -> float:
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError(f"不支持的表达式节点: {ast.dump(node)}")


class CalculatorTool(BaseTool):
    """安全的算术计算器，通过 AST 解析，杜绝 eval() 注入。"""

    @property
    def name(self) -> str:
        return "calculator"

    @property
    def description(self) -> str:
        return "计算算术表达式，支持 +、-、*、/、**、//、%。"

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "expression": {"type": "string", "description": "算术表达式，如 '(12 + 3) * 4'"}
                    },
                    "required": ["expression"],
                },
            },
        }

    async def execute(self, expression: str, **_: Any) -> dict[str, Any]:
        expr = expression.strip()
        if not re.match(r"^[\d\s\+\-\*\/\(\)\.\%\*\*]+$", expr):
            raise ToolExecutionError(self.name, f"非法表达式: {expr!r}")
        try:
            tree = ast.parse(expr, mode="eval")
            result = _safe_eval(tree)
            return {"expression": expr, "result": result}
        except ZeroDivisionError:
            raise ToolExecutionError(self.name, "除数不能为零")
        except Exception as exc:
            raise ToolExecutionError(self.name, str(exc)) from exc


# ── 通用HTTP工具 ──────────────────────────────────────────────────────────────

# 允许调用的域名白名单（生产环境应从配置读取）
_ALLOWED_ORIGINS: set[str] = {
    o.strip()
    for o in os.getenv("HTTP_TOOL_ALLOWED_ORIGINS", "").split(",")
    if o.strip()
}
# 开发模式：若未配置白名单则允许所有（生产必须配置）
_DEV_MODE = not _ALLOWED_ORIGINS


class HttpApiTool(BaseTool):
    """
    通用 HTTP 工具（GET / POST）。
    生产环境必须通过 HTTP_TOOL_ALLOWED_ORIGINS 配置域名白名单。
    具体业务 API（天气、酒店、购买等）应创建专用 Tool，而非复用本工具。
    """

    @property
    def name(self) -> str:
        return "http_api"

    @property
    def description(self) -> str:
        return "调用外部 HTTP API（GET 或 POST）。仅用于白名单域名。"

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url":     {"type": "string", "description": "完整 URL"},
                        "method":  {"type": "string", "enum": ["GET", "POST"], "default": "GET"},
                        "payload": {"type": "object", "description": "POST 请求体（JSON）"},
                        "headers": {"type": "object", "description": "请求头"},
                    },
                    "required": ["url"],
                },
            },
        }

    async def execute(
        self,
        url: str,
        method: str = "GET",
        payload: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        **_: Any,
    ) -> dict[str, Any]:
        if not _DEV_MODE:
            origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
            if origin not in _ALLOWED_ORIGINS:
                raise ToolExecutionError(self.name, f"域名 {origin!r} 不在白名单中")
        async with httpx.AsyncClient(timeout=15.0) as client:
            if method.upper() == "POST":
                resp = await client.post(url, json=payload or {}, headers=headers or {})
            else:
                resp = await client.get(url, headers=headers or {})
            resp.raise_for_status()
            return resp.json()


def register_common_tools() -> None:
    """注册全局通用工具，在 main.py 启动时调用一次。"""
    tool_registry.register(CalculatorTool())
    tool_registry.register(HttpApiTool())
    logger.info("通用工具已注册", tools=["calculator", "http_api"])
