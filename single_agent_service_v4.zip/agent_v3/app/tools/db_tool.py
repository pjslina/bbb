"""
通用数据库查询工具（基于SQL模板注册表）。

LLM 通过此工具执行任何已注册的 SQL 模板（READ 或 WRITE）。
LLM 只能选择模板名称 + 提供参数，永远无法拼写原始 SQL。
"""
from __future__ import annotations
from typing import Any
from app.core.logging import get_logger
from app.db.query import OperationType, execute_template, get_template_info, get_template_names
from app.tools.base import BaseTool, tool_registry

logger = get_logger(__name__)


class DatabaseTool(BaseTool):
    """
    执行预批准的 SQL 模板（含读操作和写操作）。

    tool_schema 中动态列出所有已注册模板，LLM 只需选择名称和传入参数。
    写操作（UPDATE/INSERT/DELETE）自动在事务内执行。
    """

    @property
    def name(self) -> str:
        return "database_query"

    @property
    def description(self) -> str:
        read_names  = get_template_names(OperationType.READ)
        write_names = get_template_names(OperationType.WRITE)
        return (
            "执行预批准的 SQL 模板查询或写入数据库。\n"
            f"读模板（SELECT）: {', '.join(read_names)}\n"
            f"写模板（INSERT/UPDATE/DELETE）: {', '.join(write_names)}"
        )

    def tool_schema(self) -> dict[str, Any]:
        all_names = get_template_names()
        # 构建每个模板的简要描述，帮助 LLM 选择
        template_descriptions = {}
        for name in all_names:
            info = get_template_info(name)
            template_descriptions[name] = (
                f"[{info['operation_type'].upper()}] {info['description']} "
                f"(必填参数: {', '.join(info['required_params'])})"
            )

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "template_name": {
                            "type": "string",
                            "description": "SQL模板名称。各模板说明：\n" + "\n".join(
                                f"- {k}: {v}" for k, v in template_descriptions.items()
                            ),
                            "enum": all_names,
                        },
                        "params": {
                            "type": "object",
                            "description": "模板所需的绑定参数（key-value对）",
                        },
                        "scene": {
                            "type": "string",
                            "description": "数据库路由场景，默认'default'。可选：analytics（分析库），opengauss",
                            "default": "default",
                        },
                    },
                    "required": ["template_name", "params"],
                },
            },
        }

    async def execute(
        self,
        template_name: str,
        params: dict[str, Any],
        scene: str = "default",
        **_: Any,
    ) -> Any:
        logger.info("DatabaseTool执行", template=template_name, op_scene=scene)
        return await execute_template(template_name, params, scene=scene)


def register_db_tool() -> None:
    tool_registry.register(DatabaseTool())
    logger.info("DatabaseTool已注册")
