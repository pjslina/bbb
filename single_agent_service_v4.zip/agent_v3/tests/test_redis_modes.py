"""
Redis 三模式测试套件。
覆盖：配置解析、连接工厂、存储操作、健康检查。
运行：pytest tests/test_redis_modes.py -v --asyncio-mode=auto
"""
from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

import pytest
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage


# ============================================================
# 辅助：构造不同模式的 settings mock
# ============================================================

def _make_settings(**overrides: Any):
    from app.core.config import AppSettings
    defaults = {
        "redis_mode": "standalone",
        "redis_url": "redis://localhost:6379/0",
        "redis_password": None,
        "redis_max_connections": 10,
        "redis_socket_timeout": 5.0,
        "redis_socket_connect_timeout": 3.0,
        "redis_retry_on_timeout": True,
        "redis_health_check_interval": 30,
        "redis_db": 0,
        "session_ttl": 3600,
        "summary_threshold": 20,
        "redis_cluster_nodes": "",
        "redis_cluster_skip_full_coverage_check": False,
        "redis_cluster_read_from_replicas": False,
        "redis_sentinel_nodes": "",
        "redis_sentinel_master_name": "mymaster",
        "redis_sentinel_password": None,
        "redis_sentinel_db": 0,
    }
    defaults.update(overrides)
    # 绕过 pydantic model_validator 直接 mock
    m = MagicMock()
    for k, v in defaults.items():
        setattr(m, k, v)
    m.parsed_cluster_nodes.return_value = []
    m.parsed_sentinel_nodes.return_value = []
    return m


# ============================================================
# 1. 配置解析测试
# ============================================================

class TestConfigParsing:

    def test_parse_cluster_nodes_valid(self):
        from app.core.config import _parse_host_port_list
        result = _parse_host_port_list("192.168.1.1:7001,192.168.1.2:7002,192.168.1.3:7003")
        assert result == [
            ("192.168.1.1", 7001),
            ("192.168.1.2", 7002),
            ("192.168.1.3", 7003),
        ]

    def test_parse_nodes_with_spaces(self):
        from app.core.config import _parse_host_port_list
        result = _parse_host_port_list(" 127.0.0.1:7001 , 127.0.0.1:7002 ")
        assert result == [("127.0.0.1", 7001), ("127.0.0.1", 7002)]

    def test_parse_nodes_empty_string(self):
        from app.core.config import _parse_host_port_list
        assert _parse_host_port_list("") == []

    def test_parse_nodes_invalid_format(self):
        from app.core.config import _parse_host_port_list
        with pytest.raises(ValueError, match="格式错误"):
            _parse_host_port_list("192.168.1.1-7001")

    def test_parse_nodes_invalid_port(self):
        from app.core.config import _parse_host_port_list
        with pytest.raises(ValueError, match="端口不是整数"):
            _parse_host_port_list("192.168.1.1:abc")

    def test_parse_nodes_port_out_of_range(self):
        from app.core.config import _parse_host_port_list
        with pytest.raises(ValueError, match="端口范围无效"):
            _parse_host_port_list("192.168.1.1:99999")

    def test_config_cluster_requires_nodes(self):
        """cluster 模式缺少 REDIS_CLUSTER_NODES 时应校验失败。"""
        import os
        from pydantic import ValidationError
        env_backup = os.environ.copy()
        try:
            os.environ["REDIS_MODE"] = "cluster"
            os.environ.pop("REDIS_CLUSTER_NODES", None)
            from app.core.config import AppSettings
            with pytest.raises(ValidationError, match="REDIS_CLUSTER_NODES"):
                AppSettings()
        finally:
            os.environ.clear()
            os.environ.update(env_backup)

    def test_config_sentinel_requires_nodes(self):
        """sentinel 模式缺少 REDIS_SENTINEL_NODES 时应校验失败。"""
        import os
        from pydantic import ValidationError
        env_backup = os.environ.copy()
        try:
            os.environ["REDIS_MODE"] = "sentinel"
            os.environ.pop("REDIS_SENTINEL_NODES", None)
            from app.core.config import AppSettings
            with pytest.raises(ValidationError, match="REDIS_SENTINEL_NODES"):
                AppSettings()
        finally:
            os.environ.clear()
            os.environ.update(env_backup)


# ============================================================
# 2. 连接工厂测试（mock 实际连接）
# ============================================================

class TestConnectionFactory:

    @pytest.mark.asyncio
    async def test_standalone_factory(self):
        """standalone 模式：调用 ConnectionPool.from_url 并 ping。"""
        mock_client = AsyncMock()
        mock_client.ping = AsyncMock(return_value=True)
        mock_pool = MagicMock()

        with patch("app.memory.redis_store.settings") as mock_settings, \
             patch("redis.asyncio.ConnectionPool.from_url", return_value=mock_pool), \
             patch("redis.asyncio.Redis", return_value=mock_client):

            mock_settings.redis_mode = "standalone"
            mock_settings.redis_url = "redis://localhost:6379/0"
            mock_settings.redis_password = None
            mock_settings.redis_max_connections = 10
            mock_settings.redis_socket_timeout = 5.0
            mock_settings.redis_socket_connect_timeout = 3.0
            mock_settings.redis_retry_on_timeout = True
            mock_settings.redis_health_check_interval = 30
            mock_settings.redis_db = 0

            from app.memory.redis_store import _create_standalone
            result = await _create_standalone()

        mock_client.ping.assert_called_once()
        assert result is mock_client

    @pytest.mark.asyncio
    async def test_cluster_factory_no_nodes_raises(self):
        """cluster 模式节点为空时，工厂应抛出 MemoryError。"""
        with patch("app.memory.redis_store.settings") as mock_settings:
            mock_settings.redis_mode = "cluster"
            mock_settings.parsed_cluster_nodes.return_value = []

            from app.memory.redis_store import _create_cluster
            from app.core.exceptions import MemoryError as AgentMemoryError
            with pytest.raises(AgentMemoryError, match="REDIS_CLUSTER_NODES"):
                await _create_cluster()

    @pytest.mark.asyncio
    async def test_sentinel_factory_no_nodes_raises(self):
        """sentinel 模式节点为空时，工厂应抛出 MemoryError。"""
        with patch("app.memory.redis_store.settings") as mock_settings:
            mock_settings.redis_mode = "sentinel"
            mock_settings.parsed_sentinel_nodes.return_value = []

            from app.memory.redis_store import _create_sentinel
            from app.core.exceptions import MemoryError as AgentMemoryError
            with pytest.raises(AgentMemoryError, match="REDIS_SENTINEL_NODES"):
                await _create_sentinel()

    @pytest.mark.asyncio
    async def test_factory_dispatcher_standalone(self):
        """_create_redis_client 在 standalone 模式下调用 _create_standalone。"""
        mock_client = AsyncMock()
        with patch("app.memory.redis_store.settings") as ms, \
             patch("app.memory.redis_store._create_standalone", new_callable=AsyncMock,
                   return_value=mock_client) as mock_fn:
            ms.redis_mode = "standalone"
            from app.memory.redis_store import _create_redis_client
            result = await _create_redis_client()
        mock_fn.assert_called_once()
        assert result is mock_client

    @pytest.mark.asyncio
    async def test_factory_dispatcher_cluster(self):
        mock_client = AsyncMock()
        with patch("app.memory.redis_store.settings") as ms, \
             patch("app.memory.redis_store._create_cluster", new_callable=AsyncMock,
                   return_value=mock_client) as mock_fn:
            ms.redis_mode = "cluster"
            from app.memory.redis_store import _create_redis_client
            result = await _create_redis_client()
        mock_fn.assert_called_once()
        assert result is mock_client

    @pytest.mark.asyncio
    async def test_factory_dispatcher_sentinel(self):
        mock_client = AsyncMock()
        with patch("app.memory.redis_store.settings") as ms, \
             patch("app.memory.redis_store._create_sentinel", new_callable=AsyncMock,
                   return_value=mock_client) as mock_fn:
            ms.redis_mode = "sentinel"
            from app.memory.redis_store import _create_redis_client
            result = await _create_redis_client()
        mock_fn.assert_called_once()
        assert result is mock_client

    @pytest.mark.asyncio
    async def test_factory_unknown_mode_raises(self):
        from app.core.exceptions import MemoryError as AgentMemoryError
        with patch("app.memory.redis_store.settings") as ms:
            ms.redis_mode = "unknown_mode"
            from app.memory.redis_store import _create_redis_client
            with pytest.raises(AgentMemoryError, match="未知 redis_mode"):
                await _create_redis_client()


# ============================================================
# 3. RedisMemoryStore 操作测试（mock client）
# ============================================================

def _build_store_with_mock_client() -> tuple:
    """返回 (store, mock_client) 元组，client 已注入。"""
    from app.memory.redis_store import RedisMemoryStore

    store = RedisMemoryStore()
    mock_client = AsyncMock()

    # pipeline mock
    mock_pipe = AsyncMock()
    mock_pipe.set = MagicMock(return_value=mock_pipe)
    mock_pipe.expire = MagicMock(return_value=mock_pipe)
    mock_pipe.execute = AsyncMock(return_value=[True, True])
    mock_client.pipeline = MagicMock(return_value=mock_pipe)

    store._client = mock_client
    return store, mock_client, mock_pipe


class TestRedisMemoryStoreOps:

    @pytest.mark.asyncio
    async def test_ensure_raises_when_not_initialized(self):
        from app.memory.redis_store import RedisMemoryStore
        from app.core.exceptions import MemoryError as AgentMemoryError
        store = RedisMemoryStore()
        store._client = None
        with pytest.raises(AgentMemoryError, match="未初始化"):
            store._ensure()

    @pytest.mark.asyncio
    async def test_load_history_empty(self):
        store, mock_client, _ = _build_store_with_mock_client()
        mock_client.get = AsyncMock(return_value=None)
        result = await store.load_history("sess-001")
        assert result == []

    @pytest.mark.asyncio
    async def test_load_history_with_summary(self):
        store, mock_client, _ = _build_store_with_mock_client()
        # 第一次 get 返回 summary，第二次返回空消息
        mock_client.get = AsyncMock(side_effect=["这是历史摘要", None])
        result = await store.load_history("sess-001")
        assert len(result) == 1
        assert isinstance(result[0], SystemMessage)
        assert "历史摘要" in result[0].content

    @pytest.mark.asyncio
    async def test_append_turn(self):
        store, mock_client, mock_pipe = _build_store_with_mock_client()
        mock_client.get = AsyncMock(return_value=None)  # 空历史

        human = HumanMessage(content="你好")
        ai = AIMessage(content="你好！有什么可以帮您的？")
        await store.append_turn("sess-001", human, ai)

        # pipeline.set 应被调用一次（保存序列化消息）
        mock_pipe.set.assert_called_once()
        mock_pipe.expire.assert_called_once()
        mock_pipe.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_session_exists_true(self):
        store, mock_client, _ = _build_store_with_mock_client()
        mock_client.exists = AsyncMock(return_value=1)
        assert await store.session_exists("sess-001") is True

    @pytest.mark.asyncio
    async def test_session_exists_false(self):
        store, mock_client, _ = _build_store_with_mock_client()
        mock_client.exists = AsyncMock(return_value=0)
        assert await store.session_exists("sess-001") is False

    @pytest.mark.asyncio
    async def test_delete_session(self):
        store, mock_client, _ = _build_store_with_mock_client()
        mock_client.delete = AsyncMock(return_value=3)
        await store.delete_session("sess-001")
        mock_client.delete.assert_called_once()
        # 应删除 messages、summary、meta 三个 key
        args = mock_client.delete.call_args[0]
        assert len(args) == 3
        assert all("sess-001" in k for k in args)

    @pytest.mark.asyncio
    async def test_get_meta_empty(self):
        store, mock_client, _ = _build_store_with_mock_client()
        mock_client.get = AsyncMock(return_value=None)
        result = await store.get_meta("sess-001")
        assert result == {}

    @pytest.mark.asyncio
    async def test_get_meta_with_data(self):
        store, mock_client, _ = _build_store_with_mock_client()
        mock_client.get = AsyncMock(
            return_value=json.dumps({"user_id": "alice", "lang": "zh"})
        )
        result = await store.get_meta("sess-001")
        assert result["user_id"] == "alice"

    @pytest.mark.asyncio
    async def test_set_meta(self):
        store, mock_client, mock_pipe = _build_store_with_mock_client()
        await store.set_meta("sess-001", {"user_id": "bob"})
        mock_pipe.set.assert_called_once()
        mock_pipe.expire.assert_called_once()

    @pytest.mark.asyncio
    async def test_ping_success(self):
        store, mock_client, _ = _build_store_with_mock_client()
        mock_client.ping = AsyncMock(return_value=True)
        assert await store.ping() is True

    @pytest.mark.asyncio
    async def test_ping_failure(self):
        store, mock_client, _ = _build_store_with_mock_client()
        mock_client.ping = AsyncMock(side_effect=Exception("连接失败"))
        assert await store.ping() is False

    @pytest.mark.asyncio
    async def test_get_message_count(self):
        from langchain_core.messages import messages_to_dict
        store, mock_client, _ = _build_store_with_mock_client()

        msgs = [
            HumanMessage(content="问1"),
            AIMessage(content="答1"),
            HumanMessage(content="问2"),
            AIMessage(content="答2"),
        ]
        mock_client.get = AsyncMock(
            return_value=json.dumps(messages_to_dict(msgs))
        )
        count = await store.get_message_count("sess-001")
        assert count == 4

    @pytest.mark.asyncio
    async def test_update_messages_filters_system(self):
        """update_messages 应过滤掉 SystemMessage（避免将摘要注入存储层）。"""
        store, mock_client, mock_pipe = _build_store_with_mock_client()
        msgs = [
            SystemMessage(content="[历史摘要]..."),
            HumanMessage(content="问"),
            AIMessage(content="答"),
        ]
        await store.update_messages("sess-001", msgs)
        # 获取实际存入的 JSON
        set_call_args = mock_pipe.set.call_args[0]
        stored_json = set_call_args[1]
        stored = json.loads(stored_json)
        # SystemMessage 不应出现在存储中
        types = [m["type"] for m in stored]
        assert "system" not in types
        assert len(stored) == 2


# ============================================================
# 4. 会话压缩测试
# ============================================================

class TestMaybeCompressSession:

    @pytest.mark.asyncio
    async def test_no_compression_below_threshold(self):
        from app.memory.redis_store import maybe_compress_session
        store = AsyncMock()
        store.get_message_count = AsyncMock(return_value=5)  # 低于阈值

        with patch("app.memory.redis_store.settings") as ms:
            ms.summary_threshold = 20
            result = await maybe_compress_session("sess-001", store, AsyncMock())

        assert result is False
        store.set_summary.assert_not_called()

    @pytest.mark.asyncio
    async def test_compression_above_threshold(self):
        from app.memory.redis_store import maybe_compress_session
        from langchain_core.messages import messages_to_dict

        msgs = [HumanMessage(content=f"问{i}") for i in range(25)] + \
               [AIMessage(content=f"答{i}") for i in range(25)]

        store = AsyncMock()
        store.get_message_count = AsyncMock(return_value=len(msgs))
        store._load_raw = AsyncMock(return_value=msgs)
        store.set_summary = AsyncMock()
        store.update_messages = AsyncMock()

        mock_llm = AsyncMock()
        mock_resp = MagicMock()
        mock_resp.content = "这是生成的摘要"
        mock_llm.ainvoke = AsyncMock(return_value=mock_resp)

        with patch("app.memory.redis_store.settings") as ms:
            ms.summary_threshold = 20
            result = await maybe_compress_session("sess-001", store, mock_llm)

        assert result is True
        store.set_summary.assert_called_once_with("sess-001", "这是生成的摘要")
        store.update_messages.assert_called_once()
        # 保留的消息数应为 threshold // 2 = 10
        kept_msgs = store.update_messages.call_args[0][1]
        assert len(kept_msgs) == 10
