"""
完整测试套件，覆盖三个核心缺口的修复验证。

运行：pytest tests/ -v --asyncio-mode=auto
"""
from __future__ import annotations
import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch
import pytest


# ============================================================================
# 缺口1：数据库写操作测试
# ============================================================================

class TestDatabaseWriteOperations:
    """验证 db/query.py 支持完整 CRUD。"""

    def test_template_registry_has_write_templates(self):
        from app.db.query import OperationType, get_template_names
        write_templates = get_template_names(OperationType.WRITE)
        assert "update_rice_stock" in write_templates
        assert "insert_rice_purchase_log" in write_templates
        assert "create_order" in write_templates
        assert "update_order_status" in write_templates

    def test_template_registry_has_read_templates(self):
        from app.db.query import OperationType, get_template_names
        read_templates = get_template_names(OperationType.READ)
        assert "query_rice_inventory" in read_templates
        assert "get_user_by_id" in read_templates

    def test_write_template_info(self):
        from app.db.query import get_template_info
        info = get_template_info("update_rice_stock")
        assert info["operation_type"] == "write"
        assert "user_id" in info["required_params"]
        assert "added_kg" in info["required_params"]
        assert "order_id" in info["required_params"]

    def test_read_template_info(self):
        from app.db.query import get_template_info
        info = get_template_info("query_rice_inventory")
        assert info["operation_type"] == "read"
        assert "user_id" in info["required_params"]

    def test_unknown_template_raises(self):
        from app.core.exceptions import DatabaseError
        from app.db.query import get_template_info
        with pytest.raises(DatabaseError):
            get_template_info("nonexistent_template")

    def test_injection_detection(self):
        from app.core.exceptions import SQLInjectionRisk
        from app.db.query import _assert_safe
        with pytest.raises(SQLInjectionRisk):
            _assert_safe("'; DROP TABLE rice_inventory; --", "test")

    def test_safe_value_passes(self):
        from app.db.query import _assert_safe
        _assert_safe("user_123", "test")      # 正常值不应报错
        _assert_safe("ORDER-ABC123", "test")  # 订单ID不应报错

    def test_missing_required_params_detected(self):
        """模板参数校验：缺少必填参数时应明确报错而非静默执行。"""
        from app.db.query import _TEMPLATES
        tmpl = _TEMPLATES["update_rice_stock"]
        required = tmpl["params"] - tmpl.get("nullable_params", set())
        # 模拟调用方只提供了 user_id，缺少 added_kg 和 order_id
        provided = {"user_id"}
        missing = required - provided
        assert "added_kg" in missing
        assert "order_id" in missing


# ============================================================================
# 缺口2：场景化体系测试
# ============================================================================

class TestScenarioSystem:
    """验证场景注册、工具注入、意图路由。"""

    def test_base_scenario_abstract(self):
        """BaseScenario 不能直接实例化。"""
        from app.scenarios.base import BaseScenario
        import pytest
        with pytest.raises(TypeError):
            BaseScenario()  # type: ignore

    def test_rice_scenario_properties(self):
        from app.scenarios.rice.scenario import RiceInventoryScenario
        s = RiceInventoryScenario()
        assert s.name == "rice_inventory"
        assert "rice_inventory_query" in s.intent_labels
        assert "rice_purchase_decision" in s.intent_labels
        assert len(s.tools) == 3
        tool_names = [t.name for t in s.tools]
        assert "query_rice_inventory" in tool_names
        assert "purchase_rice" in tool_names
        assert "update_rice_stock" in tool_names

    def test_weather_hotel_scenario_properties(self):
        from app.scenarios.weather_hotel.scenario import WeatherHotelScenario
        s = WeatherHotelScenario()
        assert s.name == "weather_hotel"
        assert "weather_query" in s.intent_labels
        assert "weather_then_hotel" in s.intent_labels
        tool_names = [t.name for t in s.tools]
        assert "get_weather" in tool_names
        assert "search_hotels" in tool_names

    def test_scenario_registry_register_and_query(self):
        from app.scenarios.base import ScenarioRegistry
        from app.scenarios.rice.scenario import RiceInventoryScenario
        from app.tools.base import ToolRegistry

        # 用独立的 registry 避免污染全局状态
        reg = ScenarioRegistry()
        # 手动替换 tool_registry 以避免重复注册
        with patch("app.scenarios.base.tool_registry", ToolRegistry()):
            reg.register(RiceInventoryScenario())

        assert "rice_inventory" in reg.all_names()
        scenario = reg.get_scenario_for_intent("rice_inventory_query")
        assert scenario is not None
        assert scenario.name == "rice_inventory"

    def test_scenario_registry_all_intent_labels(self):
        from app.scenarios.base import ScenarioRegistry
        from app.scenarios.rice.scenario import RiceInventoryScenario
        from app.tools.base import ToolRegistry

        reg = ScenarioRegistry()
        with patch("app.scenarios.base.tool_registry", ToolRegistry()):
            reg.register(RiceInventoryScenario())

        labels = [item["label"] for item in reg.all_intent_labels()]
        assert "rice_inventory_query" in labels
        assert "general_chat" in labels   # 通用意图始终存在
        assert "unknown" in labels

    def test_scenario_prompt_extra_not_empty(self):
        from app.scenarios.rice.scenario import RiceInventoryScenario
        s = RiceInventoryScenario()
        assert "库存" in s.system_prompt_extra
        assert "purchase_rice" in s.system_prompt_extra

    def test_unknown_intent_returns_none(self):
        from app.scenarios.base import ScenarioRegistry
        reg = ScenarioRegistry()
        result = reg.get_scenario_for_intent("nonexistent_intent_xyz")
        assert result is None

    def test_scenario_unregister(self):
        from app.scenarios.base import ScenarioRegistry
        from app.scenarios.rice.scenario import RiceInventoryScenario
        from app.tools.base import ToolRegistry

        reg = ScenarioRegistry()
        with patch("app.scenarios.base.tool_registry", ToolRegistry()):
            reg.register(RiceInventoryScenario())

        assert "rice_inventory" in reg.all_names()
        reg.unregister("rice_inventory")
        assert "rice_inventory" not in reg.all_names()


# ============================================================================
# 缺口3：动态意图识别测试
# ============================================================================

class TestDynamicIntentRecognition:
    """验证意图提示词动态生成，新场景自动扩展。"""

    def test_intent_prompt_includes_rice_labels(self):
        from app.scenarios.base import ScenarioRegistry
        from app.scenarios.rice.scenario import RiceInventoryScenario
        from app.tools.base import ToolRegistry
        from app.agent.nodes import _build_intent_system_prompt

        reg = ScenarioRegistry()
        with patch("app.scenarios.base.tool_registry", ToolRegistry()), \
             patch("app.agent.nodes.scenario_registry", reg):
            reg.register(RiceInventoryScenario())
            prompt = _build_intent_system_prompt()

        assert "rice_inventory_query" in prompt
        assert "rice_purchase_decision" in prompt
        assert "general_chat" in prompt

    def test_intent_prompt_auto_extends_with_new_scenario(self):
        """新增场景后，意图提示词自动包含新意图，无需改 nodes.py。"""
        from app.scenarios.base import BaseScenario, ScenarioRegistry
        from app.tools.base import BaseTool, ToolRegistry
        from app.agent.nodes import _build_intent_system_prompt

        class MockTool(BaseTool):
            @property
            def name(self): return "mock_tool"
            @property
            def description(self): return "Mock"
            def tool_schema(self): return {"type": "function", "function": {"name": "mock_tool", "description": "Mock", "parameters": {"type": "object", "properties": {}, "required": []}}}
            async def execute(self, **kwargs): return {}

        class NewScenario(BaseScenario):
            @property
            def name(self): return "flight_booking"
            @property
            def description(self): return "机票预订场景"
            @property
            def intent_labels(self): return ["book_flight", "check_flight_status"]
            @property
            def tools(self): return [MockTool()]

        reg = ScenarioRegistry()
        with patch("app.scenarios.base.tool_registry", ToolRegistry()), \
             patch("app.agent.nodes.scenario_registry", reg):
            reg.register(NewScenario())
            prompt = _build_intent_system_prompt()

        # 新场景的意图标签必须出现在提示词中
        assert "book_flight" in prompt
        assert "check_flight_status" in prompt
        assert "机票预订" in prompt

    def test_routing_logic(self):
        """缺少工具时 should_use_tool=False，有工具时=True。"""
        from app.agent.nodes import route_after_tool_decision
        from app.agent.state import AgentState

        no_tool_state = AgentState(should_use_tool=False)
        assert route_after_tool_decision(no_tool_state) == "llm_answer"

        tool_state = AgentState(should_use_tool=True)
        assert route_after_tool_decision(tool_state) == "tool_router"

    def test_conditional_loop_routing(self):
        """tool_executor 后路由：未超限回 tool_router，超限进 llm_answer。"""
        from app.agent.nodes import route_after_tool_executor
        from app.agent.state import AgentState
        from app.core.config import settings

        under_limit = AgentState(tool_call_count=1)
        assert route_after_tool_executor(under_limit) == "tool_router"

        at_limit = AgentState(tool_call_count=settings.agent_max_tool_calls)
        assert route_after_tool_executor(at_limit) == "llm_answer"


# ============================================================================
# 大米场景工具单元测试
# ============================================================================

class TestRiceTools:

    @pytest.fixture
    def query_tool(self):
        from app.scenarios.rice.tools import QueryRiceInventoryTool
        return QueryRiceInventoryTool()

    @pytest.fixture
    def purchase_tool(self):
        from app.scenarios.rice.tools import PurchaseRiceTool
        return PurchaseRiceTool()

    @pytest.fixture
    def update_tool(self):
        from app.scenarios.rice.tools import UpdateRiceStockTool
        return UpdateRiceStockTool()

    def test_query_tool_schema(self, query_tool):
        schema = query_tool.tool_schema()
        assert schema["function"]["name"] == "query_rice_inventory"
        assert "user_id" in schema["function"]["parameters"]["required"]

    def test_purchase_tool_schema(self, purchase_tool):
        schema = purchase_tool.tool_schema()
        assert schema["function"]["name"] == "purchase_rice"
        assert "user_id" in schema["function"]["parameters"]["required"]

    def test_update_tool_schema(self, update_tool):
        schema = update_tool.tool_schema()
        assert schema["function"]["name"] == "update_rice_stock"
        required = schema["function"]["parameters"]["required"]
        assert "user_id" in required
        assert "order_id" in required
        assert "added_kg" in required

    @pytest.mark.asyncio
    async def test_purchase_mock_returns_order(self, purchase_tool):
        result = await purchase_tool.execute(user_id="user1", qty_kg=10.0)
        assert result["success"] is True
        assert "order_id" in result
        assert result["order_id"].startswith("ORDER-")
        assert result["qty_kg"] == 10.0

    @pytest.mark.asyncio
    async def test_query_no_record_returns_needs_purchase(self, query_tool):
        """用户没有库存记录时，默认返回需要购买。"""
        with patch("app.scenarios.rice.tools.execute_template", new_callable=AsyncMock) as mock_exec:
            mock_exec.return_value = []  # 空记录
            result = await query_tool.execute(user_id="new_user")
        assert result["needs_purchase"] is True
        assert result["stock_kg"] == 0.0

    @pytest.mark.asyncio
    async def test_query_sufficient_stock(self, query_tool):
        with patch("app.scenarios.rice.tools.execute_template", new_callable=AsyncMock) as mock_exec:
            mock_exec.return_value = [{
                "user_id": "user1",
                "stock_kg": "8.5",
                "threshold_kg": "5.0",
                "last_purchased_at": None,
                "last_purchase_qty_kg": None,
            }]
            result = await query_tool.execute(user_id="user1")
        assert result["needs_purchase"] is False
        assert result["status"] == "sufficient"
        assert result["stock_kg"] == 8.5

    @pytest.mark.asyncio
    async def test_query_low_stock(self, query_tool):
        with patch("app.scenarios.rice.tools.execute_template", new_callable=AsyncMock) as mock_exec:
            mock_exec.return_value = [{
                "user_id": "user1",
                "stock_kg": "2.3",
                "threshold_kg": "5.0",
                "last_purchased_at": None,
                "last_purchase_qty_kg": None,
            }]
            result = await query_tool.execute(user_id="user1")
        assert result["needs_purchase"] is True
        assert result["status"] == "low"

    @pytest.mark.asyncio
    async def test_update_stock_calls_two_templates(self, update_tool):
        """更新库存工具必须同时调用 update_rice_stock 和 insert_rice_purchase_log。"""
        call_log = []
        async def mock_exec(template_name, params, **kwargs):
            call_log.append(template_name)
            if template_name == "update_rice_stock":
                return {"affected_rows": 1, "returning": []}
            return {"affected_rows": 1, "returning": []}

        with patch("app.scenarios.rice.tools.execute_template", side_effect=mock_exec):
            result = await update_tool.execute(
                user_id="user1", order_id="ORDER-ABC", added_kg=10.0, price_yuan=85.0
            )
        assert result["success"] is True
        assert "update_rice_stock" in call_log
        assert "insert_rice_purchase_log" in call_log


# ============================================================================
# 天气&酒店场景工具测试
# ============================================================================

class TestWeatherHotelTools:

    @pytest.mark.asyncio
    async def test_weather_sunny_city(self):
        from app.scenarios.weather_hotel.tools import WeatherTool
        tool = WeatherTool()
        result = await tool.execute(city="北京")
        assert result["is_outdoor_friendly"] is True
        assert result["condition"] == "晴"

    @pytest.mark.asyncio
    async def test_weather_cloudy_city(self):
        from app.scenarios.weather_hotel.tools import WeatherTool
        tool = WeatherTool()
        result = await tool.execute(city="成都")
        assert result["is_outdoor_friendly"] is False

    @pytest.mark.asyncio
    async def test_hotel_returns_sorted_by_value(self):
        from app.scenarios.weather_hotel.tools import HotelSearchTool
        tool = HotelSearchTool()
        result = await tool.execute(city="北京", sort_by="value_for_money")
        hotels = result["hotels"]
        assert len(hotels) > 0
        scores = [h["value_score"] for h in hotels]
        assert scores == sorted(scores, reverse=True)

    @pytest.mark.asyncio
    async def test_hotel_budget_filter(self):
        from app.scenarios.weather_hotel.tools import HotelSearchTool
        tool = HotelSearchTool()
        result = await tool.execute(city="北京", budget_cny=300)
        for h in result["hotels"]:
            assert h["price_per_night_cny"] <= 300


# ============================================================================
# 场景自动扫描测试
# ============================================================================

class TestScenarioLoader:

    def test_loader_discovers_rice_scenario(self):
        """自动扫描应发现 rice 场景。"""
        from app.scenarios.base import ScenarioRegistry
        from app.tools.base import ToolRegistry

        fresh_reg = ScenarioRegistry()
        fresh_tool_reg = ToolRegistry()

        with patch("app.scenarios.base.tool_registry", fresh_tool_reg), \
             patch("app.scenarios.loader.scenario_registry", fresh_reg):
            from app.scenarios import loader
            loader.discover_and_register_scenarios()

        assert "rice_inventory" in fresh_reg.all_names()
        assert "weather_hotel" in fresh_reg.all_names()

    def test_loader_does_not_crash_on_missing_scenario_file(self):
        """子目录没有 scenario.py 时不应崩溃。"""
        from app.scenarios.loader import discover_and_register_scenarios
        # 已有 __init__.py 但没有 scenario.py 的目录（utils等）不应导致崩溃
        discover_and_register_scenarios()  # 不应抛出异常
