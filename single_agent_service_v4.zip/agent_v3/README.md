# Single Agent Service

生产级单 Agent 智能体服务。基于 **LangGraph + FastAPI** 构建，支持多业务场景插拔、双通道流式（SSE + WebSocket）、多数据库读写、多轮对话记忆。

---

## 目录结构

```
agent_v3/
├── app/
│   ├── agent/
│   │   ├── state.py          # AgentState TypedDict（LangGraph 共享状态）
│   │   ├── nodes.py          # 5 个图节点 + 路由函数（核心逻辑）
│   │   └── graph.py          # StateGraph 构建 + AgentRunner
│   ├── api/
│   │   ├── models.py         # Pydantic 请求/响应模型
│   │   ├── routes.py         # REST 端点（同步对话、会话管理、健康检查）
│   │   ├── sse.py            # SSE 流式端点
│   │   └── websocket.py      # WebSocket 双向流式端点
│   ├── core/
│   │   ├── config.py         # 集中配置（pydantic-settings）
│   │   ├── exceptions.py     # 领域异常层次
│   │   └── logging.py        # 结构化日志（structlog）
│   ├── db/
│   │   ├── pool.py           # 多数据库连接池 + 动态路由（PG / OpenGauss）
│   │   └── query.py          # SQL 模板引擎（READ + WRITE，防注入）
│   ├── llm/
│   │   └── adapter.py        # 统一 LLM 适配器（Qwen / GLM / OpenAI）
│   ├── memory/
│   │   └── redis_store.py    # Redis 会话记忆 + 摘要压缩
│   ├── scenarios/            # ← 业务场景插拔目录
│   │   ├── base.py           # BaseScenario 基类 + ScenarioRegistry
│   │   ├── loader.py         # 自动扫描注册（新增场景无需改代码）
│   │   ├── rice/             # 大米库存管理场景
│   │   │   ├── tools.py      # QueryRiceInventoryTool / PurchaseRiceTool / UpdateRiceStockTool
│   │   │   └── scenario.py   # 场景意图标签 + 工具列表 + 专属规则
│   │   └── weather_hotel/    # 天气 + 酒店推荐场景
│   │       ├── tools.py      # WeatherTool / HotelSearchTool
│   │       └── scenario.py
│   ├── tools/
│   │   ├── base.py           # BaseTool 基类 + ToolRegistry
│   │   ├── common_tools.py   # 通用工具：CalculatorTool、HttpApiTool
│   │   └── db_tool.py        # DatabaseTool（代理所有 SQL 模板）
│   └── main.py               # FastAPI 应用工厂 + lifespan
├── tests/
│   └── test_full.py          # 完整测试套件（覆盖三大核心缺口）
├── scripts/
│   ├── init_db.sql           # 数据库建表 + 种子数据
│   ├── run_dev.sh            # 开发模式启动
│   └── run_prod.sh           # 生产模式启动（Gunicorn）
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml    # Agent + Redis + PostgreSQL
├── requirements.txt
├── pytest.ini
└── .env.example
```

---

## 核心架构

### LangGraph 图拓扑（含条件工具链循环）

```
START
  └─► intent_recognition      # 动态识别意图（从场景注册表读取全量标签）
  └─► tool_decision           # 判断是否需要工具
      ├─► llm_answer          # 无工具意图（general_chat 等）
      └─► tool_router         # 选择下一个工具（每次只选一个）
          ├─► llm_answer      # LLM 判断信息已足够
          └─► tool_executor   # 执行工具
              ├─► llm_answer  # 达到工具调用上限
              └─► tool_router ← 关键循环（条件链式调用）
  └─► llm_answer              # 整合工具结果，生成自然语言回答
  └─► memory_update           # 持久化到 Redis + 摘要压缩
END
```

### 大米场景调用链路示例

```
用户："家里还有多少大米，要不要买？"

第1轮 tool_router → query_rice_inventory（查库存）
  ↓ 结果：{stock_kg: 2.0, threshold_kg: 5.0, needs_purchase: true}

第2轮 tool_router → 库存不足 → purchase_rice（调购买API）
  ↓ 结果：{success: true, order_id: "ORDER-XXXX", qty_kg: 10}

第3轮 tool_router → 购买成功 → update_rice_stock（写库）
  ↓ 结果：{affected_rows: 1, message: "库存已更新"}

第4轮 tool_router → 所有步骤完成 → 返回空调用

llm_answer → "您家里现在有2公斤大米，低于补货线(5公斤)。
              我已经帮您购买了10公斤，订单号 ORDER-XXXX，
              预计明天下午送达。更新后库存将达到12公斤。"
```

---

## 快速开始

### 方式一：本地开发

```bash
# 1. 克隆项目、创建虚拟环境
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env，填入 LLM_API_KEY 等

# 3. 启动依赖（Redis + PostgreSQL）
docker compose -f docker/docker-compose.yml up redis postgres -d

# 4. 初始化数据库
psql -U agent -d agentdb -h localhost -f scripts/init_db.sql

# 5. 启动 Agent 服务
bash scripts/run_dev.sh
```

### 方式二：Docker Compose 一键启动

```bash
cp .env.example .env
# 编辑 .env，填入 LLM_API_KEY

docker compose -f docker/docker-compose.yml up --build
```

---

## API 使用

### 同步对话（REST）

```bash
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "user-alice",
    "user_id": "alice",
    "message": "家里还有多少大米，要不要现在去购买？"
  }'
```

### 调试模式（查看完整工具调用链路）

```bash
curl -X POST http://localhost:8000/api/v1/chat/debug \
  -H "Content-Type: application/json" \
  -d '{"session_id": "user-alice", "user_id": "alice", "message": "帮我买10公斤大米"}'

# 返回示例：
# {
#   "intent": "rice_purchase_direct",
#   "tool_results": [
#     {"tool": "query_rice_inventory", "status": "success", ...},
#     {"tool": "purchase_rice",        "status": "success", ...},
#     {"tool": "update_rice_stock",    "status": "success", ...}
#   ],
#   "tool_call_count": 3,
#   "final_answer": "已为您购买10公斤东北五常大米..."
# }
```

### SSE 流式对话

```bash
curl -N -X POST http://localhost:8000/api/v1/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"session_id": "user-alice", "message": "今天北京天气怎么样？如果晴天帮我找个酒店"}'

# 输出流：
# data: {"type":"metadata", ...}
# data: {"type":"token","data":"北京今天"}
# data: {"type":"token","data":"天气晴朗"}
# ...
# data: {"type":"done", ...}
```

### WebSocket 对话

```javascript
const ws = new WebSocket('ws://localhost:8000/ws/user-alice');

ws.onopen = () => ws.send(JSON.stringify({
    type: 'chat',
    user_id: 'alice',
    message: '家里大米还剩多少？'
}));

ws.onmessage = (e) => {
    const ev = JSON.parse(e.data);
    if (ev.type === 'token')    process.stdout.write(ev.data);
    if (ev.type === 'done')     console.log('\n[完成]');
    if (ev.type === 'error')    console.error('[错误]', ev.data);
};
```

### 健康检查

```bash
curl http://localhost:8000/api/v1/health
# {
#   "status": "ok",
#   "databases": {"pg_primary": "up"},
#   "redis": "up",
#   "scenarios": ["rice_inventory", "weather_hotel"],
#   "tools": ["calculator", "http_api", "database_query", "query_rice_inventory", ...]
# }
```

---

## 如何新增业务场景

只需三步，**无需修改任何已有代码**：

### Step 1：创建工具文件

```python
# app/scenarios/flight/tools.py
from app.tools.base import BaseTool

class FlightSearchTool(BaseTool):
    @property
    def name(self): return "search_flights"

    @property
    def description(self): return "搜索指定路线的航班信息"

    def tool_schema(self):
        return {
            "type": "function",
            "function": {
                "name": "search_flights",
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "departure": {"type": "string"},
                        "destination": {"type": "string"},
                        "date": {"type": "string"},
                    },
                    "required": ["departure", "destination", "date"],
                },
            },
        }

    async def execute(self, departure, destination, date, **_):
        # 调用真实 API 或返回 mock
        return {"flights": [{"no": "CA123", "price": 680}]}
```

### Step 2：创建场景文件

```python
# app/scenarios/flight/scenario.py
from app.scenarios.base import BaseScenario
from app.scenarios.flight.tools import FlightSearchTool

class FlightBookingScenario(BaseScenario):
    @property
    def name(self): return "flight_booking"

    @property
    def description(self): return "机票搜索与预订：查找航班、比较价格、完成购票"

    @property
    def intent_labels(self):
        return ["search_flights", "book_flight", "check_flight_status"]

    @property
    def tools(self):
        return [FlightSearchTool()]

    @property
    def system_prompt_extra(self):
        return "【机票场景】必须先搜索航班，再询问用户确认后才能预订。"
```

### Step 3：添加 SQL 模板（如有 DB 操作）

```python
# 在 app/db/query.py 的 _TEMPLATES 中添加：
"get_flight_orders": {
    "op": OperationType.READ,
    "desc": "查询用户的机票订单",
    "sql": "SELECT * FROM flight_orders WHERE user_id = :user_id",
    "params": {"user_id"},
},
```

**重启服务，新场景自动生效。** `loader.py` 会自动扫描发现。

---

## 安全机制

| 机制 | 说明 |
|------|------|
| SQL 注入防护 | LLM 只能选模板名+参数，`text()` 绑定，正则拦截危险关键词 |
| LLM 不能写 SQL | 所有 SQL 固化在 `db/query.py` 模板注册表中 |
| 工具调用上限 | `AGENT_MAX_TOOL_CALLS=5`，超限强制进入回答节点 |
| 最大迭代次数 | `AGENT_MAX_ITERATIONS=10` |
| 全局超时 | `AGENT_TIMEOUT=120s`，`asyncio.wait_for` 守护 |
| HTTP 白名单 | `HTTP_TOOL_ALLOWED_ORIGINS` 限制工具可访问的域名 |

---

## 运行测试

```bash
pytest tests/ -v
```

---

## 多数据库路由

```python
# 按场景路由到不同数据库
await execute_template("daily_sales_summary", params, scene="analytics")
# → pg_secondary（只读副本）

await execute_template("query_rice_inventory", params, scene="default")
# → pg_primary（主库）

# 动态注册新路由
db_manager.register_route("opengauss_biz", "og_primary")
await execute_template("some_template", params, scene="opengauss_biz")
```
