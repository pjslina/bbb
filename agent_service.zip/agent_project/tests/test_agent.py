"""
Tests for the agent service.

Run:
    pytest tests/ -v --asyncio-mode=auto
"""
from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient
from httpx import AsyncClient

from app.core.exceptions import (
    AgentMaxIterationsError,
    ToolCallLimitError,
    ToolExecutionError,
    ToolNotFoundError,
)
from app.tools.base import BaseTool, ToolRegistry


# ====================================================================== #
#  Fixtures                                                               #
# ====================================================================== #

@pytest.fixture
def tool_registry_fresh():
    """Return a fresh ToolRegistry with no tools registered."""
    return ToolRegistry()


class EchoTool(BaseTool):
    @property
    def name(self) -> str:
        return "echo"

    @property
    def description(self) -> str:
        return "Returns the input unchanged."

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": "echo",
                "description": "Echo the input.",
                "parameters": {
                    "type": "object",
                    "properties": {"text": {"type": "string"}},
                    "required": ["text"],
                },
            },
        }

    async def execute(self, text: str, **kwargs: Any) -> str:
        return text


# ====================================================================== #
#  Tool Registry Tests                                                    #
# ====================================================================== #

class TestToolRegistry:
    def test_register_and_retrieve(self, tool_registry_fresh):
        reg = tool_registry_fresh
        reg.register(EchoTool())
        assert "echo" in reg
        tool = reg.get("echo")
        assert tool.name == "echo"

    def test_not_found_raises(self, tool_registry_fresh):
        reg = tool_registry_fresh
        with pytest.raises(ToolNotFoundError):
            reg.get("nonexistent")

    def test_all_schemas(self, tool_registry_fresh):
        reg = tool_registry_fresh
        reg.register(EchoTool())
        schemas = reg.all_schemas()
        assert len(schemas) == 1
        assert schemas[0]["function"]["name"] == "echo"

    def test_unregister(self, tool_registry_fresh):
        reg = tool_registry_fresh
        reg.register(EchoTool())
        reg.unregister("echo")
        assert "echo" not in reg

    @pytest.mark.asyncio
    async def test_execute_success(self, tool_registry_fresh):
        reg = tool_registry_fresh
        reg.register(EchoTool())
        result = await reg.execute("echo", text="hello")
        assert result == "hello"

    @pytest.mark.asyncio
    async def test_execute_not_found(self, tool_registry_fresh):
        reg = tool_registry_fresh
        with pytest.raises(ToolNotFoundError):
            await reg.execute("nonexistent")


# ====================================================================== #
#  Calculator Tool Tests                                                  #
# ====================================================================== #

class TestCalculatorTool:
    @pytest.fixture
    def calc(self):
        from app.tools.builtin_tools import CalculatorTool
        return CalculatorTool()

    @pytest.mark.asyncio
    async def test_basic_arithmetic(self, calc):
        result = await calc.execute(expression="2 + 3")
        assert result["result"] == 5.0

    @pytest.mark.asyncio
    async def test_complex_expression(self, calc):
        result = await calc.execute(expression="(10 + 5) * 2 / 3")
        assert abs(result["result"] - 10.0) < 1e-9

    @pytest.mark.asyncio
    async def test_power(self, calc):
        result = await calc.execute(expression="2 ** 10")
        assert result["result"] == 1024.0

    @pytest.mark.asyncio
    async def test_invalid_expression_raises(self, calc):
        with pytest.raises(ToolExecutionError):
            await calc.execute(expression="import os; os.system('ls')")

    @pytest.mark.asyncio
    async def test_division_by_zero_raises(self, calc):
        with pytest.raises(ToolExecutionError):
            await calc.execute(expression="1 / 0")


# ====================================================================== #
#  SQL Template Tests                                                     #
# ====================================================================== #

class TestSQLTemplates:
    def test_get_template_names(self):
        from app.db.query import get_template_names
        names = get_template_names()
        assert "get_user_by_id" in names
        assert "list_users" in names

    def test_injection_risk_detected(self):
        from app.db.query import _assert_safe
        from app.core.exceptions import SQLInjectionRisk
        with pytest.raises(SQLInjectionRisk):
            _assert_safe("'; DROP TABLE users; --", "test")

    def test_safe_value_passes(self):
        from app.db.query import _assert_safe
        _assert_safe("user123", "test")  # Should not raise

    def test_unknown_template_raises(self):
        from app.db.query import get_template_params
        from app.core.exceptions import DatabaseError
        with pytest.raises(DatabaseError):
            get_template_params("nonexistent_template")


# ====================================================================== #
#  Agent State Tests                                                      #
# ====================================================================== #

class TestAgentState:
    def test_routing_intents_coverage(self):
        from app.agent.state import ROUTING_INTENTS
        assert "query_database" in ROUTING_INTENTS
        assert "general_chat" in ROUTING_INTENTS
        # general_chat should have no tools
        assert ROUTING_INTENTS["general_chat"] == []

    def test_intent_labels_valid(self):
        from app.agent.state import ROUTING_INTENTS
        valid_intents = {"query_database", "call_api", "calculate", "general_chat", "unknown"}
        assert set(ROUTING_INTENTS.keys()) == valid_intents


# ====================================================================== #
#  Config Tests                                                           #
# ====================================================================== #

class TestConfig:
    def test_defaults_loaded(self):
        from app.core.config import AppSettings
        s = AppSettings()
        assert s.agent_max_iterations > 0
        assert s.agent_max_tool_calls > 0
        assert s.agent_timeout > 0

    def test_invalid_log_level_raises(self):
        from pydantic import ValidationError
        from app.core.config import AppSettings
        with pytest.raises(ValidationError):
            AppSettings(log_level="INVALID_LEVEL")


# ====================================================================== #
#  Exception Hierarchy Tests                                              #
# ====================================================================== #

class TestExceptions:
    def test_agent_max_iterations_error(self):
        exc = AgentMaxIterationsError(10)
        assert exc.code == "MAX_ITERATIONS_EXCEEDED"
        assert "10" in exc.message

    def test_tool_call_limit_error(self):
        exc = ToolCallLimitError(5)
        assert exc.code == "TOOL_CALL_LIMIT"
        assert "5" in exc.message

    def test_tool_execution_error(self):
        exc = ToolExecutionError("my_tool", "some failure")
        assert exc.code == "TOOL_EXECUTION_ERROR"
        assert "my_tool" in exc.message


# ====================================================================== #
#  Memory Store Tests (mocked Redis)                                      #
# ====================================================================== #

class TestRedisMemoryStore:
    @pytest.mark.asyncio
    async def test_append_and_load(self):
        from app.memory.redis_store import RedisMemoryStore
        from langchain_core.messages import HumanMessage, AIMessage

        store = RedisMemoryStore()

        # Mock redis
        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(return_value=None)
        mock_redis.pipeline = MagicMock(return_value=AsyncMock())
        mock_redis.pipeline.return_value.__aenter__ = AsyncMock()
        mock_redis.pipeline.return_value.__aexit__ = AsyncMock()
        store._redis = mock_redis

        # Should return empty list when no data
        history = await store.load_history("test-session")
        assert isinstance(history, list)
