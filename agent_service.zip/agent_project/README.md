# Single Agent Service

生产级单 Agent 智能体服务，基于 LangGraph + FastAPI 构建。

## 架构概览

```
┌─────────────────────────────────────────────────────────┐
│                    FastAPI Application                   │
│                                                         │
│  POST /api/v1/chat          — 同步对话                   │
│  POST /api/v1/chat/stream   — SSE 流式输出               │
│  WS   /ws/{session_id}      — WebSocket 双向流式          │
└──────────────────────────┬──────────────────────────────┘
                           │
                ┌──────────▼──────────┐
                │   AgentRunner       │
                │   (graph invoker)   │
                └──────────┬──────────┘
                           │
        ┌──────────────────▼──────────────────────┐
        │         LangGraph StateGraph             │
        │                                          │
        │  START                                   │
        │    └► intent_recognition                 │
        │    └► tool_decision  ──(no)──► llm_answer│
        │    └► tool_router    ──(no)──► llm_answer│
        │    └► tool_executor                      │
        │    └► llm_answer                         │
        │    └► memory_update                      │
        │  END                                     │
        └──────────────────────────────────────────┘
                    │              │
          ┌─────────▼─┐     ┌──────▼──────┐
          │  LLMAdapter│     │ToolRegistry  │
          │ (Qwen/GLM/ │     │ (pluggable) │
          │  OpenAI)   │     └──────┬──────┘
          └────────────┘           │
                            ┌──────▼──────┐
                            │  DB Query   │
                            │  HTTP API   │
                            │  Calculator │
                            └─────────────┘
                    │
          ┌─────────▼──────────┐
          │   RedisMemoryStore  │
          │  (history + summary)│
          └─────────────────────┘
```

## 快速开始

### 1. 安装依赖

```bash
python -m venv .venv
source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. 配置环境

```bash
cp .env.example .env
# 编辑 .env，填入真实的 LLM API Key、数据库连接等
```

### 3. 启动服务（开发模式）

```bash
bash scripts/run_dev.sh
```

### 4. Docker Compose（推荐）

```bash
# 复制并填写 .env
cp .env.example .env

# 启动全栈（Agent + Redis + PostgreSQL）
cd docker
docker compose up --build
```

## API 使用示例

### 同步对话

```bash
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"session_id": "user-123", "message": "查询用户 alice 的信息"}'
```

### SSE 流式对话

```bash
curl -N -X POST http://localhost:8000/api/v1/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"session_id": "user-123", "message": "计算 (100 + 200) * 3"}'
```

### WebSocket 对话

```javascript
const ws = new WebSocket('ws://localhost:8000/ws/user-123');

ws.onopen = () => {
  ws.send(JSON.stringify({
    type: 'chat',
    message: '查询最新的订单列表'
  }));
};

ws.onmessage = (evt) => {
  const event = JSON.parse(evt.data);
  if (event.type === 'token') process.stdout.write(event.data);
  if (event.type === 'done') console.log('\n[完成]', event.metadata);
};
```

## 项目结构

```
agent_project/
├── app/
│   ├── agent/
│   │   ├── graph.py          # LangGraph StateGraph 构建与 AgentRunner
│   │   ├── nodes.py          # 所有图节点实现
│   │   └── state.py          # AgentState TypedDict 定义
│   ├── api/
│   │   ├── models.py         # Pydantic 请求/响应模型
│   │   ├── routes.py         # REST 端点
│   │   ├── sse.py            # SSE 流式端点
│   │   └── websocket.py      # WebSocket 端点
│   ├── core/
│   │   ├── config.py         # 集中配置（pydantic-settings）
│   │   ├── exceptions.py     # 领域异常层次
│   │   └── logging.py        # 结构化日志（structlog）
│   ├── db/
│   │   ├── pool.py           # 多数据库连接池管理（PG + OpenGauss）
│   │   └── query.py          # SQL 模板引擎（防注入）
│   ├── llm/
│   │   └── adapter.py        # 统一 LLM 适配器（Qwen/GLM/OpenAI）
│   ├── memory/
│   │   └── redis_store.py    # Redis 会话记忆 + 摘要压缩
│   ├── tools/
│   │   ├── base.py           # BaseTool + ToolRegistry
│   │   └── builtin_tools.py  # 内置工具：DB查询/HTTP/计算器
│   └── main.py               # FastAPI 应用工厂
├── tests/
│   └── test_agent.py
├── scripts/
│   ├── init_db.sql
│   ├── run_dev.sh
│   └── run_prod.sh
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml
├── .env.example
├── pytest.ini
└── requirements.txt
```

## 核心设计说明

### SQL 安全

**LLM 禁止拼写 SQL**。所有数据库查询通过命名模板执行：

```python
# LLM 只能选择模板名称 + 提供参数
result = await execute_template(
    "get_user_by_id",
    {"user_id": 42},
    scene="default"
)
```

### Agent 防失控

| 限制 | 配置项 | 默认值 |
|------|--------|--------|
| 最大迭代次数 | `AGENT_MAX_ITERATIONS` | 10 |
| 整体超时 | `AGENT_TIMEOUT` | 120s |
| Tool 调用次数 | `AGENT_MAX_TOOL_CALLS` | 5 |

### 会话压缩

当消息数超过 `SUMMARY_THRESHOLD`（默认20条）时，自动：
1. 将旧消息提交 LLM 生成摘要
2. 摘要存入 Redis
3. 保留最近 N/2 条消息
4. 下次加载时摘要作为 SystemMessage 注入

### 多数据库路由

```python
# 按场景动态路由
await execute_template("daily_sales_summary", params, scene="analytics")
# → 路由到 pg_secondary（只读副本）

await execute_template("get_user_by_id", params, scene="default")
# → 路由到 pg_primary
```

### 添加自定义工具

```python
from app.tools.base import BaseTool, tool_registry

class MyTool(BaseTool):
    @property
    def name(self): return "my_tool"

    @property
    def description(self): return "Does something useful."

    def tool_schema(self):
        return { "type": "function", "function": { ... } }

    async def execute(self, **kwargs):
        return {"result": "..."}

# 注册（在 builtin_tools.py 的 register_builtin_tools 中调用）
tool_registry.register(MyTool())
```

## 测试

```bash
pytest tests/ -v
```

## 健康检查

```bash
curl http://localhost:8000/api/v1/health
# {"status":"ok","service":"single-agent","env":"development","databases":{"pg_primary":"up"},"redis":"up"}
```
