#!/usr/bin/env bash
# Development server with auto-reload
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

# Load .env if present
if [ -f ".env" ]; then
    echo "Loading .env"
    set -a
    source .env
    set +a
fi

echo "Starting agent service (development mode)..."
exec uvicorn app.main:app \
    --host "${APP_HOST:-0.0.0.0}" \
    --port "${APP_PORT:-8000}" \
    --reload \
    --reload-dir app \
    --log-level "${LOG_LEVEL:-info}" \
    --workers 1
