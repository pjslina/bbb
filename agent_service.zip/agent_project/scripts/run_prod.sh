#!/usr/bin/env bash
# Production server (Gunicorn + Uvicorn workers)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

WORKERS="${WORKERS:-4}"
PORT="${APP_PORT:-8000}"
HOST="${APP_HOST:-0.0.0.0}"

echo "Starting agent service (production, workers=$WORKERS)..."
exec gunicorn app.main:app \
    --worker-class uvicorn.workers.UvicornWorker \
    --workers "$WORKERS" \
    --bind "${HOST}:${PORT}" \
    --timeout 180 \
    --graceful-timeout 30 \
    --keep-alive 5 \
    --access-logfile - \
    --error-logfile -
