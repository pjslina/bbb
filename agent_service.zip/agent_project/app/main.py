"""
FastAPI application factory.

Startup sequence:
  1. Setup structured logging
  2. Register built-in tools
  3. Init database pools
  4. Init Redis memory store
  5. Pre-warm LLM adapter
  6. Mount routers

Shutdown sequence:
  1. Close DB pools
  2. Close Redis
"""
from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import AsyncIterator

import structlog
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.routes import router as rest_router
from app.api.sse import router as sse_router
from app.api.websocket import router as ws_router
from app.core.config import settings
from app.core.exceptions import AgentBaseError
from app.core.logging import get_logger, setup_logging
from app.db.pool import db_manager
from app.llm.adapter import LLMAdapter
from app.memory.redis_store import memory_store
from app.tools.builtin_tools import register_builtin_tools

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Application lifespan: startup → yield → shutdown."""
    setup_logging()
    logger.info("Starting agent service", env=settings.app_env)

    # 1. Register tools
    register_builtin_tools()

    # 2. Init databases
    await db_manager.init()

    # 3. Init Redis
    await memory_store.init()

    # 4. Pre-warm LLM singleton
    LLMAdapter.get_instance()

    logger.info("Agent service ready", port=settings.app_port)

    yield  # Application runs here

    # ---- Shutdown ----
    logger.info("Shutting down agent service")
    await db_manager.close()
    await memory_store.close()
    logger.info("Shutdown complete")


def create_app() -> FastAPI:
    app = FastAPI(
        title="Single Agent Service",
        version="1.0.0",
        description=(
            "Production-grade single-agent service with "
            "dual-channel streaming (SSE + WebSocket), "
            "LangGraph state machine, and multi-database support."
        ),
        docs_url="/docs" if not settings.is_production else None,
        redoc_url="/redoc" if not settings.is_production else None,
        lifespan=lifespan,
    )

    # ---- CORS ----
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if not settings.is_production else [],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ---- Request timing middleware ----
    @app.middleware("http")
    async def add_process_time(request: Request, call_next) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = time.perf_counter() - start
        response.headers["X-Process-Time"] = f"{elapsed:.4f}"
        return response

    # ---- Global exception handler ----
    @app.exception_handler(AgentBaseError)
    async def agent_error_handler(request: Request, exc: AgentBaseError) -> JSONResponse:
        logger.error("Unhandled agent error", code=exc.code, message=exc.message)
        return JSONResponse(
            status_code=500,
            content={"code": exc.code, "message": exc.message},
        )

    @app.exception_handler(Exception)
    async def generic_error_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.error("Unhandled exception", error=str(exc), exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"code": "INTERNAL_ERROR", "message": "Internal server error"},
        )

    # ---- Mount routers ----
    API_PREFIX = "/api/v1"
    app.include_router(rest_router, prefix=API_PREFIX, tags=["Chat & Session"])
    app.include_router(sse_router, prefix=API_PREFIX, tags=["SSE Streaming"])
    app.include_router(ws_router, tags=["WebSocket"])

    @app.get("/", include_in_schema=False)
    async def root() -> dict:
        return {"service": settings.app_name, "env": settings.app_env, "status": "ok"}

    return app


app = create_app()
