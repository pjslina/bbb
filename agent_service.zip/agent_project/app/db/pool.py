"""
Multi-database connection pool manager.

Supports:
- Multiple PostgreSQL instances
- Multiple OpenGauss instances (asyncpg-compatible)
- Dynamic routing by scene/intent
- Connection pool lifecycle management
"""
from __future__ import annotations

import contextlib
from typing import Any, AsyncIterator

from sqlalchemy.ext.asyncio import (
    AsyncConnection,
    AsyncEngine,
    create_async_engine,
)

from app.core.config import settings
from app.core.exceptions import DatabaseError, DatabaseRouteError
from app.core.logging import get_logger

logger = get_logger(__name__)

# --------------------------------------------------------------------------- #
#  Scene → DB route table                                                      #
#  Maps logical scene names to engine keys configured in all_db_dsns.          #
# --------------------------------------------------------------------------- #
DEFAULT_SCENE_ROUTES: dict[str, str] = {
    "default": "pg_primary",
    "analytics": "pg_secondary",     # read replicas for heavy reads
    "opengauss": "og_primary",
    "opengauss_replica": "og_secondary",
}


class DatabasePoolManager:
    """
    Manages a pool of AsyncEngine instances keyed by logical DB name.
    Provides scene-based routing so callers never hardcode a DB name.
    """

    def __init__(self) -> None:
        self._engines: dict[str, AsyncEngine] = {}
        self._scene_routes: dict[str, str] = dict(DEFAULT_SCENE_ROUTES)
        self._initialized = False

    # ------------------------------------------------------------------ #
    #  Lifecycle                                                           #
    # ------------------------------------------------------------------ #

    async def init(self) -> None:
        if self._initialized:
            return

        pool_sizes: dict[str, int] = {
            "pg_primary": settings.pg_primary_pool_size,
            "pg_secondary": settings.pg_secondary_pool_size,
            "og_primary": settings.og_primary_pool_size,
        }

        for name, dsn in settings.all_db_dsns.items():
            pool_size = pool_sizes.get(name, 5)
            try:
                engine = create_async_engine(
                    dsn,
                    pool_size=pool_size,
                    max_overflow=settings.pg_primary_max_overflow,
                    pool_pre_ping=True,
                    pool_recycle=1800,         # recycle connections every 30 min
                    echo=not settings.is_production,
                    connect_args=self._connect_args(name),
                )
                self._engines[name] = engine
                logger.info("Database pool created", db=name, pool_size=pool_size)
            except Exception as exc:
                logger.error("Failed to create DB engine", db=name, error=str(exc))
                raise DatabaseError(f"Cannot create engine for {name!r}: {exc}") from exc

        self._initialized = True

    async def close(self) -> None:
        for name, engine in self._engines.items():
            await engine.dispose()
            logger.info("Database pool closed", db=name)
        self._engines.clear()
        self._initialized = False

    # ------------------------------------------------------------------ #
    #  Routing                                                             #
    # ------------------------------------------------------------------ #

    def register_route(self, scene: str, db_name: str) -> None:
        """Dynamically add or override a scene → db_name route."""
        if db_name not in self._engines:
            raise DatabaseError(
                f"Cannot route scene {scene!r} to unknown db {db_name!r}"
            )
        self._scene_routes[scene] = db_name
        logger.debug("DB route registered", scene=scene, db=db_name)

    def resolve_engine(self, scene: str = "default") -> AsyncEngine:
        db_name = self._scene_routes.get(scene)
        if db_name is None:
            raise DatabaseRouteError(scene)
        engine = self._engines.get(db_name)
        if engine is None:
            # Fallback to primary if the target isn't configured
            fallback = self._engines.get("pg_primary")
            if fallback is None:
                raise DatabaseError("No database engines available")
            logger.warning(
                "DB engine not found for route, using pg_primary fallback",
                scene=scene,
                db_name=db_name,
            )
            return fallback
        return engine

    # ------------------------------------------------------------------ #
    #  Context manager for connections                                     #
    # ------------------------------------------------------------------ #

    @contextlib.asynccontextmanager
    async def connect(self, scene: str = "default") -> AsyncIterator[AsyncConnection]:
        engine = self.resolve_engine(scene)
        async with engine.begin() as conn:
            yield conn

    # ------------------------------------------------------------------ #
    #  Helpers                                                             #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _connect_args(db_name: str) -> dict[str, Any]:
        """
        Extra asyncpg connect_args.
        OpenGauss may need ssl or server_settings tweaks.
        """
        if "og" in db_name:
            # OpenGauss-specific: compatible with asyncpg but needs
            # statement_timeout and application_name
            return {
                "server_settings": {
                    "application_name": settings.app_name,
                    "statement_timeout": "30000",  # 30s
                }
            }
        return {
            "server_settings": {
                "application_name": settings.app_name,
            }
        }

    def health(self) -> dict[str, str]:
        return {
            name: "up" if engine.pool is not None else "unknown"
            for name, engine in self._engines.items()
        }


# Singleton instance
db_manager = DatabasePoolManager()
