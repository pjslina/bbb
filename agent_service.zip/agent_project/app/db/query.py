"""
SQL template engine.

CRITICAL SECURITY RULES:
  1. LLM is NEVER allowed to construct raw SQL.
  2. All queries come from a pre-approved template registry.
  3. Parameters are bound via SQLAlchemy text() — never f-strings or format().
  4. Template names are validated before execution.

This prevents:
  - SQL injection
  - Hallucinated SQL from the LLM
  - Schema leakage
"""
from __future__ import annotations

import re
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection

from app.core.exceptions import DatabaseError, SQLInjectionRisk
from app.core.logging import get_logger
from app.db.pool import db_manager

logger = get_logger(__name__)

# --------------------------------------------------------------------------- #
#  Template Registry                                                           #
#  All allowed SQL lives here. LLM picks a template name + params only.       #
# --------------------------------------------------------------------------- #
_SQL_TEMPLATES: dict[str, str] = {
    # --- User queries ---
    "get_user_by_id": """
        SELECT id, username, email, created_at
        FROM users
        WHERE id = :user_id
        LIMIT 1
    """,
    "list_users": """
        SELECT id, username, email, created_at
        FROM users
        ORDER BY created_at DESC
        LIMIT :limit OFFSET :offset
    """,
    "search_users_by_name": """
        SELECT id, username, email
        FROM users
        WHERE username ILIKE :pattern
        LIMIT :limit
    """,

    # --- Order queries ---
    "get_orders_by_user": """
        SELECT o.id, o.status, o.total_amount, o.created_at
        FROM orders o
        WHERE o.user_id = :user_id
          AND o.status = ANY(:statuses)
        ORDER BY o.created_at DESC
        LIMIT :limit
    """,
    "get_order_detail": """
        SELECT o.id, o.status, o.total_amount,
               oi.product_id, oi.quantity, oi.unit_price
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        WHERE o.id = :order_id
    """,

    # --- Product queries ---
    "search_products": """
        SELECT id, name, price, stock_quantity, category
        FROM products
        WHERE (:category IS NULL OR category = :category)
          AND (:keyword IS NULL OR name ILIKE :keyword)
        ORDER BY name
        LIMIT :limit
    """,

    # --- Analytics (routed to secondary) ---
    "daily_sales_summary": """
        SELECT DATE_TRUNC('day', created_at) AS day,
               COUNT(*) AS order_count,
               SUM(total_amount) AS revenue
        FROM orders
        WHERE created_at >= :start_date
          AND created_at < :end_date
        GROUP BY 1
        ORDER BY 1
    """,
}

# LLM-facing parameter schema for each template (used to validate inputs)
_TEMPLATE_PARAM_SCHEMA: dict[str, set[str]] = {
    "get_user_by_id": {"user_id"},
    "list_users": {"limit", "offset"},
    "search_users_by_name": {"pattern", "limit"},
    "get_orders_by_user": {"user_id", "statuses", "limit"},
    "get_order_detail": {"order_id"},
    "search_products": {"category", "keyword", "limit"},
    "daily_sales_summary": {"start_date", "end_date"},
}


# Patterns that should NEVER appear in template names or param values
_DANGEROUS_PATTERNS = re.compile(
    r"(--|;|/\*|\*/|xp_|exec|execute|drop|truncate|alter|create|insert|update|delete)",
    re.IGNORECASE,
)


def _assert_safe(value: str, context: str) -> None:
    if _DANGEROUS_PATTERNS.search(value):
        logger.error("SQL injection risk detected", context=context, value=value)
        raise SQLInjectionRisk()


def get_template_names() -> list[str]:
    """Return all allowed template names. Exposed to LLM tool schema."""
    return list(_SQL_TEMPLATES.keys())


def get_template_params(template_name: str) -> set[str]:
    """Return expected parameter names for a template."""
    if template_name not in _TEMPLATE_PARAM_SCHEMA:
        raise DatabaseError(f"Unknown SQL template: {template_name!r}")
    return _TEMPLATE_PARAM_SCHEMA[template_name]


async def execute_template(
    template_name: str,
    params: dict[str, Any],
    *,
    scene: str = "default",
) -> list[dict[str, Any]]:
    """
    Execute a named SQL template with bound parameters.

    Args:
        template_name: Key into _SQL_TEMPLATES.
        params:        Bind parameters — never concatenated into SQL.
        scene:         DB routing scene (e.g. "analytics").

    Returns:
        List of row dicts.

    Raises:
        DatabaseError:    Unknown template or execution failure.
        SQLInjectionRisk: Detected dangerous pattern in input.
    """
    _assert_safe(template_name, "template_name")
    for k, v in params.items():
        if isinstance(v, str):
            _assert_safe(v, f"param:{k}")

    if template_name not in _SQL_TEMPLATES:
        raise DatabaseError(f"SQL template not found: {template_name!r}")

    # Validate provided keys match expected schema
    expected = _TEMPLATE_PARAM_SCHEMA.get(template_name, set())
    provided = set(params.keys())
    missing = expected - provided - _get_nullable_params(template_name)
    if missing:
        raise DatabaseError(
            f"Missing required params for {template_name!r}: {missing}"
        )

    sql = text(_SQL_TEMPLATES[template_name])
    logger.debug(
        "Executing SQL template",
        template=template_name,
        scene=scene,
        param_keys=list(params.keys()),
    )

    try:
        async with db_manager.connect(scene=scene) as conn:
            result = await conn.execute(sql, params)
            rows = result.mappings().all()
            return [dict(row) for row in rows]
    except Exception as exc:
        logger.error(
            "SQL template execution failed",
            template=template_name,
            error=str(exc),
        )
        raise DatabaseError(f"Query failed [{template_name}]: {exc}") from exc


def _get_nullable_params(template_name: str) -> set[str]:
    """
    Some templates have nullable/optional params (:keyword IS NULL OR ...).
    These don't need to be supplied by the caller.
    """
    nullable_map: dict[str, set[str]] = {
        "search_products": {"category", "keyword"},
    }
    return nullable_map.get(template_name, set())
