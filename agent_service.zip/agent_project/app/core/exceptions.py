"""
Domain exception hierarchy for the agent service.
All custom exceptions derive from AgentBaseError.
"""
from __future__ import annotations


class AgentBaseError(Exception):
    """Base class for all agent service errors."""

    def __init__(self, message: str, code: str = "AGENT_ERROR") -> None:
        super().__init__(message)
        self.message = message
        self.code = code

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code={self.code!r}, message={self.message!r})"


# ----- LLM -----
class LLMError(AgentBaseError):
    def __init__(self, message: str) -> None:
        super().__init__(message, code="LLM_ERROR")


class LLMTimeoutError(LLMError):
    def __init__(self) -> None:
        super().__init__("LLM call timed out")
        self.code = "LLM_TIMEOUT"


# ----- Agent Safety -----
class AgentMaxIterationsError(AgentBaseError):
    def __init__(self, max_iter: int) -> None:
        super().__init__(
            f"Agent exceeded max iterations ({max_iter})",
            code="MAX_ITERATIONS_EXCEEDED",
        )


class AgentTimeoutError(AgentBaseError):
    def __init__(self, timeout: int) -> None:
        super().__init__(
            f"Agent execution timed out after {timeout}s",
            code="AGENT_TIMEOUT",
        )


class ToolCallLimitError(AgentBaseError):
    def __init__(self, limit: int) -> None:
        super().__init__(
            f"Tool call limit reached ({limit})",
            code="TOOL_CALL_LIMIT",
        )


# ----- Tools -----
class ToolNotFoundError(AgentBaseError):
    def __init__(self, tool_name: str) -> None:
        super().__init__(f"Tool not found: {tool_name!r}", code="TOOL_NOT_FOUND")


class ToolExecutionError(AgentBaseError):
    def __init__(self, tool_name: str, detail: str) -> None:
        super().__init__(
            f"Tool {tool_name!r} failed: {detail}",
            code="TOOL_EXECUTION_ERROR",
        )


# ----- Database -----
class DatabaseError(AgentBaseError):
    def __init__(self, message: str) -> None:
        super().__init__(message, code="DB_ERROR")


class DatabaseRouteError(DatabaseError):
    def __init__(self, scene: str) -> None:
        super().__init__(f"No database route configured for scene: {scene!r}")
        self.code = "DB_ROUTE_ERROR"


class SQLInjectionRisk(DatabaseError):
    def __init__(self) -> None:
        super().__init__("SQL injection risk detected — use parameterized templates")
        self.code = "SQL_INJECTION_RISK"


# ----- Memory -----
class MemoryError(AgentBaseError):
    def __init__(self, message: str) -> None:
        super().__init__(message, code="MEMORY_ERROR")


# ----- Session -----
class SessionNotFoundError(AgentBaseError):
    def __init__(self, session_id: str) -> None:
        super().__init__(f"Session not found: {session_id!r}", code="SESSION_NOT_FOUND")
