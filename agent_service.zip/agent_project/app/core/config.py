"""
Centralized configuration using pydantic-settings.
All settings are loaded from environment variables or .env file.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Literal, Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ----- App -----
    app_name: str = Field(default="single-agent")
    app_env: Literal["development", "production"] = Field(default="development")
    app_host: str = Field(default="0.0.0.0")
    app_port: int = Field(default=8000)
    log_level: str = Field(default="INFO")

    # ----- LLM -----
    llm_provider: Literal["qwen", "glm", "openai"] = Field(default="qwen")
    llm_base_url: str = Field(default="https://dashscope.aliyuncs.com/compatible-mode/v1")
    llm_api_key: str = Field(default="sk-xxx")
    llm_model: str = Field(default="qwen-plus")
    llm_max_tokens: int = Field(default=4096)
    llm_temperature: float = Field(default=0.7)
    llm_timeout: int = Field(default=60)

    # ----- Redis -----
    redis_url: str = Field(default="redis://localhost:6379/0")
    redis_password: Optional[str] = Field(default=None)
    redis_max_connections: int = Field(default=20)
    session_ttl: int = Field(default=86400)
    summary_threshold: int = Field(default=20)

    # ----- PostgreSQL Primary -----
    pg_primary_dsn: str = Field(
        default="postgresql+asyncpg://user:password@localhost:5432/agentdb"
    )
    pg_primary_pool_size: int = Field(default=10)
    pg_primary_max_overflow: int = Field(default=20)

    # ----- PostgreSQL Secondary -----
    pg_secondary_dsn: Optional[str] = Field(default=None)
    pg_secondary_pool_size: int = Field(default=5)

    # ----- OpenGauss -----
    og_primary_dsn: Optional[str] = Field(default=None)
    og_primary_pool_size: int = Field(default=10)
    og_secondary_dsn: Optional[str] = Field(default=None)

    # ----- Agent Safety -----
    agent_max_iterations: int = Field(default=10)
    agent_timeout: int = Field(default=120)
    agent_max_tool_calls: int = Field(default=5)

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = v.upper()
        if upper not in allowed:
            raise ValueError(f"log_level must be one of {allowed}")
        return upper

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def all_db_dsns(self) -> dict[str, str]:
        """Return all configured database DSNs keyed by logical name."""
        dsns: dict[str, str] = {"pg_primary": self.pg_primary_dsn}
        if self.pg_secondary_dsn:
            dsns["pg_secondary"] = self.pg_secondary_dsn
        if self.og_primary_dsn:
            dsns["og_primary"] = self.og_primary_dsn
        if self.og_secondary_dsn:
            dsns["og_secondary"] = self.og_secondary_dsn
        return dsns


@lru_cache(maxsize=1)
def get_settings() -> AppSettings:
    return AppSettings()


settings: AppSettings = get_settings()
