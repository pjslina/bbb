"""
LangGraph StateGraph definition.

Graph topology:
  START
    └─► intent_recognition
    └─► tool_decision
    └─► [tool_router | llm_answer]  ← conditional
    └─► [tool_executor | llm_answer] ← conditional
    └─► llm_answer
    └─► memory_update
  END

Safety:
  - max_iterations enforced in intent_recognition node
  - tool_call_count enforced in tool_executor node
  - overall timeout enforced by the runner (graph.py invoker)
"""
from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator

from langgraph.graph import END, START, StateGraph

from app.agent.nodes import (
    node_intent_recognition,
    node_llm_answer,
    node_memory_update,
    node_tool_decision,
    node_tool_executor,
    node_tool_router,
    route_after_tool_decision,
    route_after_tool_router,
)
from app.agent.state import AgentState
from app.core.config import settings
from app.core.exceptions import AgentTimeoutError
from app.core.logging import get_logger
from app.llm.adapter import LLMAdapter
from app.memory.redis_store import memory_store

logger = get_logger(__name__)


def build_graph() -> Any:
    """Construct and compile the agent StateGraph."""
    builder = StateGraph(AgentState)

    # ---- Register nodes ----
    builder.add_node("intent_recognition", node_intent_recognition)
    builder.add_node("tool_decision", node_tool_decision)
    builder.add_node("tool_router", node_tool_router)
    builder.add_node("tool_executor", node_tool_executor)
    builder.add_node("llm_answer", node_llm_answer)
    builder.add_node("memory_update", node_memory_update)

    # ---- Edges ----
    builder.add_edge(START, "intent_recognition")
    builder.add_edge("intent_recognition", "tool_decision")

    builder.add_conditional_edges(
        "tool_decision",
        route_after_tool_decision,
        {
            "tool_router": "tool_router",
            "llm_answer": "llm_answer",
        },
    )

    builder.add_conditional_edges(
        "tool_router",
        route_after_tool_router,
        {
            "tool_executor": "tool_executor",
            "llm_answer": "llm_answer",
        },
    )

    builder.add_edge("tool_executor", "llm_answer")
    builder.add_edge("llm_answer", "memory_update")
    builder.add_edge("memory_update", END)

    compiled = builder.compile()
    logger.info("Agent graph compiled successfully")
    return compiled


# Singleton compiled graph
_compiled_graph: Any = None


def get_graph() -> Any:
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_graph()
    return _compiled_graph


# ====================================================================== #
#  AgentRunner — high-level interface used by API routes                  #
# ====================================================================== #

class AgentRunner:
    """
    Runs the compiled graph for a session turn.

    Handles:
    - Loading history from Redis
    - Initialising state
    - Executing the graph with timeout
    - Extracting final answer
    """

    def __init__(self) -> None:
        self._graph = get_graph()

    async def run(
        self,
        session_id: str,
        user_input: str,
        user_id: str = "",
        extra: dict[str, Any] | None = None,
    ) -> str:
        """
        Execute one turn, return the final answer string.
        Raises AgentTimeoutError if overall execution exceeds timeout.
        """
        initial_state = await self._build_initial_state(
            session_id, user_input, user_id, extra
        )

        try:
            result = await asyncio.wait_for(
                self._graph.ainvoke(initial_state),
                timeout=settings.agent_timeout,
            )
        except asyncio.TimeoutError as exc:
            raise AgentTimeoutError(settings.agent_timeout) from exc

        return result.get("final_answer", "")

    async def astream(
        self,
        session_id: str,
        user_input: str,
        user_id: str = "",
        extra: dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        """
        Stream the final answer token by token.

        Strategy:
        1. Run the graph (non-streaming) to get tool results etc.
        2. Stream the final LLM generation token by token.

        This keeps tool execution atomic while answer generation is streamed.
        """
        # Phase 1: Run graph up to llm_answer, collect tool results
        initial_state = await self._build_initial_state(
            session_id, user_input, user_id, extra
        )

        try:
            # We use astream_events which yields node outputs as they complete
            async for event in asyncio.timeout(
                settings.agent_timeout,
            )(self._run_streaming_graph(initial_state, session_id, user_input)):
                yield event
        except TimeoutError as exc:
            raise AgentTimeoutError(settings.agent_timeout) from exc

    async def _run_streaming_graph(
        self,
        initial_state: AgentState,
        session_id: str,
        user_input: str,
    ) -> AsyncIterator[str]:
        """
        Internal: run graph, then stream final LLM tokens.
        """
        from langchain_core.messages import HumanMessage, SystemMessage

        # Run graph until llm_answer node (collect tool results)
        result_state = await self._graph.ainvoke(
            {**initial_state, "_skip_llm_answer": True},
        )

        # Now stream the final answer
        tool_results = result_state.get("tool_results", [])
        tool_context = ""
        if tool_results:
            lines = [f"[Tool: {tr['tool']}] {tr['result']}" for tr in tool_results]
            tool_context = "\nTool Results:\n" + "\n".join(lines)

        from app.agent.nodes import LLM_ANSWER_SYSTEM_PROMPT
        system_content = LLM_ANSWER_SYSTEM_PROMPT + tool_context
        history = result_state.get("messages", [])

        messages = [
            SystemMessage(content=system_content),
            *history[-8:],
            HumanMessage(content=user_input),
        ]

        llm = LLMAdapter.get_instance()
        full_answer = []
        async for token in llm.astream_tokens(messages):
            full_answer.append(token)
            yield token

        # Save turn to memory after streaming completes
        from langchain_core.messages import AIMessage
        await memory_store.append_turn(
            session_id,
            HumanMessage(content=user_input),
            AIMessage(content="".join(full_answer)),
        )

        from app.memory.redis_store import maybe_compress_session
        await maybe_compress_session(session_id, memory_store, llm)

    async def _build_initial_state(
        self,
        session_id: str,
        user_input: str,
        user_id: str,
        extra: dict[str, Any] | None,
    ) -> AgentState:
        """Load history and build initial state dict."""
        history = await memory_store.load_history(session_id)
        return AgentState(
            session_id=session_id,
            user_id=user_id,
            user_input=user_input,
            messages=history,
            intent="",
            intent_confidence=0.0,
            intent_slots={},
            selected_tools=[],
            tool_calls=[],
            tool_results=[],
            tool_call_count=0,
            final_answer="",
            stream_tokens=[],
            iteration_count=0,
            should_use_tool=False,
            error=None,
            extra=extra or {},
        )


# Singleton runner
_runner: AgentRunner | None = None


def get_runner() -> AgentRunner:
    global _runner
    if _runner is None:
        _runner = AgentRunner()
    return _runner
