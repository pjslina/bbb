"""
Agent state schema for LangGraph StateGraph.

The AgentState TypedDict is the single shared state passed between
all graph nodes. Each node reads from and writes to this state.
"""
from __future__ import annotations

from typing import Annotated, Any, Literal

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict


class AgentState(TypedDict, total=False):
    # ---- Session context ----
    session_id: str                        # Unique session identifier
    user_id: str                           # Optional user identifier

    # ---- Conversation history ----
    # add_messages reducer: new messages are appended, not replaced
    messages: Annotated[list[BaseMessage], add_messages]

    # ---- Current turn ----
    user_input: str                        # Raw user message for this turn
    intent: str                            # Detected intent label
    intent_confidence: float               # 0-1 confidence score
    intent_slots: dict[str, Any]           # Extracted slots from the input

    # ---- Tool execution ----
    selected_tools: list[str]              # Tool names chosen by tool_router
    tool_calls: list[dict[str, Any]]       # Pending tool calls from LLM
    tool_results: list[dict[str, Any]]     # Results from executed tools
    tool_call_count: int                   # Running total (safety limiter)

    # ---- Response ----
    final_answer: str                      # The answer to stream back to user
    stream_tokens: list[str]               # Accumulated stream tokens

    # ---- Safety / Control ----
    iteration_count: int                   # How many graph loops so far
    should_use_tool: bool                  # tool_decision gate
    error: str | None                      # Last error message if any

    # ---- Metadata ----
    extra: dict[str, Any]                  # Arbitrary pass-through metadata


# Convenience type aliases used in node signatures
IntentLabel = Literal[
    "query_database",
    "call_api",
    "calculate",
    "general_chat",
    "unknown",
]

ROUTING_INTENTS: dict[str, list[str]] = {
    "query_database": ["database_query"],
    "call_api": ["http_api"],
    "calculate": ["calculator"],
    "general_chat": [],      # No tools — pure LLM
    "unknown": [],
}
