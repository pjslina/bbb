"""
LangGraph node implementations.

Node pipeline:
  start
    └─► intent_recognition   (classify user intent + extract slots)
    └─► tool_decision         (decide whether tools are needed)
    └─► tool_router           (select specific tools based on intent)
    └─► tool_executor         (run selected tools, respect limits)
    └─► llm_answer            (generate final response from LLM)
    └─► memory_update         (persist turn to Redis)
  end

Safety guards fire at every node:
  - max_iterations check
  - tool_call_count check
"""
from __future__ import annotations

import json
from typing import Any

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from app.agent.state import AgentState, IntentLabel, ROUTING_INTENTS
from app.core.config import settings
from app.core.exceptions import (
    AgentMaxIterationsError,
    LLMError,
    ToolCallLimitError,
)
from app.core.logging import get_logger
from app.llm.adapter import LLMAdapter
from app.memory.redis_store import memory_store, maybe_compress_session
from app.tools.base import tool_registry

logger = get_logger(__name__)

# ---- System prompts --------------------------------------------------------

INTENT_SYSTEM_PROMPT = """You are an intent classification engine.

Classify the user's message into ONE of these intents:
- query_database : user wants to query data from a database
- call_api       : user wants to call an external API or service
- calculate      : user wants arithmetic or formula calculation
- general_chat   : general conversation, advice, explanation
- unknown        : cannot determine intent

Also extract relevant slots (structured data) from the message.

Respond ONLY with valid JSON, no markdown, no preamble:
{
  "intent": "<intent_label>",
  "confidence": <0.0-1.0>,
  "slots": { "<key>": "<value>", ... }
}"""

TOOL_SELECTION_PROMPT = """You are a tool selection agent.

Based on the user intent and available tools, select the most appropriate tool(s).
You MUST call one or more tools to fulfill the request.

User intent: {intent}
Extracted slots: {slots}
"""

LLM_ANSWER_SYSTEM_PROMPT = """You are a helpful AI assistant.

You have access to conversation history and optionally tool results.
Provide a clear, concise, accurate answer to the user's question.

If tool results are available, use them to ground your answer.
Do NOT make up data or hallucinate database results.
"""


# ====================================================================== #
#  Node implementations                                                   #
# ====================================================================== #

async def node_intent_recognition(state: AgentState) -> dict[str, Any]:
    """
    Classify user intent and extract structured slots.
    Returns: intent, intent_confidence, intent_slots
    """
    _check_max_iterations(state)

    llm = LLMAdapter.get_instance()
    user_input = state.get("user_input", "")
    history = state.get("messages", [])

    messages = [
        SystemMessage(content=INTENT_SYSTEM_PROMPT),
        *history[-4:],   # last 4 messages for context
        HumanMessage(content=user_input),
    ]

    try:
        response = await llm.ainvoke(messages)
        raw = response.content.strip()
        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        data = json.loads(raw)
    except (json.JSONDecodeError, LLMError) as exc:
        logger.warning("Intent parsing failed, defaulting to general_chat", error=str(exc))
        data = {"intent": "general_chat", "confidence": 0.5, "slots": {}}

    intent = data.get("intent", "unknown")
    if intent not in ROUTING_INTENTS:
        intent = "unknown"

    logger.info(
        "Intent recognised",
        session_id=state.get("session_id"),
        intent=intent,
        confidence=data.get("confidence"),
    )

    return {
        "intent": intent,
        "intent_confidence": float(data.get("confidence", 0.5)),
        "intent_slots": data.get("slots", {}),
        "iteration_count": state.get("iteration_count", 0) + 1,
    }


async def node_tool_decision(state: AgentState) -> dict[str, Any]:
    """
    Decide whether tools should be used for this turn.
    Pure intents (general_chat, unknown) skip tools.
    """
    intent = state.get("intent", "unknown")
    tool_call_count = state.get("tool_call_count", 0)

    # Safety: already hit tool limit
    if tool_call_count >= settings.agent_max_tool_calls:
        logger.warning(
            "Tool call limit reached in tool_decision, skipping tools",
            session_id=state.get("session_id"),
            tool_call_count=tool_call_count,
        )
        return {"should_use_tool": False}

    should_use = bool(ROUTING_INTENTS.get(intent))
    logger.debug("Tool decision", intent=intent, should_use_tool=should_use)
    return {"should_use_tool": should_use}


async def node_tool_router(state: AgentState) -> dict[str, Any]:
    """
    Select which tools to activate based on intent.
    Returns: selected_tools, tool_calls (from LLM function-calling)
    """
    intent = state.get("intent", "unknown")
    slots = state.get("intent_slots", {})
    user_input = state.get("user_input", "")

    # Map intent → candidate tool names
    candidate_tools = ROUTING_INTENTS.get(intent, [])
    available = [t for t in candidate_tools if t in tool_registry]

    if not available:
        logger.warning("No tools available for intent", intent=intent)
        return {"selected_tools": [], "tool_calls": []}

    # Ask LLM to generate tool calls for the available tools
    llm = LLMAdapter.get_instance()
    schemas = [tool_registry.get(t).tool_schema() for t in available]

    messages = [
        SystemMessage(
            content=TOOL_SELECTION_PROMPT.format(
                intent=intent, slots=json.dumps(slots, ensure_ascii=False)
            )
        ),
        HumanMessage(content=user_input),
    ]

    try:
        response = await llm.ainvoke(messages, tools=schemas)
    except LLMError as exc:
        logger.error("Tool router LLM call failed", error=str(exc))
        return {"selected_tools": available, "tool_calls": []}

    # Extract tool_calls from response
    raw_tool_calls: list[dict[str, Any]] = []
    if hasattr(response, "tool_calls") and response.tool_calls:
        for tc in response.tool_calls:
            raw_tool_calls.append({
                "id": tc.get("id", ""),
                "name": tc.get("name", ""),
                "args": tc.get("args", {}),
            })

    logger.info(
        "Tool router selected",
        session_id=state.get("session_id"),
        tools=[tc["name"] for tc in raw_tool_calls],
    )
    return {
        "selected_tools": available,
        "tool_calls": raw_tool_calls,
    }


async def node_tool_executor(state: AgentState) -> dict[str, Any]:
    """
    Execute all pending tool calls. Respects max_tool_calls limit.
    """
    tool_calls = state.get("tool_calls", [])
    tool_call_count = state.get("tool_call_count", 0)
    messages = list(state.get("messages", []))
    results: list[dict[str, Any]] = []

    for tc in tool_calls:
        if tool_call_count >= settings.agent_max_tool_calls:
            raise ToolCallLimitError(settings.agent_max_tool_calls)

        tool_name = tc.get("name", "")
        tool_args = tc.get("args", {})
        tool_id = tc.get("id", tool_name)

        logger.info(
            "Executing tool",
            session_id=state.get("session_id"),
            tool=tool_name,
            call_count=tool_call_count + 1,
        )

        try:
            result = await tool_registry.execute(tool_name, **tool_args)
            result_str = json.dumps(result, ensure_ascii=False, default=str)
            status = "success"
        except Exception as exc:
            result_str = json.dumps({"error": str(exc)})
            status = "error"
            logger.error("Tool failed", tool=tool_name, error=str(exc))

        results.append({"tool": tool_name, "result": result_str, "status": status})
        tool_call_count += 1

        # Append ToolMessage to conversation so LLM sees the result
        messages.append(
            ToolMessage(content=result_str, tool_call_id=tool_id, name=tool_name)
        )

    return {
        "tool_results": results,
        "tool_call_count": tool_call_count,
        "messages": messages,
    }


async def node_llm_answer(state: AgentState) -> dict[str, Any]:
    """
    Generate the final answer using LLM, incorporating tool results.
    """
    llm = LLMAdapter.get_instance()
    user_input = state.get("user_input", "")
    history = state.get("messages", [])
    tool_results = state.get("tool_results", [])

    # Build context with tool results
    tool_context = ""
    if tool_results:
        lines = []
        for tr in tool_results:
            lines.append(f"[Tool: {tr['tool']}] {tr['result']}")
        tool_context = "\nTool Results:\n" + "\n".join(lines)

    system_content = LLM_ANSWER_SYSTEM_PROMPT
    if tool_context:
        system_content += tool_context

    messages = [
        SystemMessage(content=system_content),
        *history[-8:],  # Keep last 8 messages for context
        HumanMessage(content=user_input),
    ]

    try:
        response = await llm.ainvoke(messages)
        answer = response.content if hasattr(response, "content") else str(response)
    except LLMError as exc:
        answer = f"I encountered an error generating the response: {exc.message}"
        logger.error("LLM answer failed", error=str(exc))

    logger.info(
        "LLM answer generated",
        session_id=state.get("session_id"),
        answer_length=len(answer),
    )
    return {
        "final_answer": answer,
        "messages": [AIMessage(content=answer)],
    }


async def node_memory_update(state: AgentState) -> dict[str, Any]:
    """
    Persist the current turn to Redis and run compression if needed.
    """
    session_id = state.get("session_id", "")
    if not session_id:
        return {}

    user_input = state.get("user_input", "")
    final_answer = state.get("final_answer", "")

    if user_input and final_answer:
        await memory_store.append_turn(
            session_id,
            HumanMessage(content=user_input),
            AIMessage(content=final_answer),
        )

        # Run compression if threshold exceeded
        llm = LLMAdapter.get_instance()
        await maybe_compress_session(session_id, memory_store, llm)

    logger.debug("Memory updated", session_id=session_id)
    return {}


# ====================================================================== #
#  Routing conditions (LangGraph conditional_edges)                       #
# ====================================================================== #

def route_after_tool_decision(state: AgentState) -> str:
    """Route to tool_router or llm_answer based on tool_decision."""
    if state.get("should_use_tool"):
        return "tool_router"
    return "llm_answer"


def route_after_tool_router(state: AgentState) -> str:
    """Route to tool_executor or llm_answer if no calls were generated."""
    if state.get("tool_calls"):
        return "tool_executor"
    return "llm_answer"


# ====================================================================== #
#  Safety guard                                                            #
# ====================================================================== #

def _check_max_iterations(state: AgentState) -> None:
    count = state.get("iteration_count", 0)
    if count >= settings.agent_max_iterations:
        raise AgentMaxIterationsError(settings.agent_max_iterations)
