"""
Server-Sent Events (SSE) streaming endpoint.

Endpoint: POST /api/v1/chat/stream
Content-Type: text/event-stream

Event format:
  data: {"type": "token", "data": "...", "session_id": "..."}
  data: {"type": "metadata", "metadata": {...}}
  data: {"type": "done", "session_id": "..."}
  data: {"type": "error", "data": "..."}
"""
from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter, Request
from sse_starlette.sse import EventSourceResponse

from app.agent.graph import get_runner
from app.api.models import ChatRequest, StreamEvent
from app.core.config import settings
from app.core.exceptions import AgentBaseError, AgentTimeoutError
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()


@router.post("/chat/stream", summary="SSE streaming chat")
async def stream_chat(request: Request, body: ChatRequest) -> EventSourceResponse:
    """
    Stream agent response as Server-Sent Events.

    Returns a text/event-stream response. Each event is a JSON object
    with a 'type' field: 'token' | 'metadata' | 'done' | 'error'.
    """

    async def event_generator():
        runner = get_runner()
        session_id = body.session_id
        accumulated_tokens: list[str] = []

        try:
            # Send metadata event first
            meta_event = StreamEvent(
                type="metadata",
                session_id=session_id,
                metadata={
                    "model": settings.llm_model,
                    "provider": settings.llm_provider,
                    "max_iterations": settings.agent_max_iterations,
                },
            )
            yield {"data": meta_event.model_dump_json()}

            # Run graph (tools + context building) then stream tokens
            # We use the non-streaming graph path + then stream the final LLM call
            from app.agent.state import AgentState
            from app.memory.redis_store import memory_store

            initial_state = await runner._build_initial_state(
                session_id=session_id,
                user_input=body.message,
                user_id=body.user_id,
                extra=body.extra,
            )

            # Step 1: Run graph nodes except llm_answer
            graph = runner._graph
            result_state = await asyncio.wait_for(
                graph.ainvoke(initial_state),
                timeout=settings.agent_timeout,
            )

            # Step 2: Stream final LLM tokens
            from app.agent.nodes import LLM_ANSWER_SYSTEM_PROMPT
            from app.llm.adapter import LLMAdapter
            from langchain_core.messages import HumanMessage, SystemMessage, AIMessage

            tool_results = result_state.get("tool_results", [])
            tool_context = ""
            if tool_results:
                lines = [f"[Tool: {tr['tool']}] {tr['result']}" for tr in tool_results]
                tool_context = "\nTool Results:\n" + "\n".join(lines)

            system_content = LLM_ANSWER_SYSTEM_PROMPT + tool_context
            history = result_state.get("messages", [])[-8:]

            messages = [
                SystemMessage(content=system_content),
                *history,
                HumanMessage(content=body.message),
            ]

            llm = LLMAdapter.get_instance()
            async for token in llm.astream_tokens(messages):
                accumulated_tokens.append(token)
                token_event = StreamEvent(
                    type="token",
                    data=token,
                    session_id=session_id,
                )
                yield {"data": token_event.model_dump_json()}

                # Honour client disconnect
                if await request.is_disconnected():
                    logger.info("Client disconnected", session_id=session_id)
                    return

            # Save to memory
            full_answer = "".join(accumulated_tokens)
            await memory_store.append_turn(
                session_id,
                HumanMessage(content=body.message),
                AIMessage(content=full_answer),
            )
            from app.memory.redis_store import maybe_compress_session
            await maybe_compress_session(session_id, memory_store, llm)

            # Done event
            done_event = StreamEvent(
                type="done",
                session_id=session_id,
                metadata={
                    "intent": result_state.get("intent", ""),
                    "intent_confidence": result_state.get("intent_confidence", 0.0),
                    "tool_calls_count": result_state.get("tool_call_count", 0),
                    "total_tokens": len(accumulated_tokens),
                },
            )
            yield {"data": done_event.model_dump_json()}

        except asyncio.TimeoutError:
            error_event = StreamEvent(
                type="error",
                data=f"Request timed out after {settings.agent_timeout}s",
                session_id=session_id,
            )
            yield {"data": error_event.model_dump_json()}
        except AgentBaseError as exc:
            logger.error("Agent error in SSE", error=str(exc), session_id=session_id)
            error_event = StreamEvent(
                type="error",
                data=exc.message,
                session_id=session_id,
            )
            yield {"data": error_event.model_dump_json()}
        except Exception as exc:
            logger.error("Unexpected SSE error", error=str(exc), session_id=session_id)
            error_event = StreamEvent(
                type="error",
                data="Internal server error",
                session_id=session_id,
            )
            yield {"data": error_event.model_dump_json()}

    return EventSourceResponse(event_generator())
