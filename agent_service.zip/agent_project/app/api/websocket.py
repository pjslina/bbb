"""
WebSocket streaming endpoint.

Endpoint: WS /api/v1/ws/{session_id}

Protocol (JSON messages):
  Client → Server:
    {"type": "chat", "message": "...", "user_id": "..."}
    {"type": "ping"}
    {"type": "clear_session"}

  Server → Client:
    {"type": "metadata", "metadata": {...}}
    {"type": "token", "data": "...", "session_id": "..."}
    {"type": "done", "metadata": {...}}
    {"type": "error", "data": "..."}
    {"type": "pong"}
    {"type": "session_cleared"}
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.agent.graph import get_runner
from app.core.config import settings
from app.core.exceptions import AgentBaseError
from app.core.logging import get_logger
from app.memory.redis_store import memory_store

logger = get_logger(__name__)

router = APIRouter()

# Maximum concurrent WebSocket connections per session
_MAX_WS_SESSIONS = 1000
_active_sessions: dict[str, WebSocket] = {}


@router.websocket("/ws/{session_id}")
async def websocket_chat(websocket: WebSocket, session_id: str) -> None:
    """
    WebSocket endpoint for streaming agent responses.

    Maintains a persistent connection per session and handles
    multiple sequential chat turns.
    """
    # Validate session_id
    import re
    if not re.match(r"^[\w\-]+$", session_id):
        await websocket.close(code=4000, reason="Invalid session_id")
        return

    if len(_active_sessions) >= _MAX_WS_SESSIONS:
        await websocket.close(code=4001, reason="Too many connections")
        return

    await websocket.accept()
    _active_sessions[session_id] = websocket
    logger.info("WebSocket connected", session_id=session_id)

    try:
        await _send_json(websocket, {
            "type": "connected",
            "session_id": session_id,
            "config": {
                "max_iterations": settings.agent_max_iterations,
                "max_tool_calls": settings.agent_max_tool_calls,
                "timeout": settings.agent_timeout,
            },
        })

        # Main message loop
        while True:
            try:
                raw = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=300.0,   # 5 min idle timeout
                )
            except asyncio.TimeoutError:
                await _send_json(websocket, {"type": "idle_timeout"})
                break

            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await _send_json(websocket, {"type": "error", "data": "Invalid JSON"})
                continue

            msg_type = msg.get("type", "chat")

            if msg_type == "ping":
                await _send_json(websocket, {"type": "pong"})
                continue

            if msg_type == "clear_session":
                await memory_store.delete_session(session_id)
                await _send_json(websocket, {"type": "session_cleared"})
                logger.info("Session cleared via WS", session_id=session_id)
                continue

            if msg_type == "chat":
                user_message = msg.get("message", "").strip()
                user_id = msg.get("user_id", "")
                extra: dict[str, Any] = msg.get("extra", {})

                if not user_message:
                    await _send_json(websocket, {
                        "type": "error",
                        "data": "Empty message",
                    })
                    continue

                await _handle_chat_turn(
                    websocket=websocket,
                    session_id=session_id,
                    user_message=user_message,
                    user_id=user_id,
                    extra=extra,
                )

    except WebSocketDisconnect:
        logger.info("WebSocket disconnected", session_id=session_id)
    except Exception as exc:
        logger.error("WebSocket error", session_id=session_id, error=str(exc))
        try:
            await _send_json(websocket, {
                "type": "error",
                "data": "Internal server error",
            })
        except Exception:
            pass
    finally:
        _active_sessions.pop(session_id, None)


async def _handle_chat_turn(
    websocket: WebSocket,
    session_id: str,
    user_message: str,
    user_id: str,
    extra: dict[str, Any],
) -> None:
    """Process one chat turn and stream the response."""
    runner = get_runner()

    # Send metadata
    await _send_json(websocket, {
        "type": "metadata",
        "session_id": session_id,
        "metadata": {
            "model": settings.llm_model,
            "provider": settings.llm_provider,
        },
    })

    try:
        # Run graph for tool processing
        initial_state = await runner._build_initial_state(
            session_id=session_id,
            user_input=user_message,
            user_id=user_id,
            extra=extra,
        )

        graph = runner._graph
        result_state = await asyncio.wait_for(
            graph.ainvoke(initial_state),
            timeout=settings.agent_timeout,
        )

        # Stream LLM tokens
        from app.agent.nodes import LLM_ANSWER_SYSTEM_PROMPT
        from app.llm.adapter import LLMAdapter
        from langchain_core.messages import HumanMessage, SystemMessage, AIMessage

        tool_results = result_state.get("tool_results", [])
        tool_context = ""
        if tool_results:
            lines = [f"[Tool: {tr['tool']}] {tr['result']}" for tr in tool_results]
            tool_context = "\nTool Results:\n" + "\n".join(lines)

        system_content = LLM_ANSWER_SYSTEM_PROMPT + tool_context
        history = result_state.get("messages", [])[-8:]
        messages = [
            SystemMessage(content=system_content),
            *history,
            HumanMessage(content=user_message),
        ]

        llm = LLMAdapter.get_instance()
        accumulated = []

        async for token in llm.astream_tokens(messages):
            accumulated.append(token)
            await _send_json(websocket, {
                "type": "token",
                "data": token,
                "session_id": session_id,
            })

        # Save to memory
        full_answer = "".join(accumulated)
        await memory_store.append_turn(
            session_id,
            HumanMessage(content=user_message),
            AIMessage(content=full_answer),
        )
        from app.memory.redis_store import maybe_compress_session
        await maybe_compress_session(session_id, memory_store, llm)

        # Done
        await _send_json(websocket, {
            "type": "done",
            "session_id": session_id,
            "metadata": {
                "intent": result_state.get("intent", ""),
                "intent_confidence": result_state.get("intent_confidence", 0.0),
                "tool_calls_count": result_state.get("tool_call_count", 0),
            },
        })

    except asyncio.TimeoutError:
        await _send_json(websocket, {
            "type": "error",
            "data": f"Request timed out after {settings.agent_timeout}s",
        })
    except AgentBaseError as exc:
        logger.error("Agent error in WS", error=str(exc), session_id=session_id)
        await _send_json(websocket, {"type": "error", "data": exc.message})
    except Exception as exc:
        logger.error("WS turn error", error=str(exc), session_id=session_id)
        await _send_json(websocket, {"type": "error", "data": "Internal error"})


async def _send_json(websocket: WebSocket, data: dict[str, Any]) -> None:
    await websocket.send_text(json.dumps(data, ensure_ascii=False))
