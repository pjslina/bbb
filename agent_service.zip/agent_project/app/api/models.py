"""
API request and response models.
"""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, field_validator


class ChatRequest(BaseModel):
    """Payload for a single-turn chat request."""

    session_id: str = Field(
        ...,
        description="Session identifier. Use the same ID for multi-turn conversations.",
        min_length=1,
        max_length=128,
    )
    message: str = Field(
        ...,
        description="User message text.",
        min_length=1,
        max_length=8192,
    )
    user_id: str = Field(
        default="",
        description="Optional user identifier for personalisation.",
        max_length=128,
    )
    extra: Optional[dict[str, Any]] = Field(
        default=None,
        description="Arbitrary metadata passed through to the agent.",
    )

    @field_validator("session_id")
    @classmethod
    def session_id_no_special_chars(cls, v: str) -> str:
        import re
        if not re.match(r"^[\w\-]+$", v):
            raise ValueError("session_id must contain only word chars and hyphens")
        return v


class ChatResponse(BaseModel):
    """Non-streaming chat response."""

    session_id: str
    message: str
    intent: str = ""
    intent_confidence: float = 0.0
    tool_calls_count: int = 0


class StreamEvent(BaseModel):
    """A single SSE event payload."""

    type: Literal["token", "done", "error", "metadata"]
    data: str = ""
    session_id: str = ""
    metadata: Optional[dict[str, Any]] = None


class SessionInfoResponse(BaseModel):
    """Session status and metadata."""

    session_id: str
    exists: bool
    message_count: int = 0
    meta: dict[str, Any] = Field(default_factory=dict)


class HealthResponse(BaseModel):
    """Service health check."""

    status: Literal["ok", "degraded", "error"]
    service: str
    env: str
    databases: dict[str, str] = Field(default_factory=dict)
    redis: str = "unknown"
