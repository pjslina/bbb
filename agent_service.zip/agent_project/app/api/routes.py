"""
REST API endpoints:
  POST /api/v1/chat          — single-turn, non-streaming
  GET  /api/v1/session/{id}  — session info
  DELETE /api/v1/session/{id} — delete session
  GET  /api/v1/health        — health check
  GET  /api/v1/tools         — list registered tools
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, status

from app.agent.graph import get_runner
from app.api.models import (
    ChatRequest,
    ChatResponse,
    HealthResponse,
    SessionInfoResponse,
)
from app.core.config import settings
from app.core.exceptions import AgentBaseError, SessionNotFoundError
from app.core.logging import get_logger
from app.db.pool import db_manager
from app.memory.redis_store import memory_store
from app.tools.base import tool_registry

logger = get_logger(__name__)

router = APIRouter()


@router.post(
    "/chat",
    response_model=ChatResponse,
    summary="Single-turn chat (non-streaming)",
)
async def chat(body: ChatRequest) -> ChatResponse:
    """
    Execute a single agent turn and return the complete response.
    For streaming, use POST /chat/stream (SSE) or WS /ws/{session_id}.
    """
    runner = get_runner()
    try:
        answer = await runner.run(
            session_id=body.session_id,
            user_input=body.message,
            user_id=body.user_id,
            extra=body.extra,
        )
    except AgentBaseError as exc:
        logger.error(
            "Agent error",
            session_id=body.session_id,
            error=exc.code,
            detail=exc.message,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"code": exc.code, "message": exc.message},
        )

    return ChatResponse(
        session_id=body.session_id,
        message=answer,
    )


@router.get(
    "/session/{session_id}",
    response_model=SessionInfoResponse,
    summary="Get session info",
)
async def get_session(session_id: str) -> SessionInfoResponse:
    exists = await memory_store.session_exists(session_id)
    if not exists:
        return SessionInfoResponse(session_id=session_id, exists=False)

    count = await memory_store.get_message_count(session_id)
    meta = await memory_store.get_meta(session_id)
    return SessionInfoResponse(
        session_id=session_id,
        exists=True,
        message_count=count,
        meta=meta,
    )


@router.delete(
    "/session/{session_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete session",
)
async def delete_session(session_id: str) -> None:
    await memory_store.delete_session(session_id)


@router.get(
    "/tools",
    summary="List registered tools",
)
async def list_tools() -> dict:
    return {
        "tools": [
            {
                "name": name,
                "description": tool_registry.get(name).description,
            }
            for name in tool_registry.names()
        ]
    }


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Health check",
)
async def health_check() -> HealthResponse:
    # Check Redis
    redis_status = "unknown"
    try:
        from app.memory.redis_store import memory_store as ms
        await ms._redis.ping()  # type: ignore[union-attr]
        redis_status = "up"
    except Exception:
        redis_status = "down"

    # Check DBs
    db_health = db_manager.health()

    overall = "ok"
    if redis_status == "down":
        overall = "degraded"
    if all(v != "up" for v in db_health.values()) and db_health:
        overall = "degraded"

    return HealthResponse(
        status=overall,
        service=settings.app_name,
        env=settings.app_env,
        databases=db_health,
        redis=redis_status,
    )
