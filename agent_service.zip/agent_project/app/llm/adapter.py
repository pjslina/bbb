"""
Unified LLM adapter.

All providers (Qwen, GLM, OpenAI) expose an OpenAI-compatible API.
This adapter normalises the interface and handles retry/timeout.
"""
from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator, Sequence

from langchain_core.messages import BaseMessage
from langchain_openai import ChatOpenAI
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.core.config import settings
from app.core.exceptions import LLMError, LLMTimeoutError
from app.core.logging import get_logger

logger = get_logger(__name__)

# Provider-specific base URLs (fallback map)
_PROVIDER_BASE_URLS: dict[str, str] = {
    "qwen": "https://dashscope.aliyuncs.com/compatible-mode/v1",
    "glm": "https://open.bigmodel.cn/api/paas/v4",
    "openai": "https://api.openai.com/v1",
}

# Provider-specific default models
_PROVIDER_MODELS: dict[str, str] = {
    "qwen": "qwen-plus",
    "glm": "glm-4",
    "openai": "gpt-4o",
}


def _build_base_url() -> str:
    """Resolve base URL: prefer explicit setting, fallback to provider map."""
    if settings.llm_base_url:
        return settings.llm_base_url
    return _PROVIDER_BASE_URLS.get(settings.llm_provider, settings.llm_base_url)


def _build_model() -> str:
    if settings.llm_model:
        return settings.llm_model
    return _PROVIDER_MODELS.get(settings.llm_provider, "gpt-4o")


def create_llm(
    *,
    streaming: bool = False,
    temperature: float | None = None,
    max_tokens: int | None = None,
) -> ChatOpenAI:
    """
    Factory: returns a configured ChatOpenAI instance.

    Args:
        streaming:    Enable token streaming.
        temperature:  Override default temperature.
        max_tokens:   Override default max_tokens.
    """
    return ChatOpenAI(
        base_url=_build_base_url(),
        api_key=settings.llm_api_key,
        model=_build_model(),
        temperature=temperature if temperature is not None else settings.llm_temperature,
        max_tokens=max_tokens or settings.llm_max_tokens,
        streaming=streaming,
        timeout=settings.llm_timeout,
        model_kwargs={},
    )


class LLMAdapter:
    """
    Thread-safe singleton wrapper around ChatOpenAI.

    Provides:
    - ainvoke()        — single response
    - astream_tokens() — token-level async generator
    - bind_tools()     — attach tool schemas
    """

    _instance: LLMAdapter | None = None

    def __init__(self) -> None:
        self._llm = create_llm(streaming=False)
        self._llm_streaming = create_llm(streaming=True)
        logger.info(
            "LLM adapter initialised",
            provider=settings.llm_provider,
            model=_build_model(),
            base_url=_build_base_url(),
        )

    @classmethod
    def get_instance(cls) -> "LLMAdapter":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @retry(
        retry=retry_if_exception_type((ConnectionError, TimeoutError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def ainvoke(
        self,
        messages: Sequence[BaseMessage],
        tools: list[dict[str, Any]] | None = None,
    ) -> Any:
        """Invoke LLM, return full response message."""
        try:
            llm = self._llm
            if tools:
                llm = llm.bind_tools(tools)  # type: ignore[arg-type]
            return await asyncio.wait_for(
                llm.ainvoke(list(messages)),
                timeout=settings.llm_timeout,
            )
        except asyncio.TimeoutError as e:
            raise LLMTimeoutError() from e
        except Exception as e:
            raise LLMError(str(e)) from e

    async def astream_tokens(
        self,
        messages: Sequence[BaseMessage],
    ) -> AsyncIterator[str]:
        """Yield token strings as they arrive from the model."""
        try:
            async for chunk in self._llm_streaming.astream(list(messages)):
                content = chunk.content  # type: ignore[union-attr]
                if isinstance(content, str) and content:
                    yield content
                elif isinstance(content, list):
                    for part in content:
                        if isinstance(part, dict) and part.get("type") == "text":
                            yield part.get("text", "")
        except asyncio.TimeoutError as e:
            raise LLMTimeoutError() from e
        except Exception as e:
            raise LLMError(str(e)) from e

    def bind_tools(self, tools: list[Any]) -> Any:
        """Return an LLM instance with tools bound (for function-calling)."""
        return self._llm.bind_tools(tools)
