"""
Redis-backed conversation memory.

Features:
- Auto-load history on session start
- Auto-append new turns
- Token-budget trimming (sliding window)
- Summary compression when threshold exceeded
- TTL-based session expiry
"""
from __future__ import annotations

import json
from typing import Any

import redis.asyncio as aioredis
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    messages_from_dict,
    messages_to_dict,
)

from app.core.config import settings
from app.core.exceptions import MemoryError
from app.core.logging import get_logger

logger = get_logger(__name__)

# Redis key prefixes
_KEY_MESSAGES = "session:{sid}:messages"
_KEY_SUMMARY = "session:{sid}:summary"
_KEY_META = "session:{sid}:meta"


class RedisMemoryStore:
    """
    Async Redis memory store for multi-turn conversations.

    Usage:
        store = RedisMemoryStore.get_instance()
        await store.init()

        history = await store.load_history(session_id)
        await store.append_turn(session_id, human_msg, ai_msg)
        await store.maybe_compress(session_id, llm)
    """

    _instance: "RedisMemoryStore | None" = None

    def __init__(self) -> None:
        self._redis: aioredis.Redis | None = None

    @classmethod
    def get_instance(cls) -> "RedisMemoryStore":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    async def init(self) -> None:
        """Connect to Redis. Called at application startup."""
        try:
            pool = aioredis.ConnectionPool.from_url(
                settings.redis_url,
                password=settings.redis_password or None,
                max_connections=settings.redis_max_connections,
                decode_responses=True,
            )
            self._redis = aioredis.Redis(connection_pool=pool)
            await self._redis.ping()
            logger.info("Redis memory store connected", url=settings.redis_url)
        except Exception as exc:
            raise MemoryError(f"Redis connection failed: {exc}") from exc

    async def close(self) -> None:
        if self._redis:
            await self._redis.aclose()
            logger.info("Redis memory store closed")

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    async def load_history(self, session_id: str) -> list[BaseMessage]:
        """
        Load full message history for a session.
        Prepends summary (if any) as a SystemMessage.
        """
        self._ensure_connected()
        key = _KEY_MESSAGES.format(sid=session_id)
        raw = await self._redis.get(key)  # type: ignore[union-attr]
        messages: list[BaseMessage] = []

        # Inject prior summary as system context
        summary = await self._get_summary(session_id)
        if summary:
            messages.append(
                SystemMessage(content=f"[Prior conversation summary]\n{summary}")
            )

        if raw:
            try:
                dicts = json.loads(raw)
                messages.extend(messages_from_dict(dicts))
            except Exception as exc:
                logger.warning(
                    "Failed to deserialise history, starting fresh",
                    session_id=session_id,
                    error=str(exc),
                )

        logger.debug(
            "History loaded",
            session_id=session_id,
            message_count=len(messages),
            has_summary=bool(summary),
        )
        return messages

    async def append_turn(
        self,
        session_id: str,
        human_msg: HumanMessage,
        ai_msg: AIMessage,
    ) -> None:
        """Append a human+AI turn to the session history."""
        self._ensure_connected()
        key = _KEY_MESSAGES.format(sid=session_id)

        # Load existing
        existing = await self._load_raw_messages(session_id)
        existing.extend([human_msg, ai_msg])

        serialised = json.dumps(messages_to_dict(existing), ensure_ascii=False)
        pipe = self._redis.pipeline()  # type: ignore[union-attr]
        pipe.set(key, serialised)
        pipe.expire(key, settings.session_ttl)
        await pipe.execute()

        logger.debug(
            "Turn appended",
            session_id=session_id,
            total_messages=len(existing),
        )

    async def update_messages(
        self, session_id: str, messages: list[BaseMessage]
    ) -> None:
        """Replace the full message list for a session (used after compression)."""
        self._ensure_connected()
        key = _KEY_MESSAGES.format(sid=session_id)
        # Filter out system messages (summary injected dynamically)
        filtered = [m for m in messages if not isinstance(m, SystemMessage)]
        serialised = json.dumps(messages_to_dict(filtered), ensure_ascii=False)
        pipe = self._redis.pipeline()  # type: ignore[union-attr]
        pipe.set(key, serialised)
        pipe.expire(key, settings.session_ttl)
        await pipe.execute()

    async def set_summary(self, session_id: str, summary: str) -> None:
        key = _KEY_SUMMARY.format(sid=session_id)
        pipe = self._redis.pipeline()  # type: ignore[union-attr]
        pipe.set(key, summary)
        pipe.expire(key, settings.session_ttl)
        await pipe.execute()
        logger.info("Session summary stored", session_id=session_id)

    async def get_message_count(self, session_id: str) -> int:
        msgs = await self._load_raw_messages(session_id)
        return len(msgs)

    async def delete_session(self, session_id: str) -> None:
        self._ensure_connected()
        keys = [
            _KEY_MESSAGES.format(sid=session_id),
            _KEY_SUMMARY.format(sid=session_id),
            _KEY_META.format(sid=session_id),
        ]
        await self._redis.delete(*keys)  # type: ignore[union-attr]
        logger.info("Session deleted", session_id=session_id)

    async def session_exists(self, session_id: str) -> bool:
        self._ensure_connected()
        key = _KEY_MESSAGES.format(sid=session_id)
        return bool(await self._redis.exists(key))  # type: ignore[union-attr]

    async def get_meta(self, session_id: str) -> dict[str, Any]:
        self._ensure_connected()
        key = _KEY_META.format(sid=session_id)
        raw = await self._redis.get(key)  # type: ignore[union-attr]
        if raw:
            return json.loads(raw)
        return {}

    async def set_meta(self, session_id: str, meta: dict[str, Any]) -> None:
        self._ensure_connected()
        key = _KEY_META.format(sid=session_id)
        pipe = self._redis.pipeline()  # type: ignore[union-attr]
        pipe.set(key, json.dumps(meta, ensure_ascii=False))
        pipe.expire(key, settings.session_ttl)
        await pipe.execute()

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                    #
    # ------------------------------------------------------------------ #

    async def _load_raw_messages(self, session_id: str) -> list[BaseMessage]:
        key = _KEY_MESSAGES.format(sid=session_id)
        raw = await self._redis.get(key)  # type: ignore[union-attr]
        if not raw:
            return []
        try:
            return messages_from_dict(json.loads(raw))
        except Exception:
            return []

    async def _get_summary(self, session_id: str) -> str:
        key = _KEY_SUMMARY.format(sid=session_id)
        result = await self._redis.get(key)  # type: ignore[union-attr]
        return result or ""

    def _ensure_connected(self) -> None:
        if self._redis is None:
            raise MemoryError("RedisMemoryStore not initialised. Call init() first.")


# ------------------------------------------------------------------ #
#  Compression utility                                                 #
# ------------------------------------------------------------------ #

SUMMARISE_PROMPT = """You are a conversation summariser.
Summarise the following conversation in 3-5 concise sentences,
preserving key facts, user preferences, and any decisions made.
Output ONLY the summary, no preamble.

Conversation:
{conversation}
"""


async def maybe_compress_session(
    session_id: str,
    store: RedisMemoryStore,
    llm: Any,  # LLMAdapter
) -> bool:
    """
    If message count exceeds SUMMARY_THRESHOLD, summarise older turns
    and replace them with the summary, keeping only the most recent
    `SUMMARY_THRESHOLD // 2` messages.

    Returns True if compression was performed.
    """
    count = await store.get_message_count(session_id)
    if count < settings.summary_threshold:
        return False

    messages = await store._load_raw_messages(session_id)
    keep_n = settings.summary_threshold // 2
    to_summarise = messages[:-keep_n]
    to_keep = messages[-keep_n:]

    # Build text for summarisation
    lines = []
    for m in to_summarise:
        role = "User" if isinstance(m, HumanMessage) else "Assistant"
        lines.append(f"{role}: {m.content}")
    conversation_text = "\n".join(lines)

    from langchain_core.messages import HumanMessage as HM
    summary_response = await llm.ainvoke(
        [HM(content=SUMMARISE_PROMPT.format(conversation=conversation_text))]
    )
    summary_text = summary_response.content if hasattr(summary_response, "content") else str(summary_response)

    await store.set_summary(session_id, summary_text)
    await store.update_messages(session_id, to_keep)

    logger.info(
        "Session compressed",
        session_id=session_id,
        original_count=count,
        kept=len(to_keep),
    )
    return True


memory_store = RedisMemoryStore.get_instance()
