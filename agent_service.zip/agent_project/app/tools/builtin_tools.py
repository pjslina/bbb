"""
Built-in tools shipped with the agent.

Tools:
- DatabaseQueryTool  — executes approved SQL templates
- HttpApiTool        — calls external REST APIs
- CalculatorTool     — safe arithmetic evaluation
- WeatherTool        — example external API tool (mock)

All tools self-register into tool_registry on import.
"""
from __future__ import annotations

import ast
import operator as op
import re
from typing import Any

import httpx

from app.core.config import settings
from app.core.exceptions import ToolExecutionError
from app.core.logging import get_logger
from app.db.query import execute_template, get_template_names
from app.tools.base import BaseTool, tool_registry

logger = get_logger(__name__)


# --------------------------------------------------------------------------- #
#  1. Database Query Tool                                                      #
# --------------------------------------------------------------------------- #
class DatabaseQueryTool(BaseTool):
    """
    Execute pre-approved SQL templates against the database.

    The LLM CANNOT write SQL. It may only select a template name
    and supply typed parameters defined in the template schema.
    """

    @property
    def name(self) -> str:
        return "database_query"

    @property
    def description(self) -> str:
        return (
            "Query the database using an approved SQL template. "
            "Available templates: " + ", ".join(get_template_names())
        )

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "template_name": {
                            "type": "string",
                            "description": "Name of the SQL template to execute.",
                            "enum": get_template_names(),
                        },
                        "params": {
                            "type": "object",
                            "description": "Bind parameters for the template.",
                        },
                        "scene": {
                            "type": "string",
                            "description": "DB routing scene. Default: 'default'.",
                            "default": "default",
                        },
                    },
                    "required": ["template_name", "params"],
                },
            },
        }

    async def execute(  # type: ignore[override]
        self,
        template_name: str,
        params: dict[str, Any],
        scene: str = "default",
        **_: Any,
    ) -> list[dict[str, Any]]:
        return await execute_template(template_name, params, scene=scene)


# --------------------------------------------------------------------------- #
#  2. HTTP API Tool                                                             #
# --------------------------------------------------------------------------- #
class HttpApiTool(BaseTool):
    """
    Call an external REST API via GET or POST.
    URL must match an allow-list to prevent SSRF.
    """

    # Allow-list of base URLs the agent may call
    ALLOWED_ORIGINS = {
        "https://api.example.com",
        "https://api.weather.gov",
        "https://api.exchangerate.host",
    }

    @property
    def name(self) -> str:
        return "http_api"

    @property
    def description(self) -> str:
        return (
            "Call an external HTTP API. "
            "Only whitelisted domains are permitted."
        )

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "Full URL to call.",
                        },
                        "method": {
                            "type": "string",
                            "enum": ["GET", "POST"],
                            "default": "GET",
                        },
                        "payload": {
                            "type": "object",
                            "description": "JSON body for POST requests.",
                        },
                        "headers": {
                            "type": "object",
                            "description": "Optional request headers.",
                        },
                    },
                    "required": ["url"],
                },
            },
        }

    async def execute(  # type: ignore[override]
        self,
        url: str,
        method: str = "GET",
        payload: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        **_: Any,
    ) -> dict[str, Any]:
        self._validate_url(url)

        async with httpx.AsyncClient(timeout=15.0) as client:
            if method.upper() == "POST":
                resp = await client.post(url, json=payload or {}, headers=headers or {})
            else:
                resp = await client.get(url, headers=headers or {})
            resp.raise_for_status()
            return resp.json()

    def _validate_url(self, url: str) -> None:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        if origin not in self.ALLOWED_ORIGINS:
            raise ToolExecutionError(
                self.name,
                f"URL origin {origin!r} is not in the allow-list.",
            )


# --------------------------------------------------------------------------- #
#  3. Calculator Tool                                                           #
# --------------------------------------------------------------------------- #

# Allowed AST node types for safe eval
_ALLOWED_NODES = (
    ast.Expression, ast.BinOp, ast.UnaryOp,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod, ast.Pow, ast.FloorDiv,
    ast.USub, ast.UAdd,
    ast.Num, ast.Constant,
)

_OPS: dict[type, Any] = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Mod: op.mod,
    ast.Pow: op.pow,
    ast.FloorDiv: op.floordiv,
    ast.USub: op.neg,
    ast.UAdd: op.pos,
}


def _safe_eval(node: ast.AST) -> float:
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError(f"Unsupported expression: {ast.dump(node)}")


class CalculatorTool(BaseTool):
    """Safe arithmetic calculator using AST parsing (no eval())."""

    @property
    def name(self) -> str:
        return "calculator"

    @property
    def description(self) -> str:
        return (
            "Evaluate a safe arithmetic expression. "
            "Supports +, -, *, /, **, //, %. "
            "No variables or function calls."
        )

    def tool_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "expression": {
                            "type": "string",
                            "description": "Arithmetic expression, e.g. '(12 + 3) * 4 / 2'.",
                        }
                    },
                    "required": ["expression"],
                },
            },
        }

    async def execute(self, expression: str, **_: Any) -> dict[str, Any]:  # type: ignore[override]
        # Strip whitespace and basic sanity check
        expr = expression.strip()
        if not re.match(r"^[\d\s\+\-\*\/\(\)\.\%\*\*]+$", expr):
            raise ToolExecutionError(self.name, f"Invalid expression: {expr!r}")
        try:
            tree = ast.parse(expr, mode="eval")
            result = _safe_eval(tree)
            return {"expression": expr, "result": result}
        except Exception as exc:
            raise ToolExecutionError(self.name, str(exc)) from exc


# --------------------------------------------------------------------------- #
#  Auto-register all built-in tools                                            #
# --------------------------------------------------------------------------- #
def register_builtin_tools() -> None:
    """Call once at application startup."""
    tool_registry.register(DatabaseQueryTool())
    tool_registry.register(HttpApiTool())
    tool_registry.register(CalculatorTool())
    logger.info("Built-in tools registered", tools=tool_registry.names())
