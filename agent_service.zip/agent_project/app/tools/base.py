"""
Tool base class and pluggable registry.

All tools must:
1. Subclass BaseTool
2. Define a JSON schema via tool_schema()
3. Implement async execute()

The ToolRegistry is the single source of truth for available tools.
LLM only receives tool names + schemas — never implementation code.
"""
from __future__ import annotations

import abc
import time
from typing import Any

from app.core.exceptions import ToolExecutionError, ToolNotFoundError
from app.core.logging import get_logger

logger = get_logger(__name__)


class BaseTool(abc.ABC):
    """Abstract base for all agent tools."""

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Unique tool identifier. Snake_case."""

    @property
    @abc.abstractmethod
    def description(self) -> str:
        """Human/LLM-readable description of what this tool does."""

    @abc.abstractmethod
    def tool_schema(self) -> dict[str, Any]:
        """
        OpenAI function-calling compatible schema.
        Example:
          {
            "type": "function",
            "function": {
                "name": "search_products",
                "description": "...",
                "parameters": {
                    "type": "object",
                    "properties": { ... },
                    "required": [...]
                }
            }
          }
        """

    @abc.abstractmethod
    async def execute(self, **kwargs: Any) -> Any:
        """Execute the tool. Raise ToolExecutionError on failure."""


class ToolRegistry:
    """
    Central registry for all agent tools.

    Tools are registered at startup and can be added/removed at runtime
    (e.g., feature flags, A/B testing, per-tenant tools).
    """

    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        self._tools[tool.name] = tool
        logger.info("Tool registered", tool=tool.name)

    def unregister(self, name: str) -> None:
        if name in self._tools:
            del self._tools[name]
            logger.info("Tool unregistered", tool=name)

    def get(self, name: str) -> BaseTool:
        tool = self._tools.get(name)
        if tool is None:
            raise ToolNotFoundError(name)
        return tool

    def all_schemas(self) -> list[dict[str, Any]]:
        """Return all tool schemas for LLM function-calling."""
        return [t.tool_schema() for t in self._tools.values()]

    def names(self) -> list[str]:
        return list(self._tools.keys())

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    async def execute(self, name: str, **kwargs: Any) -> Any:
        """Execute a tool by name with timing + error wrapping."""
        tool = self.get(name)
        start = time.perf_counter()
        try:
            result = await tool.execute(**kwargs)
            elapsed = time.perf_counter() - start
            logger.info(
                "Tool executed",
                tool=name,
                elapsed_ms=round(elapsed * 1000, 1),
            )
            return result
        except ToolExecutionError:
            raise
        except Exception as exc:
            elapsed = time.perf_counter() - start
            logger.error(
                "Tool execution error",
                tool=name,
                elapsed_ms=round(elapsed * 1000, 1),
                error=str(exc),
            )
            raise ToolExecutionError(name, str(exc)) from exc


# Global registry — tools register themselves at import time
tool_registry = ToolRegistry()
