# AI Agent - 生产级智能体系统

基于 **FastAPI + LangGraph 1.x** 构建的单Agent智能体，支持SSE/WebSocket双通道流式输出。

## 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│                        FastAPI Server                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   SSE API   │  │  WebSocket  │  │    REST API         │  │
│  │ /chat/stream│  │ /chat/ws    │  │ /chat /health       │  │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │
│         └─────────────────┴────────────────────┘              │
│                              │                                │
│                    ┌─────────┴─────────┐                      │
│                    │   Stream Manager   │                      │
│                    │  (统一流式输出)     │                      │
│                    └─────────┬─────────┘                      │
│                              │                                │
│              ┌───────────────┼───────────────┐                │
│              │           LangGraph            │                │
│              │    StateGraph (1.x LTS)        │                │
│              └───────────────┬───────────────┘                │
│                              │                                │
│    ┌──────────┬──────────┬──┴──┬──────────┬──────────┐      │
│    │  Safety  │  Intent  │Tool │  Tool    │   LLM    │      │
│    │  Guard   │Recognize │Router│ Execute │  Answer  │      │
│    └──────────┴──────────┴─────┴──────────┴──────────┘      │
│                              │                                │
│                    ┌─────────┴─────────┐                      │
│                    │   Memory Update    │                      │
│                    └─────────┬─────────┘                      │
└──────────────────────────────┼───────────────────────────────┘
                               │
        ┌──────────────────────┼──────────────────────┐
        │                      │                      │
   ┌────┴────┐          ┌─────┴─────┐         ┌─────┴─────┐
   │  Redis  │          │  LLM API  │         │  Database │
   │ (Memory)│          │ Qwen/GLM  │         │Pool/Router│
   └─────────┘          └───────────┘         └───────────┘
```

## 核心特性

### 1. 双通道流式输出
- **SSE** (`/api/v1/chat/stream`): Server-Sent Events，适合Web前端
- **WebSocket** (`/api/v1/chat/ws/{session_id}`): 全双工通信，适合实时交互
- 统一 `StreamManager` 管理，状态机驱动

### 2. LangGraph 1.x StateGraph
```
start -> safety_guard -> intent_recognition -> [tool_decision -> tool_execution] -> llm_answer -> memory_update -> end
```
- 可插拔节点设计
- 条件路由（按意图分发）
- MemorySaver checkpoint

### 3. 工具体系
| 工具 | 类型 | 说明 |
|------|------|------|
| `api_call` | API | 通用HTTP API调用 |
| `weather_query` | API | 天气查询示例 |
| `db_query` | DB | 安全模板化数据库查询 |
| `db_aggregate` | DB | 聚合查询(SUM/AVG/COUNT/MAX/MIN) |

- `ToolRouter`: 自动工具选择
- `ToolRegistry`: 动态注册/发现

### 4. 数据库安全
- **禁止LLM直接拼SQL**
- 预定义SQL模板 + 参数绑定
- 表名/字段名白名单校验
- 多PostgreSQL/OpenGauss支持
- 连接池 + 动态路由（按场景/标签）

### 5. 多轮对话 & 记忆
- Redis存储对话历史
- 自动加载历史上下文
- 会话压缩（Token裁剪 + Summary Memory）
- 会话TTL管理

### 6. Agent安全控制
- `max_iterations`: 最大迭代次数（默认10）
- `timeout`: 单次请求超时（默认120s）
- `max_tool_calls_per_session`: 工具调用上限（默认20）

### 7. LLM统一适配
- 支持 Qwen / GLM / OpenAI
- 统一通过OpenAI兼容接口对接
- 流式/非流式统一接口

## 快速开始

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 配置环境变量
```bash
cp .env.example .env
# 编辑 .env 文件，配置LLM API Key和数据库连接
```

### 3. 启动服务
```bash
python -m app.main
# 或
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### 4. 测试接口

#### SSE流式
```bash
curl -N -H "Content-Type: application/json" \
  -d '{"session_id":"test-001","message":"查询今天的天气","stream":true}' \
  http://localhost:8000/api/v1/chat/stream
```

#### WebSocket
```javascript
const ws = new WebSocket('ws://localhost:8000/api/v1/chat/ws/test-001');
ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log(data.type, data.content);
};
ws.send(JSON.stringify({message: "查询北京天气"}));
```

#### 非流式
```bash
curl -H "Content-Type: application/json" \
  -d '{"session_id":"test-001","message":"你好"}' \
  http://localhost:8000/api/v1/chat
```

## 项目结构

```
ai_agent/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI入口
│   ├── config.py            # 配置管理
│   ├── logger.py            # 结构化日志
│   ├── graph.py             # LangGraph构建
│   ├── models/
│   │   ├── schemas.py       # Pydantic模型
│   │   └── state.py         # LangGraph状态定义
│   ├── core/
│   │   ├── llm.py           # LLM统一适配器
│   │   └── memory.py        # Redis记忆管理
│   ├── nodes/
│   │   ├── intent_recognition.py
│   │   ├── tool_decision.py
│   │   ├── tool_execution.py
│   │   ├── llm_answer.py
│   │   ├── memory_update.py
│   │   ├── safety_guard.py
│   │   └── stream_manager.py
│   ├── tools/
│   │   ├── base.py          # 工具基类
│   │   ├── registry.py      # 工具注册表
│   │   ├── api_tools.py     # API工具
│   │   ├── db_tools.py      # 数据库工具
│   │   └── router.py        # 工具路由器
│   ├── database/
│   │   ├── templates.py     # SQL安全模板
│   │   ├── pool.py          # 连接池管理
│   │   ├── router.py        # 动态路由
│   │   └── manager.py       # 数据库操作管理
│   └── api/
│       └── routes.py        # API路由
├── requirements.txt
├── .env.example
└── README.md
```

## 扩展指南

### 添加新工具
1. 继承 `BaseTool`
2. 实现 `get_schema()` 和 `execute()`
3. 在 `app/api/routes.py` 的 `init_tools()` 中注册

```python
from app.tools.base import BaseTool, ToolSchema

class MyTool(BaseTool):
    name = "my_tool"
    description = "我的工具"

    def get_schema(self):
        return ToolSchema(name=self.name, description=self.description, parameters={...})

    async def execute(self, params):
        return {"success": True, "result": ...}
```

### 添加新数据库
在 `.env` 的 `DATABASES` 中添加新配置：
```json
{"name":"analytics_db","db_type":"postgresql","host":"...","tags":["analytics"]}
```

### 自定义SQL模板
在 `app/database/templates.py` 的 `SQLTemplateRegistry` 中注册新模板。

## 生产部署建议

1. **使用Gunicorn + Uvicorn Worker**
```bash
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

2. **Nginx反向代理**
- SSE: 配置 `proxy_buffering off;`
- WebSocket: 配置 `proxy_http_version 1.1; proxy_set_header Upgrade $http_upgrade;`

3. **监控**
- 结构化日志已配置，可接入ELK/Loki
- 健康检查: `GET /api/v1/health`

4. **安全**
- 生产环境限制CORS域名
- 数据库密码使用环境变量或密钥管理服务
- 启用API认证（可扩展JWT中间件）

## 依赖版本

| 包 | 版本 | 说明 |
|----|------|------|
| langgraph | 1.1.9 | 核心图引擎 |
| langgraph-checkpoint | 4.0.2 | 状态持久化 |
| fastapi | >=0.115.0 | Web框架 |
| asyncpg | >=0.30.0 | 异步PostgreSQL |
| redis | >=5.0.0 | 缓存与记忆 |
| openai | >=1.60.0 | LLM客户端 |
| structlog | >=25.0.0 | 结构化日志 |

## License

MIT
