"""
Redis记忆管理
支持多轮对话历史、自动加载、会话压缩、Summary Memory
"""
import json
import asyncio
from typing import List, Dict, Any, Optional
from datetime import datetime
import redis.asyncio as redis
from app.config import settings, MemoryConfig
from app.models.schemas import ChatMessage, MessageRole, SessionSummary
from app.logger import get_logger

logger = get_logger("memory")


class MemoryManager:
    """记忆管理器"""

    def __init__(self, config: MemoryConfig = None):
        self.config = config or settings.memory
        self.redis_client: Optional[redis.Redis] = None
        self._lock = asyncio.Lock()

    async def connect(self):
        """连接Redis"""
        if self.redis_client is None:
            self.redis_client = redis.Redis(
                host=settings.redis.host,
                port=settings.redis.port,
                db=settings.redis.db,
                password=settings.redis.password,
                decode_responses=settings.redis.decode_responses,
                socket_connect_timeout=settings.redis.socket_connect_timeout,
                socket_timeout=settings.redis.socket_timeout,
                max_connections=settings.redis.max_connections,
            )
            await self.redis_client.ping()
            logger.info("redis_connected", host=settings.redis.host, port=settings.redis.port)

    async def disconnect(self):
        """断开Redis"""
        if self.redis_client:
            await self.redis_client.close()
            self.redis_client = None

    def _session_key(self, session_id: str) -> str:
        return f"agent:session:{session_id}"

    def _summary_key(self, session_id: str) -> str:
        return f"agent:summary:{session_id}"

    def _metadata_key(self, session_id: str) -> str:
        return f"agent:meta:{session_id}"

    async def load_history(self, session_id: str) -> List[ChatMessage]:
        """加载历史消息"""
        await self.connect()
        key = self._session_key(session_id)
        data = await self.redis_client.lrange(key, 0, -1)
        messages = []
        for item in data:
            try:
                msg_dict = json.loads(item)
                messages.append(ChatMessage(**msg_dict))
            except Exception as e:
                logger.warning("parse_history_failed", error=str(e), item=item)
        logger.info("history_loaded", session_id=session_id, count=len(messages))
        return messages

    async def append_message(self, session_id: str, message: ChatMessage):
        """追加消息到历史"""
        await self.connect()
        key = self._session_key(session_id)
        async with self._lock:
            await self.redis_client.rpush(key, message.model_dump_json())
            await self.redis_client.expire(key, self.config.session_ttl)

            # 检查是否需要压缩
            length = await self.redis_client.llen(key)
            if length > self.config.max_history_messages:
                await self._compress_session(session_id)

    async def append_messages(self, session_id: str, messages: List[ChatMessage]):
        """批量追加消息"""
        for msg in messages:
            await self.append_message(session_id, msg)

    async def get_summary(self, session_id: str) -> Optional[str]:
        """获取会话摘要"""
        await self.connect()
        summary = await self.redis_client.get(self._summary_key(session_id))
        return summary

    async def save_summary(self, session_id: str, summary: str):
        """保存会话摘要"""
        await self.connect()
        await self.redis_client.set(
            self._summary_key(session_id),
            summary,
            ex=self.config.session_ttl
        )

    async def _compress_session(self, session_id: str):
        """会话压缩：保留摘要 + 最近消息"""
        if not self.config.enable_summary:
            # 不启用summary时，直接裁剪
            key = self._session_key(session_id)
            await self.redis_client.ltrim(key, -self.config.max_history_messages // 2, -1)
            return

        from app.core.llm import get_llm
        llm = get_llm()

        key = self._session_key(session_id)
        all_data = await self.redis_client.lrange(key, 0, -1)

        # 取前一半生成summary
        half_point = len(all_data) // 2
        old_messages = all_data[:half_point]

        # 构建summary prompt
        summary_prompt = "请对以下对话进行简洁摘要，保留关键信息：\n\n"
        for item in old_messages:
            try:
                msg = json.loads(item)
                summary_prompt += f"{msg['role']}: {msg['content']}\n"
            except:
                continue

        try:
            result = await llm.chat([
                {"role": "system", "content": "你是一个对话摘要助手。请用简洁的中文总结对话要点。"},
                {"role": "user", "content": summary_prompt}
            ], max_tokens=500)

            new_summary = result["content"]
            existing_summary = await self.get_summary(session_id)
            if existing_summary:
                new_summary = f"{existing_summary}\n\n[新摘要]\n{new_summary}"

            await self.save_summary(session_id, new_summary)

            # 裁剪：保留后一半
            await self.redis_client.ltrim(key, half_point, -1)
            logger.info("session_compressed", session_id=session_id, old_len=len(all_data))
        except Exception as e:
            logger.error("compression_failed", error=str(e), session_id=session_id)
            # 降级：直接裁剪
            await self.redis_client.ltrim(key, -self.config.max_history_messages // 2, -1)

    async def get_context_messages(self, session_id: str) -> List[Dict[str, str]]:
        """获取用于LLM上下文的消息列表（含summary）"""
        messages = await self.load_history(session_id)
        summary = await self.get_summary(session_id)

        result = []
        if summary:
            result.append({
                "role": "system",
                "content": f"[历史对话摘要]\n{summary}"
            })

        for msg in messages:
            result.append({
                "role": msg.role.value,
                "content": msg.content,
            })

        return result

    async def clear_session(self, session_id: str):
        """清除会话"""
        await self.connect()
        await self.redis_client.delete(self._session_key(session_id))
        await self.redis_client.delete(self._summary_key(session_id))
        await self.redis_client.delete(self._metadata_key(session_id))
        logger.info("session_cleared", session_id=session_id)


# 全局记忆管理器单例
_memory_instance: Optional[MemoryManager] = None


async def get_memory_manager() -> MemoryManager:
    """获取记忆管理器"""
    global _memory_instance
    if _memory_instance is None:
        _memory_instance = MemoryManager()
        await _memory_instance.connect()
    return _memory_instance
