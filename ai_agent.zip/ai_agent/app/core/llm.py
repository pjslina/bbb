"""
LLM统一适配器
支持Qwen / GLM / OpenAI，统一通过OpenAI兼容接口对接
"""
import asyncio
from typing import AsyncIterator, List, Dict, Any, Optional
from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionMessageParam
from app.config import settings, LLMConfig
from app.logger import get_logger

logger = get_logger("llm")


class LLMProvider:
    """LLM提供者基类"""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.client = AsyncOpenAI(
            api_key=config.api_key,
            base_url=config.base_url,
            timeout=config.timeout,
            max_retries=config.max_retries,
        )
        logger.info(
            "llm_provider_initialized",
            provider=config.provider,
            model=config.model,
            base_url=config.base_url,
        )

    async def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        """非流式对话"""
        try:
            params = {
                "model": self.config.model,
                "messages": messages,
                "temperature": temperature or self.config.temperature,
                "max_tokens": max_tokens or self.config.max_tokens,
                "stream": False,
            }
            if tools:
                params["tools"] = tools
                params["tool_choice"] = "auto"

            response = await self.client.chat.completions.create(**params)

            return {
                "content": response.choices[0].message.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": tc.type,
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments,
                        }
                    }
                    for tc in (response.choices[0].message.tool_calls or [])
                ],
                "usage": {
                    "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                    "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                    "total_tokens": response.usage.total_tokens if response.usage else 0,
                }
            }
        except Exception as e:
            logger.error("llm_chat_error", error=str(e), provider=self.config.provider)
            raise

    async def chat_stream(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[str]:
        """流式对话（SSE/WebSocket统一使用）"""
        try:
            response = await self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=temperature or self.config.temperature,
                max_tokens=max_tokens or self.config.max_tokens,
                stream=True,
            )

            async for chunk in response:
                delta = chunk.choices[0].delta
                if delta.content:
                    yield delta.content
        except Exception as e:
            logger.error("llm_stream_error", error=str(e), provider=self.config.provider)
            raise

    async def embed(self, texts: List[str]) -> List[List[float]]:
        """获取文本嵌入（用于记忆压缩等）"""
        try:
            response = await self.client.embeddings.create(
                model=self.config.model,
                input=texts,
            )
            return [item.embedding for item in response.data]
        except Exception as e:
            logger.error("llm_embed_error", error=str(e))
            raise


# 全局LLM实例
_llm_instance: Optional[LLMProvider] = None


def get_llm() -> LLMProvider:
    """获取LLM单例"""
    global _llm_instance
    if _llm_instance is None:
        _llm_instance = LLMProvider(settings.llm)
    return _llm_instance
