"""
生产级配置管理
支持环境变量覆盖，具备完整的类型校验
"""
from typing import List, Dict, Any, Optional
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings
import os


class DatabaseConfig(BaseSettings):
    """数据库节点配置"""
    name: str
    db_type: str = Field(..., pattern="^(postgresql|openguass)$")
    host: str
    port: int
    database: str
    user: str
    password: str
    min_size: int = 5
    max_size: int = 20
    command_timeout: int = 60
    schema: str = "public"
    # 动态路由标签
    tags: List[str] = Field(default_factory=list)

    class Config:
        extra = "allow"


class LLMConfig(BaseSettings):
    """LLM配置"""
    provider: str = Field(..., pattern="^(qwen|glm|openai)$")
    api_key: str
    base_url: str
    model: str
    temperature: float = 0.7
    max_tokens: int = 4096
    timeout: float = 60.0
    max_retries: int = 3


class RedisConfig(BaseSettings):
    """Redis配置"""
    host: str = "localhost"
    port: int = 6379
    db: int = 0
    password: Optional[str] = None
    decode_responses: bool = True
    socket_connect_timeout: int = 5
    socket_timeout: int = 5
    max_connections: int = 50


class AgentSafetyConfig(BaseSettings):
    """Agent防失控配置"""
    max_iterations: int = 10
    timeout_seconds: float = 120.0
    max_tool_calls_per_session: int = 20
    enable_tool_call_rate_limit: bool = True


class MemoryConfig(BaseSettings):
    """记忆配置"""
    max_history_messages: int = 20
    summary_threshold: int = 10
    compression_ratio: float = 0.5
    session_ttl: int = 86400  # 24小时
    enable_summary: bool = True


class Settings(BaseSettings):
    """全局配置"""
    # App
    app_name: str = "AI-Agent"
    app_version: str = "1.0.0"
    debug: bool = False

    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1

    # LLM
    llm: LLMConfig = Field(default_factory=lambda: LLMConfig(
        provider="qwen",
        api_key=os.getenv("LLM_API_KEY", ""),
        base_url=os.getenv("LLM_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
        model=os.getenv("LLM_MODEL", "qwen-max")
    ))

    # Redis
    redis: RedisConfig = Field(default_factory=RedisConfig)

    # Databases (支持多实例)
    databases: List[DatabaseConfig] = Field(default_factory=list)

    # Agent Safety
    safety: AgentSafetyConfig = Field(default_factory=AgentSafetyConfig)

    # Memory
    memory: MemoryConfig = Field(default_factory=MemoryConfig)

    # Logging
    log_level: str = "INFO"
    log_format: str = "json"

    @field_validator("databases", mode="before")
    @classmethod
    def parse_databases(cls, v):
        """支持从JSON字符串解析数据库配置"""
        if isinstance(v, str):
            import json
            return json.loads(v)
        return v

    class Config:
        env_file = ".env"
        env_nested_delimiter = "__"
        case_sensitive = False


# 全局配置单例
settings = Settings()


def get_db_config_by_tag(tag: str) -> Optional[DatabaseConfig]:
    """按标签获取数据库配置（动态路由）"""
    for db in settings.databases:
        if tag in db.tags:
            return db
    return None


def get_db_config_by_name(name: str) -> Optional[DatabaseConfig]:
    """按名称获取数据库配置"""
    for db in settings.databases:
        if db.name == name:
            return db
    return None
