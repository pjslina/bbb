"""
FastAPI 路由
支持双通道流式：SSE + WebSocket
"""
import json
import asyncio
import time
from typing import Optional
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from app.models.schemas import ChatRequest, ChatResponse, ChatResponseChunk, MessageRole
from app.models.state import AgentState
from app.graph import get_agent_graph
from app.core.memory import get_memory_manager
from app.core.llm import get_llm
from app.nodes.stream_manager import get_stream_manager
from app.tools.registry import get_registry
from app.tools.api_tools import APICallTool, WeatherTool
from app.tools.db_tools import DBQueryTool, DBAggregateTool
from app.database.pool import get_pool_manager
from app.config import settings
from app.logger import get_logger, configure_logging

logger = get_logger("api")

router = APIRouter(prefix="/api/v1")


# === 初始化工具 ===
def init_tools():
    """初始化并注册所有工具"""
    registry = get_registry()
    registry.register(APICallTool())
    registry.register(WeatherTool())
    registry.register(DBQueryTool())
    registry.register(DBAggregateTool())
    logger.info("tools_initialized", count=len(registry.list_tools()))


# === 构建初始状态 ===
def build_initial_state(request: ChatRequest) -> AgentState:
    """构建Agent初始状态"""
    return AgentState(
        session_id=request.session_id,
        user_input=request.message,
        messages=[],
        iteration_count=0,
        tool_call_count=0,
        should_stop=False,
        context=request.context,
        db_route_tag=request.db_route_tag,
    )


# === SSE 流式接口 ===
@router.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    """SSE流式对话接口"""
    session_id = request.session_id
    stream_mgr = get_stream_manager()
    queue = stream_mgr.create_queue(session_id)

    async def event_generator():
        try:
            graph = get_agent_graph()
            state = build_initial_state(request)

            # 发送开始信号
            await stream_mgr.send_state(session_id, "start", {"input": request.message[:50]})

            # 运行图
            start_time = time.time()
            config = {"configurable": {"thread_id": session_id}}

            async for event in graph.astream(state, config, stream_mode="values"):
                # 提取状态变化
                current_state = event

                # 发送节点状态
                if "intent_result" in current_state and current_state["intent_result"]:
                    await stream_mgr.send_state(
                        session_id,
                        "intent_recognition",
                        {
                            "intent": current_state["intent_result"].intent.value,
                            "confidence": current_state["intent_result"].confidence,
                        }
                    )

                if "selected_tools" in current_state and current_state["selected_tools"]:
                    await stream_mgr.send_state(
                        session_id,
                        "tool_decision",
                        {"tools": current_state["selected_tools"]}
                    )

                if "tool_results" in current_state and current_state["tool_results"]:
                    for tr in current_state["tool_results"]:
                        await stream_mgr.send_tool_result(
                            session_id,
                            tr.tool_name,
                            {
                                "success": tr.success,
                                "result": tr.result,
                                "error": tr.error,
                            }
                        )

                if "final_response" in current_state and current_state["final_response"]:
                    # 流式发送回答
                    response_text = current_state["final_response"]
                    # 模拟逐字输出
                    chunk_size = 4
                    for i in range(0, len(response_text), chunk_size):
                        chunk = response_text[i:i+chunk_size]
                        await stream_mgr.send_text(session_id, chunk)
                        await asyncio.sleep(0.02)  # 控制流式速度

                if current_state.get("should_stop"):
                    break

            elapsed = time.time() - start_time
            await stream_mgr.send_state(session_id, "end", {"elapsed_ms": round(elapsed * 1000, 2)})
            await stream_mgr.send_done(session_id)

        except Exception as e:
            logger.error("stream_error", session_id=session_id, error=str(e))
            await stream_mgr.send_error(session_id, str(e))
            await stream_mgr.send_done(session_id)

    # 启动后台任务
    asyncio.create_task(event_generator())

    async def sse_generator():
        async for chunk in stream_mgr.consume(session_id):
            data = chunk.model_dump_json()
            yield f"data: {data}\n\n"

    return StreamingResponse(
        sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        }
    )


# === WebSocket 接口 ===
@router.websocket("/chat/ws/{session_id}")
async def chat_websocket(websocket: WebSocket, session_id: str):
    """WebSocket流式对话接口"""
    await websocket.accept()
    stream_mgr = get_stream_manager()
    queue = stream_mgr.create_queue(session_id)

    try:
        while True:
            # 接收消息
            data = await websocket.receive_json()
            message = data.get("message", "")
            context = data.get("context", {})
            db_route_tag = data.get("db_route_tag")

            request = ChatRequest(
                session_id=session_id,
                message=message,
                context=context,
                db_route_tag=db_route_tag,
            )

            graph = get_agent_graph()
            state = build_initial_state(request)

            # 发送开始信号
            await websocket.send_json({
                "type": "state",
                "content": "开始处理",
                "data": {"node": "start"}
            })

            # 运行图
            config = {"configurable": {"thread_id": session_id}}
            async for event in graph.astream(state, config, stream_mode="values"):
                current_state = event

                # 发送各节点状态
                if "intent_result" in current_state and current_state["intent_result"]:
                    await websocket.send_json({
                        "type": "state",
                        "content": f"意图: {current_state['intent_result'].intent.value}",
                        "data": {
                            "node": "intent_recognition",
                            "intent": current_state["intent_result"].intent.value,
                            "confidence": current_state["intent_result"].confidence,
                        }
                    })

                if "selected_tools" in current_state and current_state["selected_tools"]:
                    await websocket.send_json({
                        "type": "tool_call",
                        "content": f"调用工具: {', '.join(current_state['selected_tools'])}",
                        "data": {"tools": current_state["selected_tools"]}
                    })

                if "tool_results" in current_state and current_state["tool_results"]:
                    for tr in current_state["tool_results"]:
                        await websocket.send_json({
                            "type": "tool_result",
                            "content": f"{tr.tool_name}: {'成功' if tr.success else '失败'}",
                            "data": {
                                "tool_name": tr.tool_name,
                                "success": tr.success,
                                "result": tr.result,
                                "error": tr.error,
                            }
                        })

                if "final_response" in current_state and current_state["final_response"]:
                    response_text = current_state["final_response"]
                    # WebSocket也支持流式分块
                    chunk_size = 8
                    for i in range(0, len(response_text), chunk_size):
                        chunk = response_text[i:i+chunk_size]
                        await websocket.send_json({
                            "type": "text",
                            "content": chunk,
                            "data": {"finished": i + chunk_size >= len(response_text)}
                        })
                        await asyncio.sleep(0.015)

                if current_state.get("should_stop"):
                    break

            await websocket.send_json({
                "type": "done",
                "content": "",
                "data": {}
            })

    except WebSocketDisconnect:
        logger.info("websocket_disconnected", session_id=session_id)
    except Exception as e:
        logger.error("websocket_error", session_id=session_id, error=str(e))
        await websocket.send_json({
            "type": "error",
            "content": str(e),
            "data": {}
        })
    finally:
        stream_mgr.remove_queue(session_id)


# === 非流式接口 ===
@router.post("/chat")
async def chat(request: ChatRequest) -> ChatResponse:
    """非流式对话接口"""
    session_id = request.session_id

    try:
        graph = get_agent_graph()
        state = build_initial_state(request)
        config = {"configurable": {"thread_id": session_id}}

        # 同步运行图
        result = await graph.ainvoke(state, config)

        return ChatResponse(
            session_id=session_id,
            response=result.get("final_response", ""),
            tool_results=result.get("tool_results", []),
            state={
                "session_id": session_id,
                "current_node": "end",
                "intent": result.get("intent_result"),
                "tool_calls": result.get("tool_calls", []),
                "tool_results": result.get("tool_results", []),
                "iteration_count": result.get("iteration_count", 0),
                "tool_call_count": result.get("tool_call_count", 0),
            },
        )
    except Exception as e:
        logger.error("chat_error", session_id=session_id, error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


# === 会话管理接口 ===
@router.delete("/session/{session_id}")
async def clear_session(session_id: str):
    """清除会话历史"""
    memory = await get_memory_manager()
    await memory.clear_session(session_id)
    return {"session_id": session_id, "status": "cleared"}


@router.get("/session/{session_id}/history")
async def get_session_history(session_id: str):
    """获取会话历史"""
    memory = await get_memory_manager()
    messages = await memory.load_history(session_id)
    return {
        "session_id": session_id,
        "messages": [msg.model_dump() for msg in messages],
        "count": len(messages),
    }


# === 健康检查 ===
@router.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "healthy",
        "version": settings.app_version,
        "llm_provider": settings.llm.provider,
        "tools": get_registry().list_tools(),
    }
