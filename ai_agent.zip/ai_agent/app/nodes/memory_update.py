"""
记忆更新节点
自动保存对话历史到Redis
"""
from typing import Dict, Any
from app.models.state import AgentState
from app.models.schemas import ChatMessage, MessageRole
from app.core.memory import get_memory_manager
from app.logger import get_logger

logger = get_logger("node.memory")


async def memory_update_node(state: AgentState) -> Dict[str, Any]:
    """
    记忆更新节点
    保存用户输入和助手回复到Redis
    """
    session_id = state["session_id"]
    user_input = state["user_input"]
    final_response = state.get("final_response", "")

    logger.info("memory_update_start", session_id=session_id)

    try:
        memory = await get_memory_manager()

        # 保存用户消息
        user_msg = ChatMessage(role=MessageRole.USER, content=user_input)
        await memory.append_message(session_id, user_msg)

        # 保存助手消息
        if final_response:
            assistant_msg = ChatMessage(role=MessageRole.ASSISTANT, content=final_response)
            await memory.append_message(session_id, assistant_msg)

        # 获取最新summary
        summary = await memory.get_summary(session_id)

        logger.info("memory_update_done", session_id=session_id, has_summary=bool(summary))

        return {
            "memory_summary": summary or "",
        }
    except Exception as e:
        logger.error("memory_update_error", session_id=session_id, error=str(e))
        return {
            "memory_summary": state.get("memory_summary", ""),
            "error": str(e),
        }
