"""
工具决策节点
根据意图和上下文，决定是否需要调用工具、调用哪些工具
"""
from typing import Dict, Any
from app.models.state import AgentState
from app.models.schemas import IntentType, ToolCall
from app.tools.router import get_tool_router
from app.tools.registry import get_registry
from app.logger import get_logger

logger = get_logger("node.tool_decision")


async def tool_decision_node(state: AgentState) -> Dict[str, Any]:
    """
    工具决策节点
    根据意图决定是否需要工具调用
    """
    session_id = state["session_id"]
    intent_result = state.get("intent_result")
    user_input = state["user_input"]
    tool_call_count = state.get("tool_call_count", 0)

    logger.info("tool_decision_start", session_id=session_id, tool_call_count=tool_call_count)

    # 检查工具调用次数限制
    if tool_call_count >= 5:  # 单次对话最多5次工具调用
        logger.warning("tool_call_limit_reached", session_id=session_id, count=tool_call_count)
        return {
            "selected_tools": [],
            "should_stop": False,
        }

    # 根据意图判断是否需要工具
    intent = intent_result.intent if intent_result else IntentType.UNKNOWN

    needs_tool = intent in [
        IntentType.DATABASE_QUERY,
        IntentType.API_CALL,
        IntentType.DATA_ANALYSIS,
    ]

    if not needs_tool:
        logger.info("no_tool_needed", session_id=session_id, intent=intent.value)
        return {
            "selected_tools": [],
            "should_stop": False,
        }

    # 使用工具路由器自动选择工具
    router = get_tool_router()
    selected = await router.route(user_input, intent.value, state.get("context", {}))

    tool_calls = []
    for tool_name in selected:
        tool_calls.append(ToolCall(tool_name=tool_name, tool_input={}))

    logger.info(
        "tool_decision_done",
        session_id=session_id,
        selected_tools=selected,
        tool_call_count=tool_call_count + len(tool_calls),
    )

    return {
        "selected_tools": selected,
        "tool_calls": tool_calls,
        "tool_call_count": tool_call_count + len(tool_calls),
        "should_stop": False,
    }
