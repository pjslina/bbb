"""
流式输出管理器
统一SSE和WebSocket的流式输出，状态机驱动
"""
import asyncio
from typing import AsyncIterator, Dict, Any, Optional
from app.models.schemas import ChatResponseChunk
from app.logger import get_logger

logger = get_logger("stream_manager")


class StreamManager:
    """流式输出管理器"""

    def __init__(self):
        self._queues: Dict[str, asyncio.Queue] = {}

    def create_queue(self, session_id: str) -> asyncio.Queue:
        """为会话创建消息队列"""
        queue = asyncio.Queue()
        self._queues[session_id] = queue
        return queue

    def get_queue(self, session_id: str) -> Optional[asyncio.Queue]:
        """获取会话队列"""
        return self._queues.get(session_id)

    def remove_queue(self, session_id: str):
        """移除会话队列"""
        if session_id in self._queues:
            del self._queues[session_id]

    async def send(self, session_id: str, chunk: ChatResponseChunk):
        """发送消息块到队列"""
        queue = self.get_queue(session_id)
        if queue:
            await queue.put(chunk)

    async def send_text(self, session_id: str, text: str):
        """发送文本块"""
        await self.send(session_id, ChatResponseChunk(type="text", content=text))

    async def send_tool_call(self, session_id: str, tool_name: str, data: Dict[str, Any]):
        """发送工具调用块"""
        await self.send(session_id, ChatResponseChunk(
            type="tool_call",
            content=f"调用工具: {tool_name}",
            data=data
        ))

    async def send_tool_result(self, session_id: str, tool_name: str, data: Dict[str, Any]):
        """发送工具结果块"""
        await self.send(session_id, ChatResponseChunk(
            type="tool_result",
            content=f"工具结果: {tool_name}",
            data=data
        ))

    async def send_state(self, session_id: str, node: str, data: Dict[str, Any]):
        """发送状态更新块"""
        await self.send(session_id, ChatResponseChunk(
            type="state",
            content=f"进入节点: {node}",
            data={"node": node, **data}
        ))

    async def send_error(self, session_id: str, error: str):
        """发送错误块"""
        await self.send(session_id, ChatResponseChunk(type="error", content=error))

    async def send_done(self, session_id: str):
        """发送完成信号"""
        await self.send(session_id, ChatResponseChunk(type="done", content=""))

    async def consume(self, session_id: str) -> AsyncIterator[ChatResponseChunk]:
        """消费队列中的消息（用于SSE/WebSocket）"""
        queue = self.get_queue(session_id)
        if not queue:
            logger.error("queue_not_found", session_id=session_id)
            return

        try:
            while True:
                chunk = await queue.get()
                yield chunk
                if chunk.type == "done":
                    break
        except asyncio.CancelledError:
            logger.info("stream_cancelled", session_id=session_id)
        finally:
            self.remove_queue(session_id)


# 全局流式管理器
_stream_manager = StreamManager()


def get_stream_manager() -> StreamManager:
    return _stream_manager
