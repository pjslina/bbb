"""
工具执行节点
执行选中的工具，收集结果
"""
import asyncio
from typing import Dict, Any
from app.models.state import AgentState
from app.models.schemas import ToolResult
from app.tools.registry import get_registry
from app.logger import get_logger

logger = get_logger("node.tool_execution")


async def tool_execution_node(state: AgentState) -> Dict[str, Any]:
    """
    工具执行节点
    执行所有选中的工具
    """
    session_id = state["session_id"]
    selected_tools = state.get("selected_tools", [])
    tool_calls = state.get("tool_calls", [])

    logger.info("tool_execution_start", session_id=session_id, tool_count=len(selected_tools))

    if not selected_tools:
        return {"tool_results": [], "should_stop": False}

    registry = get_registry()
    results = []

    for call in tool_calls:
        tool_name = call.tool_name
        tool_input = call.tool_input

        tool = registry.get(tool_name)
        if not tool:
            results.append(ToolResult(
                tool_name=tool_name,
                tool_call_id=call.tool_call_id,
                success=False,
                error=f"工具未找到: {tool_name}",
            ))
            continue

        try:
            start = asyncio.get_event_loop().time()
            exec_result = await tool.execute(tool_input)
            elapsed = (asyncio.get_event_loop().time() - start) * 1000

            results.append(ToolResult(
                tool_name=tool_name,
                tool_call_id=call.tool_call_id,
                success=exec_result.get("success", False),
                result=exec_result.get("result"),
                error=exec_result.get("error"),
                execution_time_ms=round(elapsed, 2),
            ))

            logger.info(
                "tool_executed",
                session_id=session_id,
                tool=tool_name,
                success=exec_result.get("success", False),
                elapsed_ms=round(elapsed, 2),
            )
        except Exception as e:
            logger.error("tool_execution_error", session_id=session_id, tool=tool_name, error=str(e))
            results.append(ToolResult(
                tool_name=tool_name,
                tool_call_id=call.tool_call_id,
                success=False,
                error=str(e),
            ))

    return {
        "tool_results": results,
        "should_stop": False,
    }
