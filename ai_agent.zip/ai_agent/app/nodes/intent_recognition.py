"""
意图识别节点
按意图分发到不同处理分支
"""
from typing import Dict, Any
from app.models.state import AgentState
from app.models.schemas import IntentResult, IntentType
from app.core.llm import get_llm
from app.logger import get_logger

logger = get_logger("node.intent")


INTENT_PROMPT = """你是一个意图识别专家。请分析用户输入，判断其意图类别。

可选意图：
- general: 一般对话、问候、闲聊
- database_query: 需要查询数据库、统计数据、报表
- api_call: 需要调用外部API、获取实时信息
- data_analysis: 需要分析数据、计算、对比
- unknown: 无法判断

请输出JSON格式：
{
    "intent": "意图类别",
    "confidence": 0.95,
    "entities": {},
    "reason": "判断理由"
}"""


async def intent_recognition_node(state: AgentState) -> Dict[str, Any]:
    """
    意图识别节点
    输入: state["user_input"]
    输出: state["intent_result"]
    """
    user_input = state["user_input"]
    session_id = state["session_id"]

    logger.info("intent_recognition_start", session_id=session_id, input_preview=user_input[:50])

    try:
        llm = get_llm()
        result = await llm.chat([
            {"role": "system", "content": INTENT_PROMPT},
            {"role": "user", "content": user_input}
        ], temperature=0.1, max_tokens=300)

        import json
        content = result["content"].strip()
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]

        data = json.loads(content.strip())

        intent_result = IntentResult(
            intent=IntentType(data.get("intent", "unknown")),
            confidence=float(data.get("confidence", 0.0)),
            entities=data.get("entities", {}),
            reason=data.get("reason", ""),
        )

        logger.info(
            "intent_recognition_done",
            session_id=session_id,
            intent=intent_result.intent.value,
            confidence=intent_result.confidence,
        )

        return {
            "intent_result": intent_result,
            "iteration_count": state["iteration_count"] + 1,
        }
    except Exception as e:
        logger.error("intent_recognition_error", session_id=session_id, error=str(e))
        return {
            "intent_result": IntentResult(
                intent=IntentType.UNKNOWN,
                confidence=0.0,
                reason=f"识别失败: {str(e)}"
            ),
            "error": str(e),
            "iteration_count": state["iteration_count"] + 1,
        }
