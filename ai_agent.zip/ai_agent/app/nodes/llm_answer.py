"""
LLM回答节点
根据上下文生成最终回答，支持流式输出
"""
from typing import Dict, Any
from app.models.state import AgentState
from app.models.schemas import ChatMessage, MessageRole
from app.core.llm import get_llm
from app.core.memory import get_memory_manager
from app.logger import get_logger

logger = get_logger("node.llm_answer")


SYSTEM_PROMPT = """你是一个智能助手。请根据用户问题和可用信息提供准确、有帮助的回答。

注意事项：
1. 如果使用了工具查询结果，请基于结果进行回答
2. 如果工具执行失败，请礼貌告知用户
3. 保持回答简洁、专业
4. 如果不确定，请明确说明"""


async def llm_answer_node(state: AgentState) -> Dict[str, Any]:
    """
    LLM回答节点
    生成最终回复
    """
    session_id = state["session_id"]
    user_input = state["user_input"]
    tool_results = state.get("tool_results", [])
    intent_result = state.get("intent_result")
    memory_summary = state.get("memory_summary", "")

    logger.info("llm_answer_start", session_id=session_id)

    try:
        # 加载历史上下文
        memory = await get_memory_manager()
        history = await memory.get_context_messages(session_id)

        # 构建消息
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]

        if memory_summary:
            messages.append({
                "role": "system",
                "content": f"[历史摘要]\n{memory_summary}"
            })

        messages.extend(history)

        # 添加工具结果上下文
        if tool_results:
            tool_context = "工具执行结果：\n"
            for r in tool_results:
                if r.success:
                    tool_context += f"- {r.tool_name}: {r.result}\n"
                else:
                    tool_context += f"- {r.tool_name}: 执行失败 - {r.error}\n"
            messages.append({"role": "system", "content": tool_context})

        # 添加意图信息
        if intent_result:
            messages.append({
                "role": "system",
                "content": f"[意图识别] {intent_result.intent.value} (置信度: {intent_result.confidence})"
            })

        messages.append({"role": "user", "content": user_input})

        llm = get_llm()
        result = await llm.chat(messages, temperature=0.7)

        response_text = result["content"]

        logger.info("llm_answer_done", session_id=session_id, response_preview=response_text[:50])

        return {
            "final_response": response_text,
            "should_stop": True,
        }
    except Exception as e:
        logger.error("llm_answer_error", session_id=session_id, error=str(e))
        return {
            "final_response": "抱歉，处理您的请求时出现了错误，请稍后重试。",
            "error": str(e),
            "should_stop": True,
        }
