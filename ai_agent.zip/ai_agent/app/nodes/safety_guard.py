"""
安全守卫节点
Agent防失控：max_iterations、timeout、tool调用次数限制
"""
import time
from typing import Dict, Any
from app.models.state import AgentState
from app.config import settings
from app.logger import get_logger

logger = get_logger("node.safety")


async def safety_guard_node(state: AgentState) -> Dict[str, Any]:
    """
    安全守卫节点
    在每个迭代周期检查安全限制
    """
    session_id = state["session_id"]
    iteration_count = state.get("iteration_count", 0)
    tool_call_count = state.get("tool_call_count", 0)

    safety = settings.safety

    # 检查迭代次数
    if iteration_count >= safety.max_iterations:
        logger.warning(
            "max_iterations_reached",
            session_id=session_id,
            iterations=iteration_count,
            max=safety.max_iterations,
        )
        return {
            "should_stop": True,
            "stop_reason": f"达到最大迭代次数限制 ({safety.max_iterations})",
            "final_response": "抱歉，处理您的请求需要太多步骤，我已停止执行。请简化您的问题或稍后重试。",
        }

    # 检查工具调用次数
    if tool_call_count >= safety.max_tool_calls_per_session:
        logger.warning(
            "max_tool_calls_reached",
            session_id=session_id,
            tool_calls=tool_call_count,
            max=safety.max_tool_calls_per_session,
        )
        return {
            "should_stop": True,
            "stop_reason": f"达到单次会话工具调用次数限制 ({safety.max_tool_calls_per_session})",
            "final_response": "抱歉，本次对话中工具调用次数已达上限。如需继续，请开启新对话。",
        }

    # 检查错误状态
    if state.get("error"):
        logger.warning(
            "error_detected",
            session_id=session_id,
            error=state["error"],
        )
        return {
            "should_stop": True,
            "stop_reason": f"执行错误: {state['error']}",
        }

    return {
        "should_stop": False,
    }


async def timeout_guard(start_time: float) -> bool:
    """超时检查"""
    elapsed = time.time() - start_time
    if elapsed > settings.safety.timeout_seconds:
        logger.warning("timeout_reached", elapsed=elapsed, max=settings.safety.timeout_seconds)
        return True
    return False
