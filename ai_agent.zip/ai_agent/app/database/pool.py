"""
数据库连接池管理
支持多PostgreSQL、多OpenGauss实例
使用asyncpg + 连接池
"""
import asyncpg
from typing import Dict, Optional
from app.config import settings, DatabaseConfig
from app.logger import get_logger

logger = get_logger("db_pool")


class DatabasePool:
    """数据库连接池封装"""

    def __init__(self, config: DatabaseConfig):
        self.config = config
        self.pool: Optional[asyncpg.Pool] = None
        self._initialized = False

    async def initialize(self):
        """初始化连接池"""
        if self._initialized:
            return

        try:
            # asyncpg原生支持PostgreSQL协议，OpenGauss兼容该协议
            self.pool = await asyncpg.create_pool(
                host=self.config.host,
                port=self.config.port,
                database=self.config.database,
                user=self.config.user,
                password=self.config.password,
                min_size=self.config.min_size,
                max_size=self.config.max_size,
                command_timeout=self.config.command_timeout,
                server_settings={
                    "application_name": f"ai_agent_{self.config.name}",
                    "search_path": self.config.schema,
                }
            )
            self._initialized = True
            logger.info(
                "db_pool_initialized",
                name=self.config.name,
                db_type=self.config.db_type,
                host=self.config.host,
                port=self.config.port,
                min_size=self.config.min_size,
                max_size=self.config.max_size,
            )
        except Exception as e:
            logger.error(
                "db_pool_init_failed",
                name=self.config.name,
                error=str(e),
            )
            raise

    async def close(self):
        """关闭连接池"""
        if self.pool:
            await self.pool.close()
            self._initialized = False
            logger.info("db_pool_closed", name=self.config.name)

    async def fetch(self, sql: str, *args) -> list:
        """查询多条"""
        if not self.pool:
            raise RuntimeError(f"连接池未初始化: {self.config.name}")
        async with self.pool.acquire() as conn:
            return await conn.fetch(sql, *args)

    async def fetchrow(self, sql: str, *args) -> Optional[asyncpg.Record]:
        """查询单条"""
        if not self.pool:
            raise RuntimeError(f"连接池未初始化: {self.config.name}")
        async with self.pool.acquire() as conn:
            return await conn.fetchrow(sql, *args)

    async def fetchval(self, sql: str, *args):
        """查询单个值"""
        if not self.pool:
            raise RuntimeError(f"连接池未初始化: {self.config.name}")
        async with self.pool.acquire() as conn:
            return await conn.fetchval(sql, *args)

    async def execute(self, sql: str, *args) -> str:
        """执行（INSERT/UPDATE/DELETE）"""
        if not self.pool:
            raise RuntimeError(f"连接池未初始化: {self.config.name}")
        async with self.pool.acquire() as conn:
            return await conn.execute(sql, *args)

    async def transaction(self):
        """获取事务上下文"""
        if not self.pool:
            raise RuntimeError(f"连接池未初始化: {self.config.name}")
        return self.pool.acquire()


class PoolManager:
    """连接池管理器（管理多个数据库实例）"""

    def __init__(self):
        self._pools: Dict[str, DatabasePool] = {}

    async def initialize_all(self):
        """初始化所有配置的连接池"""
        for db_config in settings.databases:
            pool = DatabasePool(db_config)
            await pool.initialize()
            self._pools[db_config.name] = pool

    async def close_all(self):
        """关闭所有连接池"""
        for name, pool in self._pools.items():
            await pool.close()
        self._pools.clear()

    def get_pool(self, name: str) -> Optional[DatabasePool]:
        """按名称获取连接池"""
        return self._pools.get(name)

    def get_pool_by_tag(self, tag: str) -> Optional[DatabasePool]:
        """按标签获取连接池（动态路由）"""
        from app.config import get_db_config_by_tag
        db_config = get_db_config_by_tag(tag)
        if db_config:
            return self._pools.get(db_config.name)
        return None

    def list_pools(self) -> Dict[str, str]:
        """列出所有连接池"""
        return {name: pool.config.db_type for name, pool in self._pools.items()}


# 全局连接池管理器
_pool_manager = PoolManager()


async def get_pool_manager() -> PoolManager:
    """获取连接池管理器"""
    return _pool_manager


def get_pool(name: str) -> Optional[DatabasePool]:
    """快捷获取连接池"""
    return _pool_manager.get_pool(name)
