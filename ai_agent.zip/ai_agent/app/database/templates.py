"""
SQL安全模板系统
核心原则：禁止LLM直接拼接SQL，所有SQL必须预定义模板 + 参数绑定
"""
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass
from enum import Enum
import re
from app.logger import get_logger

logger = get_logger("db_templates")


class SQLTemplateType(str, Enum):
    SELECT = "SELECT"
    INSERT = "INSERT"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    AGGREGATE = "AGGREGATE"


@dataclass
class SQLTemplate:
    """SQL模板定义"""
    name: str
    template_type: SQLTemplateType
    # 使用%s或$1风格参数占位符
    sql: str
    # 参数定义：name -> (type, required, description)
    params: Dict[str, tuple]
    # 允许的表白名单（安全校验）
    allowed_tables: List[str]
    # 最大返回行数
    max_rows: int = 1000
    # 是否只读
    read_only: bool = True
    # 描述
    description: str = ""


class SQLTemplateRegistry:
    """SQL模板注册表"""

    def __init__(self):
        self._templates: Dict[str, SQLTemplate] = {}
        self._init_default_templates()

    def _init_default_templates(self):
        """初始化默认安全模板"""

        # === 查询类模板 ===
        self.register(SQLTemplate(
            name="select_by_id",
            template_type=SQLTemplateType.SELECT,
            sql="SELECT * FROM {table} WHERE id = $1 LIMIT 1",
            params={
                "table": ("str", True, "表名"),
                "id": ("int", True, "主键ID"),
            },
            allowed_tables=["*"],  # 实际生产应限制
            read_only=True,
            description="根据ID查询单条记录"
        ))

        self.register(SQLTemplate(
            name="select_list",
            template_type=SQLTemplateType.SELECT,
            sql="SELECT * FROM {table} WHERE 1=1 {conditions} ORDER BY {order_by} LIMIT $1 OFFSET $2",
            params={
                "table": ("str", True, "表名"),
                "conditions": ("str", False, "额外条件（已预校验）"),
                "order_by": ("str", False, "排序字段，默认id DESC"),
                "limit": ("int", False, "分页大小"),
                "offset": ("int", False, "分页偏移"),
            },
            allowed_tables=["*"],
            read_only=True,
            max_rows=100,
            description="分页查询列表"
        ))

        self.register(SQLTemplate(
            name="select_count",
            template_type=SQLTemplateType.SELECT,
            sql="SELECT COUNT(*) as total FROM {table} WHERE 1=1 {conditions}",
            params={
                "table": ("str", True, "表名"),
                "conditions": ("str", False, "额外条件"),
            },
            allowed_tables=["*"],
            read_only=True,
            description="统计记录数"
        ))

        self.register(SQLTemplate(
            name="select_aggregate",
            template_type=SQLTemplateType.AGGREGATE,
            sql="SELECT {agg_func}({agg_column}) as result FROM {table} WHERE 1=1 {conditions}",
            params={
                "table": ("str", True, "表名"),
                "agg_func": ("str", True, "聚合函数：SUM/AVG/COUNT/MAX/MIN"),
                "agg_column": ("str", True, "聚合字段"),
                "conditions": ("str", False, "额外条件"),
            },
            allowed_tables=["*"],
            read_only=True,
            description="聚合查询"
        ))

        # === 写入类模板（严格限制） ===
        self.register(SQLTemplate(
            name="insert_record",
            template_type=SQLTemplateType.INSERT,
            sql="INSERT INTO {table} ({columns}) VALUES ({placeholders}) RETURNING *",
            params={
                "table": ("str", True, "表名"),
                "columns": ("str", True, "字段列表，逗号分隔"),
                "placeholders": ("str", True, "参数占位符"),
            },
            allowed_tables=["*"],
            read_only=False,
            description="插入记录"
        ))

    def register(self, template: SQLTemplate):
        """注册模板"""
        self._templates[template.name] = template
        logger.debug("template_registered", name=template.name)

    def get(self, name: str) -> Optional[SQLTemplate]:
        """获取模板"""
        return self._templates.get(name)

    def list_templates(self) -> List[str]:
        """列出所有模板名"""
        return list(self._templates.keys())

    def validate_table_name(self, table: str) -> bool:
        """校验表名安全（防止SQL注入）"""
        # 只允许字母、数字、下划线
        if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', table):
            return False
        return True

    def validate_column_name(self, column: str) -> bool:
        """校验字段名安全"""
        if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', column):
            return False
        return True

    def render(self, name: str, params: Dict[str, Any]) -> tuple:
        """
        渲染模板，返回 (sql, bound_params)
        bound_params 用于参数绑定
        """
        template = self.get(name)
        if not template:
            raise ValueError(f"SQL模板不存在: {name}")

        # 校验表名
        table = params.get("table", "")
        if table and not self.validate_table_name(table):
            raise ValueError(f"非法表名: {table}")

        # 校验聚合函数（白名单）
        if template.template_type == SQLTemplateType.AGGREGATE:
            agg_func = params.get("agg_func", "").upper()
            if agg_func not in ("SUM", "AVG", "COUNT", "MAX", "MIN"):
                raise ValueError(f"非法聚合函数: {agg_func}")

        # 构建SQL和参数列表
        sql = template.sql
        bound_params = []
        param_index = 1

        # 替换 {table} 等占位符（这些不是参数绑定的，是模板变量）
        for key, value in params.items():
            placeholder = "{" + key + "}"
            if placeholder in sql:
                if key == "table" and not self.validate_table_name(str(value)):
                    raise ValueError(f"非法表名: {value}")
                sql = sql.replace(placeholder, str(value))
            else:
                # 作为绑定参数
                bound_params.append(value)
                sql = sql.replace(f"${param_index}", f"${param_index}", 1)  # 保持原样
                param_index += 1

        # 安全检查：禁止危险关键字
        dangerous = ["DROP", "TRUNCATE", "ALTER", "GRANT", "REVOKE", "EXECUTE", "UNION"]
        sql_upper = sql.upper()
        for d in dangerous:
            if d in sql_upper and template.read_only:
                raise ValueError(f"只读模板中禁止包含关键字: {d}")

        logger.info(
            "template_rendered",
            name=name,
            read_only=template.read_only,
            param_count=len(bound_params)
        )
        return sql, bound_params


# 全局模板注册表
_template_registry = SQLTemplateRegistry()


def get_template_registry() -> SQLTemplateRegistry:
    return _template_registry
