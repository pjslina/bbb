"""
数据库动态路由器
按场景/标签动态路由到不同数据库实例
"""
from typing import Optional
from app.config import settings, get_db_config_by_tag, get_db_config_by_name
from app.database.pool import get_pool, DatabasePool
from app.logger import get_logger

logger = get_logger("db_router")


class DatabaseRouter:
    """数据库路由器"""

    # 场景 -> 数据库标签映射
    SCENARIO_MAP = {
        "order": ["order_db", "main_db"],
        "user": ["user_db", "main_db"],
        "product": ["product_db", "main_db"],
        "analytics": ["analytics_db", "report_db"],
        "default": ["main_db"],
    }

    @classmethod
    def route_by_scenario(cls, scenario: str) -> Optional[DatabasePool]:
        """按场景路由"""
        tags = cls.SCENARIO_MAP.get(scenario, cls.SCENARIO_MAP["default"])
        for tag in tags:
            pool = get_pool_by_tag(tag)
            if pool:
                logger.info("db_routed", scenario=scenario, tag=tag, pool=pool.config.name)
                return pool

        # fallback到第一个可用池
        pools = list(get_pool_manager()._pool_manager._pools.values())
        if pools:
            logger.warning("db_route_fallback", scenario=scenario, fallback=pools[0].config.name)
            return pools[0]
        return None

    @classmethod
    def route_by_tag(cls, tag: str) -> Optional[DatabasePool]:
        """按标签路由"""
        pool = get_pool_by_tag(tag)
        if pool:
            logger.info("db_routed_by_tag", tag=tag, pool=pool.config.name)
            return pool
        return None

    @classmethod
    def route_by_name(cls, name: str) -> Optional[DatabasePool]:
        """按名称路由"""
        pool = get_pool(name)
        if pool:
            logger.info("db_routed_by_name", name=name)
            return pool
        return None


def get_pool_by_tag(tag: str) -> Optional[DatabasePool]:
    """快捷方法：按标签获取连接池"""
    from app.database.pool import _pool_manager
    return _pool_manager.get_pool_by_tag(tag)
