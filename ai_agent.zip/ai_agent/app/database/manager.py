"""
数据库操作管理器
封装安全的数据库操作，禁止直接执行LLM生成的SQL
"""
from typing import List, Dict, Any, Optional
from app.database.pool import DatabasePool, get_pool
from app.database.templates import get_template_registry, SQLTemplateType
from app.logger import get_logger

logger = get_logger("db_manager")


class DatabaseManager:
    """数据库管理器"""

    def __init__(self, pool: DatabasePool):
        self.pool = pool
        self.registry = get_template_registry()

    async def query_by_template(
        self,
        template_name: str,
        params: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        通过预定义模板安全查询
        这是唯一允许的数据库查询入口
        """
        sql, bound_params = self.registry.render(template_name, params)

        logger.info(
            "template_query",
            template=template_name,
            pool=self.pool.config.name,
            sql_preview=sql[:100],
        )

        rows = await self.pool.fetch(sql, *bound_params)
        return [dict(row) for row in rows]

    async def query_single(
        self,
        template_name: str,
        params: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """单条查询"""
        sql, bound_params = self.registry.render(template_name, params)
        row = await self.pool.fetchrow(sql, *bound_params)
        return dict(row) if row else None

    async def execute_template(
        self,
        template_name: str,
        params: Dict[str, Any]
    ) -> str:
        """通过模板执行写入操作"""
        template = self.registry.get(template_name)
        if template and template.read_only:
            raise ValueError(f"模板 {template_name} 为只读，禁止执行写入操作")

        sql, bound_params = self.registry.render(template_name, params)

        logger.info(
            "template_execute",
            template=template_name,
            pool=self.pool.config.name,
        )

        return await self.pool.execute(sql, *bound_params)

    async def health_check(self) -> bool:
        """健康检查"""
        try:
            result = await self.pool.fetchval("SELECT 1")
            return result == 1
        except Exception as e:
            logger.error("health_check_failed", pool=self.pool.config.name, error=str(e))
            return False


def get_db_manager(pool_name: str) -> DatabaseManager:
    """获取指定连接池的数据库管理器"""
    pool = get_pool(pool_name)
    if not pool:
        raise ValueError(f"连接池不存在: {pool_name}")
    return DatabaseManager(pool)
