"""
FastAPI 主入口
生产级应用启动配置
"""
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from app.config import settings
from app.logger import configure_logging, get_logger
from app.api.routes import router, init_tools
from app.database.pool import get_pool_manager
from app.core.memory import get_memory_manager
from app.core.llm import get_llm

logger = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动
    configure_logging()
    logger.info("app_starting", version=settings.app_version, debug=settings.debug)

    # 初始化数据库连接池
    pool_mgr = await get_pool_manager()
    await pool_mgr.initialize_all()
    logger.info("db_pools_initialized", pools=pool_mgr.list_pools())

    # 初始化Redis
    memory = await get_memory_manager()
    await memory.connect()

    # 初始化LLM
    get_llm()

    # 初始化工具
    init_tools()

    logger.info("app_started", name=settings.app_name)
    yield

    # 关闭
    logger.info("app_shutting_down")
    await pool_mgr.close_all()
    await memory.disconnect()
    logger.info("app_shutdown_complete")


# 创建FastAPI应用
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="生产级AI Agent - 支持SSE/WebSocket双通道流式输出",
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None,
    lifespan=lifespan,
)

# CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应限制具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# GZip压缩
app.add_middleware(GZipMiddleware, minimum_size=1000)

# 注册路由
app.include_router(router)


@app.get("/")
async def root():
    """根路径"""
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "docs": "/docs",
        "health": "/api/v1/health",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        workers=settings.workers,
        reload=settings.debug,
        log_level=settings.log_level.lower(),
    )
