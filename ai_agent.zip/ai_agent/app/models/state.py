"""
LangGraph State定义 (LangGraph 1.x)
使用TypedDict定义状态结构
"""
from typing import TypedDict, Annotated, List, Dict, Any, Optional
from typing_extensions import NotRequired
import operator
from app.models.schemas import IntentResult, ToolCall, ToolResult, ChatMessage


# 自定义reducer：列表追加
def reduce_list(left: List[Any], right: List[Any]) -> List[Any]:
    if left is None:
        left = []
    if right is None:
        right = []
    return left + right


def reduce_messages(left: List[ChatMessage], right: List[ChatMessage]) -> List[ChatMessage]:
    if left is None:
        left = []
    if right is None:
        right = []
    return left + right


class AgentState(TypedDict):
    """
    Agent状态图状态定义
    所有节点共享此状态，通过reducer控制状态更新行为
    """
    # === 会话标识 ===
    session_id: str

    # === 输入输出 ===
    user_input: str
    final_response: NotRequired[str]

    # === 对话历史 ===
    messages: Annotated[List[ChatMessage], reduce_messages]

    # === 意图识别 ===
    intent_result: NotRequired[IntentResult]

    # === 工具相关 ===
    tool_calls: Annotated[List[ToolCall], reduce_list]
    tool_results: Annotated[List[ToolResult], reduce_list]
    selected_tools: NotRequired[List[str]]

    # === 安全控制 ===
    iteration_count: int
    tool_call_count: int
    should_stop: bool
    stop_reason: NotRequired[str]

    # === 错误处理 ===
    error: NotRequired[str]

    # === 上下文传递 ===
    context: NotRequired[Dict[str, Any]]

    # === 流式控制 ===
    stream_queue: NotRequired[Any]  # 运行时注入，不参与序列化

    # === 记忆 ===
    memory_summary: NotRequired[str]

    # === 数据库路由 ===
    db_route_tag: NotRequired[str]
