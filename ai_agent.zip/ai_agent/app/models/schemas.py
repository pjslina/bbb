"""
Pydantic Schema定义
所有API输入输出模型
"""
from typing import List, Dict, Any, Optional, Literal
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


class MessageRole(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class ChatMessage(BaseModel):
    """对话消息"""
    role: MessageRole
    content: str
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class IntentType(str, Enum):
    """意图类型"""
    GENERAL = "general"
    DATABASE_QUERY = "database_query"
    API_CALL = "api_call"
    DATA_ANALYSIS = "data_analysis"
    UNKNOWN = "unknown"


class IntentResult(BaseModel):
    """意图识别结果"""
    intent: IntentType
    confidence: float = Field(..., ge=0.0, le=1.0)
    entities: Dict[str, Any] = Field(default_factory=dict)
    reason: str = ""


class ToolCall(BaseModel):
    """工具调用定义"""
    tool_name: str
    tool_input: Dict[str, Any] = Field(default_factory=dict)
    tool_call_id: str = Field(default_factory=lambda: f"call_{datetime.utcnow().timestamp()}")


class ToolResult(BaseModel):
    """工具执行结果"""
    tool_name: str
    tool_call_id: str
    success: bool
    result: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0


class AgentStateSnapshot(BaseModel):
    """Agent状态快照"""
    session_id: str
    current_node: str
    intent: Optional[IntentType] = None
    tool_calls: List[ToolCall] = Field(default_factory=list)
    tool_results: List[ToolResult] = Field(default_factory=list)
    iteration_count: int = 0
    tool_call_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ChatRequest(BaseModel):
    """聊天请求"""
    session_id: str = Field(..., min_length=1, max_length=64)
    message: str = Field(..., min_length=1, max_length=10000)
    context: Dict[str, Any] = Field(default_factory=dict)
    stream: bool = True
    # 动态路由标签
    db_route_tag: Optional[str] = None


class ChatResponseChunk(BaseModel):
    """流式响应块"""
    type: Literal["text", "tool_call", "tool_result", "state", "error", "done"] = "text"
    content: str = ""
    data: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ChatResponse(BaseModel):
    """完整响应"""
    session_id: str
    response: str
    tool_calls: List[ToolResult] = Field(default_factory=list)
    state: AgentStateSnapshot
    usage: Dict[str, int] = Field(default_factory=dict)


class SessionSummary(BaseModel):
    """会话摘要"""
    session_id: str
    summary: str
    key_points: List[str] = Field(default_factory=list)
    message_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
