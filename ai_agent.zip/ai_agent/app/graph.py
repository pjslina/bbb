"""
LangGraph StateGraph 构建
版本: LangGraph 1.x
架构: start -> 意图识别 -> 工具决策 -> [工具执行 or LLM回答] -> 记忆更新 -> end
"""
from typing import Literal
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from app.models.state import AgentState
from app.nodes.intent_recognition import intent_recognition_node
from app.nodes.tool_decision import tool_decision_node
from app.nodes.tool_execution import tool_execution_node
from app.nodes.llm_answer import llm_answer_node
from app.nodes.memory_update import memory_update_node
from app.nodes.safety_guard import safety_guard_node
from app.nodes.stream_manager import get_stream_manager
from app.logger import get_logger

logger = get_logger("graph")


# === 条件路由函数 ===
def route_after_intent(state: AgentState) -> Literal["tool_decision", "llm_answer"]:
    """
    意图识别后的路由
    - database_query / api_call / data_analysis -> 工具决策
    - general / unknown -> 直接LLM回答
    """
    from app.models.schemas import IntentType

    intent_result = state.get("intent_result")
    if not intent_result:
        return "llm_answer"

    intent = intent_result.intent

    if intent in [IntentType.DATABASE_QUERY, IntentType.API_CALL, IntentType.DATA_ANALYSIS]:
        logger.info("route_to_tool_decision", intent=intent.value)
        return "tool_decision"

    logger.info("route_to_llm_answer", intent=intent.value)
    return "llm_answer"


def route_after_tool_decision(state: AgentState) -> Literal["tool_execution", "llm_answer"]:
    """
    工具决策后的路由
    - 有选中工具 -> 工具执行
    - 无工具 -> LLM回答
    """
    selected_tools = state.get("selected_tools", [])
    if selected_tools:
        logger.info("route_to_tool_execution", tools=selected_tools)
        return "tool_execution"

    logger.info("route_to_llm_answer_no_tools")
    return "llm_answer"


def route_after_safety(state: AgentState) -> Literal["intent_recognition", "llm_answer"]:
    """
    安全检查后的路由
    - should_stop=True -> 直接LLM回答（生成停止信息）
    - should_stop=False -> 继续意图识别
    """
    if state.get("should_stop"):
        logger.warning("safety_stop_triggered", reason=state.get("stop_reason", ""))
        return "llm_answer"

    return "intent_recognition"


def route_after_tool_execution(state: AgentState) -> Literal["llm_answer", "tool_decision"]:
    """
    工具执行后的路由
    - 正常 -> LLM回答
    - 需要重试/链式调用 -> 回到工具决策（迭代）
    当前简化：一律到LLM回答
    """
    return "llm_answer"


# === 构建Graph ===
def build_agent_graph() -> StateGraph:
    """构建Agent StateGraph"""

    # 使用MemorySaver作为checkpoint（LangGraph 1.x）
    checkpointer = MemorySaver()

    # 定义图
    workflow = StateGraph(AgentState)

    # === 添加节点 ===
    workflow.add_node("safety_guard", safety_guard_node)
    workflow.add_node("intent_recognition", intent_recognition_node)
    workflow.add_node("tool_decision", tool_decision_node)
    workflow.add_node("tool_execution", tool_execution_node)
    workflow.add_node("llm_answer", llm_answer_node)
    workflow.add_node("memory_update", memory_update_node)

    # === 定义边 ===
    # start -> safety_guard
    workflow.set_entry_point("safety_guard")

    # safety_guard -> intent_recognition / llm_answer
    workflow.add_conditional_edges(
        "safety_guard",
        route_after_safety,
        {
            "intent_recognition": "intent_recognition",
            "llm_answer": "llm_answer",
        }
    )

    # intent_recognition -> tool_decision / llm_answer
    workflow.add_conditional_edges(
        "intent_recognition",
        route_after_intent,
        {
            "tool_decision": "tool_decision",
            "llm_answer": "llm_answer",
        }
    )

    # tool_decision -> tool_execution / llm_answer
    workflow.add_conditional_edges(
        "tool_decision",
        route_after_tool_decision,
        {
            "tool_execution": "tool_execution",
            "llm_answer": "llm_answer",
        }
    )

    # tool_execution -> llm_answer
    workflow.add_conditional_edges(
        "tool_execution",
        route_after_tool_execution,
        {
            "llm_answer": "llm_answer",
            "tool_decision": "tool_decision",
        }
    )

    # llm_answer -> memory_update
    workflow.add_edge("llm_answer", "memory_update")

    # memory_update -> END
    workflow.add_edge("memory_update", END)

    # 编译图（LangGraph 1.x 使用 compile）
    graph = workflow.compile(checkpointer=checkpointer)

    logger.info("agent_graph_compiled", nodes=list(workflow.nodes.keys()))
    return graph


# 全局图实例
_agent_graph = None


def get_agent_graph():
    """获取Agent图实例（懒加载）"""
    global _agent_graph
    if _agent_graph is None:
        _agent_graph = build_agent_graph()
    return _agent_graph
