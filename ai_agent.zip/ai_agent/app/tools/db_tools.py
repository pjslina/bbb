"""
数据库工具实现
通过安全模板执行查询，禁止LLM直接拼SQL
"""
from typing import Dict, Any, Optional
from app.tools.base import BaseTool, ToolSchema
from app.database.pool import get_pool
from app.database.router import DatabaseRouter
from app.database.manager import DatabaseManager
from app.logger import get_logger

logger = get_logger("db_tools")


class DBQueryTool(BaseTool):
    """数据库查询工具（安全模板化）"""

    name = "db_query"
    description = "通过预定义模板安全查询数据库，支持按场景动态路由"

    def get_schema(self) -> ToolSchema:
        return ToolSchema(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "template_name": {
                        "type": "string",
                        "description": "SQL模板名称，如：select_by_id, select_list, select_count"
                    },
                    "params": {
                        "type": "object",
                        "description": "模板参数"
                    },
                    "scenario": {
                        "type": "string",
                        "description": "业务场景，用于动态路由，如：order, user, product, analytics"
                    },
                    "db_tag": {
                        "type": "string",
                        "description": "数据库标签，直接指定路由"
                    },
                },
                "required": ["template_name", "params"],
            }
        )

    async def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        valid, error = self.validate_params(params)
        if not valid:
            return {"success": False, "error": error}

        template_name = params["template_name"]
        query_params = params.get("params", {})
        scenario = params.get("scenario", "default")
        db_tag = params.get("db_tag")

        try:
            # 动态路由
            if db_tag:
                pool = DatabaseRouter.route_by_tag(db_tag)
            else:
                pool = DatabaseRouter.route_by_scenario(scenario)

            if not pool:
                return {"success": False, "error": "未找到可用的数据库连接池"}

            manager = DatabaseManager(pool)

            # 安全模板查询
            result = await manager.query_by_template(template_name, query_params)

            logger.info(
                "db_query_success",
                template=template_name,
                scenario=scenario,
                pool=pool.config.name,
                row_count=len(result),
            )

            return {
                "success": True,
                "result": result,
                "pool": pool.config.name,
                "row_count": len(result),
            }
        except Exception as e:
            logger.error("db_query_error", template=template_name, error=str(e))
            return {"success": False, "error": str(e)}


class DBAggregateTool(BaseTool):
    """数据库聚合查询工具"""

    name = "db_aggregate"
    description = "执行聚合查询（SUM/AVG/COUNT/MAX/MIN）"

    def get_schema(self) -> ToolSchema:
        return ToolSchema(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "table": {
                        "type": "string",
                        "description": "表名"
                    },
                    "agg_func": {
                        "type": "string",
                        "enum": ["SUM", "AVG", "COUNT", "MAX", "MIN"],
                        "description": "聚合函数"
                    },
                    "agg_column": {
                        "type": "string",
                        "description": "聚合字段"
                    },
                    "conditions": {
                        "type": "string",
                        "description": "条件（已预校验）"
                    },
                    "scenario": {
                        "type": "string",
                        "description": "业务场景"
                    },
                },
                "required": ["table", "agg_func", "agg_column"],
            }
        )

    async def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        valid, error = self.validate_params(params)
        if not valid:
            return {"success": False, "error": error}

        scenario = params.get("scenario", "default")

        try:
            pool = DatabaseRouter.route_by_scenario(scenario)
            if not pool:
                return {"success": False, "error": "未找到可用的数据库连接池"}

            manager = DatabaseManager(pool)
            result = await manager.query_by_template("select_aggregate", params)

            return {
                "success": True,
                "result": result,
                "pool": pool.config.name,
            }
        except Exception as e:
            logger.error("db_aggregate_error", error=str(e))
            return {"success": False, "error": str(e)}
