"""
工具路由器
支持多个工具自动选择，可插拔架构
"""
import json
from typing import Dict, Any, List, Optional
from app.tools.base import BaseTool
from app.tools.registry import get_registry
from app.core.llm import get_llm
from app.logger import get_logger

logger = get_logger("tool_router")


class ToolRouter:
    """工具路由器"""

    def __init__(self):
        self.registry = get_registry()
        self.llm = get_llm()

    async def route(self, user_input: str, intent: str, context: Dict[str, Any] = None) -> List[str]:
        """
        根据用户输入和意图，自动选择需要调用的工具
        返回工具名称列表
        """
        tools = self.registry.get_all_schemas()
        if not tools:
            logger.warning("no_tools_registered")
            return []

        # 构建工具选择Prompt
        tool_descriptions = []
        for tool in tools:
            func = tool["function"]
            tool_descriptions.append(
                f"- {func['name']}: {func['description']}"
            )

        prompt = f"""你是一个工具选择助手。根据用户输入和意图，判断需要调用哪些工具。

可用工具：
{"\n".join(tool_descriptions)}

用户输入：{user_input}
识别意图：{intent}

请分析用户需求，选择最相关的工具。如果没有合适的工具，返回空列表。
只返回JSON格式：{{"tools": ["tool_name1", "tool_name2"]}}"""

        try:
            result = await self.llm.chat([
                {"role": "system", "content": "你是一个工具选择助手，只输出JSON格式。"},
                {"role": "user", "content": prompt}
            ], temperature=0.1, max_tokens=200)

            content = result["content"].strip()
            # 提取JSON
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            data = json.loads(content.strip())
            selected = data.get("tools", [])

            # 校验工具存在性
            valid_tools = []
            for t in selected:
                if self.registry.get(t):
                    valid_tools.append(t)
                else:
                    logger.warning("tool_not_found", tool=t)

            logger.info("tools_selected", intent=intent, tools=valid_tools)
            return valid_tools
        except Exception as e:
            logger.error("tool_route_error", error=str(e))
            return []

    async def execute_tools(self, tool_calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """批量执行工具"""
        results = []
        for call in tool_calls:
            tool_name = call.get("name")
            params = call.get("arguments", {})

            tool = self.registry.get(tool_name)
            if not tool:
                results.append({
                    "tool_name": tool_name,
                    "success": False,
                    "error": f"工具不存在: {tool_name}"
                })
                continue

            try:
                result = await tool.execute(params)
                results.append({
                    "tool_name": tool_name,
                    **result
                })
            except Exception as e:
                logger.error("tool_execute_error", tool=tool_name, error=str(e))
                results.append({
                    "tool_name": tool_name,
                    "success": False,
                    "error": str(e)
                })

        return results

    def get_tool_schemas_for_llm(self) -> List[Dict[str, Any]]:
        """获取所有工具的LLM格式Schema"""
        return self.registry.get_all_schemas()


# 全局路由器
_tool_router = ToolRouter()


def get_tool_router() -> ToolRouter:
    return _tool_router
