"""
工具注册表
支持动态注册、发现、加载工具
"""
from typing import Dict, List, Type, Optional
from app.tools.base import BaseTool, ToolSchema
from app.logger import get_logger

logger = get_logger("tool_registry")


class ToolRegistry:
    """工具注册表"""

    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}
        self._schemas: Dict[str, ToolSchema] = {}

    def register(self, tool: BaseTool):
        """注册工具"""
        if not tool.name:
            raise ValueError("工具名称不能为空")

        self._tools[tool.name] = tool
        self._schemas[tool.name] = tool.get_schema()
        logger.info("tool_registered", name=tool.name, description=tool.description)

    def unregister(self, name: str):
        """注销工具"""
        if name in self._tools:
            del self._tools[name]
            del self._schemas[name]
            logger.info("tool_unregistered", name=name)

    def get(self, name: str) -> Optional[BaseTool]:
        """获取工具实例"""
        return self._tools.get(name)

    def get_schema(self, name: str) -> Optional[ToolSchema]:
        """获取工具Schema"""
        return self._schemas.get(name)

    def list_tools(self) -> List[str]:
        """列出所有工具名"""
        return list(self._tools.keys())

    def get_all_schemas(self) -> List[Dict[str, Any]]:
        """获取所有工具的OpenAI格式Schema"""
        return [schema.to_openai_format() for schema in self._schemas.values()]

    def get_all_tools(self) -> Dict[str, BaseTool]:
        """获取所有工具"""
        return self._tools.copy()


# 全局注册表
_registry = ToolRegistry()


def get_registry() -> ToolRegistry:
    return _registry


def register_tool(tool: BaseTool):
    """快捷注册"""
    _registry.register(tool)


def get_tool(name: str) -> Optional[BaseTool]:
    """快捷获取"""
    return _registry.get(name)
