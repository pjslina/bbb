"""
API工具实现
支持HTTP GET/POST调用，可插拔
"""
import httpx
import asyncio
from typing import Dict, Any, Optional
from app.tools.base import BaseTool, ToolSchema
from app.logger import get_logger

logger = get_logger("api_tools")


class APICallTool(BaseTool):
    """通用API调用工具"""

    name = "api_call"
    description = "调用外部HTTP API，支持GET/POST/PUT/DELETE"

    def __init__(self, timeout: float = 30.0):
        super().__init__()
        self.timeout = timeout
        self.client = httpx.AsyncClient(timeout=timeout)

    def get_schema(self) -> ToolSchema:
        return ToolSchema(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "API地址"
                    },
                    "method": {
                        "type": "string",
                        "enum": ["GET", "POST", "PUT", "DELETE"],
                        "description": "HTTP方法"
                    },
                    "headers": {
                        "type": "object",
                        "description": "请求头"
                    },
                    "params": {
                        "type": "object",
                        "description": "URL参数"
                    },
                    "body": {
                        "type": "object",
                        "description": "请求体（POST/PUT）"
                    },
                },
                "required": ["url", "method"],
            }
        )

    async def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """执行API调用"""
        valid, error = self.validate_params(params)
        if not valid:
            return {"success": False, "error": error}

        url = params["url"]
        method = params["method"].upper()
        headers = params.get("headers", {})
        query_params = params.get("params", {})
        body = params.get("body", {})

        try:
            start = asyncio.get_event_loop().time()

            if method == "GET":
                response = await self.client.get(url, headers=headers, params=query_params)
            elif method == "POST":
                response = await self.client.post(url, headers=headers, json=body, params=query_params)
            elif method == "PUT":
                response = await self.client.put(url, headers=headers, json=body, params=query_params)
            elif method == "DELETE":
                response = await self.client.delete(url, headers=headers, params=query_params)
            else:
                return {"success": False, "error": f"不支持的HTTP方法: {method}"}

            elapsed = (asyncio.get_event_loop().time() - start) * 1000

            # 解析响应
            try:
                result = response.json()
            except:
                result = {"text": response.text, "status_code": response.status_code}

            logger.info(
                "api_call_success",
                url=url,
                method=method,
                status=response.status_code,
                elapsed_ms=round(elapsed, 2),
            )

            return {
                "success": 200 <= response.status_code < 300,
                "result": result,
                "status_code": response.status_code,
                "elapsed_ms": round(elapsed, 2),
            }
        except httpx.TimeoutException:
            logger.error("api_call_timeout", url=url, method=method)
            return {"success": False, "error": "API调用超时"}
        except Exception as e:
            logger.error("api_call_error", url=url, method=method, error=str(e))
            return {"success": False, "error": str(e)}

    async def close(self):
        await self.client.aclose()


class WeatherTool(BaseTool):
    """天气查询工具（示例）"""

    name = "weather_query"
    description = "查询指定城市的天气信息"

    def __init__(self):
        super().__init__()
        self.client = httpx.AsyncClient(timeout=10.0)

    def get_schema(self) -> ToolSchema:
        return ToolSchema(
            name=self.name,
            description=self.description,
            parameters={
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "城市名称，如：北京、上海"
                    },
                },
                "required": ["city"],
            }
        )

    async def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        valid, error = self.validate_params(params)
        if not valid:
            return {"success": False, "error": error}

        city = params["city"]
        # 这里接入真实天气API
        return {
            "success": True,
            "result": {
                "city": city,
                "temperature": "25°C",
                "weather": "晴",
                "humidity": "60%",
                "note": "此为示例数据，请接入真实天气API"
            }
        }
