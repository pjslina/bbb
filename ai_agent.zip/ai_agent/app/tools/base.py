"""
工具基类与接口定义
所有工具必须继承BaseTool，实现schema和execute方法
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field
from dataclasses import dataclass
from datetime import datetime
from app.logger import get_logger

logger = get_logger("tools")


class ToolParameter(BaseModel):
    """工具参数定义"""
    name: str
    type: str
    description: str
    required: bool = True
    default: Any = None
    enum: Optional[List[Any]] = None


class ToolSchema(BaseModel):
    """工具Schema（OpenAI Function Calling格式）"""
    name: str
    description: str
    parameters: Dict[str, Any] = Field(default_factory=dict)

    def to_openai_format(self) -> Dict[str, Any]:
        """转换为OpenAI tools格式"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            }
        }


class BaseTool(ABC):
    """工具基类"""

    name: str = ""
    description: str = ""

    def __init__(self):
        self.logger = get_logger(f"tool.{self.name}")

    @abstractmethod
    def get_schema(self) -> ToolSchema:
        """返回工具Schema"""
        pass

    @abstractmethod
    async def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行工具
        返回: {"success": bool, "result": Any, "error": str}
        """
        pass

    def validate_params(self, params: Dict[str, Any]) -> tuple:
        """校验参数"""
        schema = self.get_schema()
        required = schema.parameters.get("required", [])
        properties = schema.parameters.get("properties", {})

        missing = [p for p in required if p not in params]
        if missing:
            return False, f"缺少必需参数: {missing}"

        # 类型校验（简化版）
        for key, value in params.items():
            if key in properties:
                expected_type = properties[key].get("type", "string")
                type_map = {
                    "string": str,
                    "integer": int,
                    "number": (int, float),
                    "boolean": bool,
                    "array": list,
                    "object": dict,
                }
                expected = type_map.get(expected_type)
                if expected and not isinstance(value, expected):
                    return False, f"参数 {key} 类型错误，期望 {expected_type}"

        return True, ""


@dataclass
class ToolExecutionResult:
    """工具执行结果"""
    tool_name: str
    success: bool
    result: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    timestamp: datetime = Field(default_factory=datetime.utcnow)
