"""集中配置，通过环境变量或 .env 文件加载。"""
from __future__ import annotations
from functools import lru_cache
from typing import Literal, Optional
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8",
        case_sensitive=False, extra="ignore",
    )

    # App
    app_name: str = "single-agent"
    app_env: Literal["development", "production"] = "development"
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    log_level: str = "INFO"

    # LLM
    llm_provider: Literal["qwen", "glm", "openai"] = "qwen"
    llm_base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    llm_api_key: str = "sk-xxx"
    llm_model: str = "qwen-plus"
    llm_max_tokens: int = 4096
    llm_temperature: float = 0.7
    llm_timeout: int = 60

    # Redis
    redis_url: str = "redis://localhost:6379/0"
    redis_password: Optional[str] = None
    redis_max_connections: int = 20
    session_ttl: int = 86400
    summary_threshold: int = 20

    # PostgreSQL Primary
    pg_primary_dsn: str = "postgresql+asyncpg://user:password@localhost:5432/agentdb"
    pg_primary_pool_size: int = 10
    pg_primary_max_overflow: int = 20

    # PostgreSQL Secondary (analytics replica)
    pg_secondary_dsn: Optional[str] = None
    pg_secondary_pool_size: int = 5

    # OpenGauss
    og_primary_dsn: Optional[str] = None
    og_primary_pool_size: int = 10
    og_secondary_dsn: Optional[str] = None

    # Agent safety
    agent_max_iterations: int = 10
    agent_timeout: int = 120
    agent_max_tool_calls: int = 5

    @field_validator("log_level")
    @classmethod
    def _validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        u = v.upper()
        if u not in allowed:
            raise ValueError(f"log_level must be one of {allowed}")
        return u

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def all_db_dsns(self) -> dict[str, str]:
        dsns: dict[str, str] = {"pg_primary": self.pg_primary_dsn}
        if self.pg_secondary_dsn:
            dsns["pg_secondary"] = self.pg_secondary_dsn
        if self.og_primary_dsn:
            dsns["og_primary"] = self.og_primary_dsn
        if self.og_secondary_dsn:
            dsns["og_secondary"] = self.og_secondary_dsn
        return dsns


@lru_cache(maxsize=1)
def get_settings() -> AppSettings:
    return AppSettings()


settings: AppSettings = get_settings()
