"""Redis会话记忆：多轮对话历史存储 + 摘要压缩。"""
from __future__ import annotations
import json
from typing import Any
import redis.asyncio as aioredis
from langchain_core.messages import (
    AIMessage, BaseMessage, HumanMessage, SystemMessage,
    messages_from_dict, messages_to_dict,
)
from app.core.config import settings
from app.core.exceptions import MemoryError
from app.core.logging import get_logger

logger = get_logger(__name__)

_KEY_MSGS    = "session:{sid}:messages"
_KEY_SUMMARY = "session:{sid}:summary"
_KEY_META    = "session:{sid}:meta"

SUMMARISE_PROMPT = """你是一个对话摘要引擎。
用3-5句话概括以下对话的关键信息、用户意图和已完成的操作。
只输出摘要，不要前缀。

对话：
{conversation}"""


class RedisMemoryStore:
    _instance: "RedisMemoryStore | None" = None

    def __init__(self) -> None:
        self._redis: aioredis.Redis | None = None

    @classmethod
    def get_instance(cls) -> "RedisMemoryStore":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    async def init(self) -> None:
        try:
            pool = aioredis.ConnectionPool.from_url(
                settings.redis_url,
                password=settings.redis_password or None,
                max_connections=settings.redis_max_connections,
                decode_responses=True,
            )
            self._redis = aioredis.Redis(connection_pool=pool)
            await self._redis.ping()
            logger.info("Redis记忆存储已连接")
        except Exception as exc:
            raise MemoryError(f"Redis连接失败: {exc}") from exc

    async def close(self) -> None:
        if self._redis:
            await self._redis.aclose()

    # ── 公共API ──────────────────────────────────────────────────────────────

    async def load_history(self, session_id: str) -> list[BaseMessage]:
        self._ensure()
        messages: list[BaseMessage] = []
        summary = await self._get_summary(session_id)
        if summary:
            messages.append(SystemMessage(content=f"[历史摘要]\n{summary}"))
        raw = await self._redis.get(_KEY_MSGS.format(sid=session_id))  # type: ignore
        if raw:
            try:
                messages.extend(messages_from_dict(json.loads(raw)))
            except Exception as exc:
                logger.warning("历史反序列化失败，重置", session_id=session_id, error=str(exc))
        return messages

    async def append_turn(self, session_id: str, human: HumanMessage, ai: AIMessage) -> None:
        self._ensure()
        existing = await self._load_raw(session_id)
        existing.extend([human, ai])
        await self._save_msgs(session_id, existing)

    async def update_messages(self, session_id: str, messages: list[BaseMessage]) -> None:
        self._ensure()
        filtered = [m for m in messages if not isinstance(m, SystemMessage)]
        await self._save_msgs(session_id, filtered)

    async def set_summary(self, session_id: str, summary: str) -> None:
        self._ensure()
        pipe = self._redis.pipeline()  # type: ignore
        pipe.set(_KEY_SUMMARY.format(sid=session_id), summary)
        pipe.expire(_KEY_SUMMARY.format(sid=session_id), settings.session_ttl)
        await pipe.execute()

    async def get_message_count(self, session_id: str) -> int:
        return len(await self._load_raw(session_id))

    async def session_exists(self, session_id: str) -> bool:
        self._ensure()
        return bool(await self._redis.exists(_KEY_MSGS.format(sid=session_id)))  # type: ignore

    async def delete_session(self, session_id: str) -> None:
        self._ensure()
        await self._redis.delete(  # type: ignore
            _KEY_MSGS.format(sid=session_id),
            _KEY_SUMMARY.format(sid=session_id),
            _KEY_META.format(sid=session_id),
        )

    async def get_meta(self, session_id: str) -> dict[str, Any]:
        self._ensure()
        raw = await self._redis.get(_KEY_META.format(sid=session_id))  # type: ignore
        return json.loads(raw) if raw else {}

    async def set_meta(self, session_id: str, meta: dict[str, Any]) -> None:
        self._ensure()
        pipe = self._redis.pipeline()  # type: ignore
        pipe.set(_KEY_META.format(sid=session_id), json.dumps(meta, ensure_ascii=False))
        pipe.expire(_KEY_META.format(sid=session_id), settings.session_ttl)
        await pipe.execute()

    # ── 内部方法 ─────────────────────────────────────────────────────────────

    async def _load_raw(self, session_id: str) -> list[BaseMessage]:
        raw = await self._redis.get(_KEY_MSGS.format(sid=session_id))  # type: ignore
        if not raw:
            return []
        try:
            return messages_from_dict(json.loads(raw))
        except Exception:
            return []

    async def _save_msgs(self, session_id: str, msgs: list[BaseMessage]) -> None:
        pipe = self._redis.pipeline()  # type: ignore
        pipe.set(_KEY_MSGS.format(sid=session_id),
                 json.dumps(messages_to_dict(msgs), ensure_ascii=False))
        pipe.expire(_KEY_MSGS.format(sid=session_id), settings.session_ttl)
        await pipe.execute()

    async def _get_summary(self, session_id: str) -> str:
        return await self._redis.get(_KEY_SUMMARY.format(sid=session_id)) or ""  # type: ignore

    def _ensure(self) -> None:
        if not self._redis:
            raise MemoryError("RedisMemoryStore 未初始化，请先调用 init()")


async def maybe_compress_session(session_id: str, store: RedisMemoryStore, llm: Any) -> bool:
    """若消息数超过阈值，自动生成摘要并裁剪历史。"""
    count = await store.get_message_count(session_id)
    if count < settings.summary_threshold:
        return False
    messages = await store._load_raw(session_id)
    keep_n = settings.summary_threshold // 2
    to_summarise, to_keep = messages[:-keep_n], messages[-keep_n:]
    lines = []
    for m in to_summarise:
        role = "用户" if isinstance(m, HumanMessage) else "助手"
        lines.append(f"{role}: {m.content}")
    resp = await llm.ainvoke([HumanMessage(
        content=SUMMARISE_PROMPT.format(conversation="\n".join(lines))
    )])
    summary = resp.content if hasattr(resp, "content") else str(resp)
    await store.set_summary(session_id, summary)
    await store.update_messages(session_id, to_keep)
    logger.info("会话已压缩", session_id=session_id, before=count, after=len(to_keep))
    return True


memory_store = RedisMemoryStore.get_instance()
