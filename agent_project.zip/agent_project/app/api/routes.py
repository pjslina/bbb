"""REST API 端点：同步对话、会话管理、健康检查、场景/工具查看。"""
from __future__ import annotations
from fastapi import APIRouter, HTTPException, status, Response
from app.agent.graph import get_runner
from app.api.models import ChatRequest, ChatResponse, HealthResponse, SessionInfoResponse
from app.core.config import settings
from app.core.exceptions import AgentBaseError
from app.core.logging import get_logger
from app.db.pool import db_manager
from app.memory.redis_store import memory_store
from app.scenarios.base import scenario_registry
from app.tools.base import tool_registry

logger = get_logger(__name__)
router = APIRouter()


@router.post("/chat", response_model=ChatResponse, summary="同步对话（非流式）")
async def chat(body: ChatRequest) -> ChatResponse:
    runner = get_runner()
    try:
        answer = await runner.run(
            session_id=body.session_id,
            user_input=body.message,
            user_id=body.user_id,
            extra=body.extra,
        )
    except AgentBaseError as exc:
        logger.error("Agent错误", code=exc.code, msg=exc.message)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"code": exc.code, "message": exc.message},
        )
    return ChatResponse(session_id=body.session_id, message=answer)


@router.post("/chat/debug", summary="调试对话（返回完整工具链路）")
async def chat_debug(body: ChatRequest) -> dict:
    runner = get_runner()
    try:
        return await runner.run_debug(
            session_id=body.session_id,
            user_input=body.message,
            user_id=body.user_id,
        )
    except AgentBaseError as exc:
        raise HTTPException(500, detail={"code": exc.code, "message": exc.message})


@router.get("/session/{session_id}", response_model=SessionInfoResponse)
async def get_session(session_id: str) -> SessionInfoResponse:
    exists = await memory_store.session_exists(session_id)
    if not exists:
        return SessionInfoResponse(session_id=session_id, exists=False)
    count = await memory_store.get_message_count(session_id)
    meta = await memory_store.get_meta(session_id)
    return SessionInfoResponse(session_id=session_id, exists=True, message_count=count, meta=meta)


@router.delete(
    "/session/{session_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,          # 显式指定无体响应类
    summary="Delete session",
)
async def delete_session(session_id: str):
    await memory_store.delete_session(session_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/scenarios", summary="查看已注册场景")
async def list_scenarios() -> dict:
    result = []
    for name in scenario_registry.all_names():
        labels = scenario_registry.all_intent_labels()
        scenario_labels = [l["label"] for l in labels if l["scenario"] == name]
        result.append({"name": name, "intent_labels": scenario_labels})
    return {"scenarios": result, "total": len(result)}


@router.get("/tools", summary="查看已注册工具")
async def list_tools() -> dict:
    return {
        "tools": [
            {"name": name, "description": tool_registry.get(name).description}
            for name in tool_registry.names()
        ],
        "total": len(tool_registry.names()),
    }


@router.get("/health", response_model=HealthResponse, summary="健康检查")
async def health_check() -> HealthResponse:
    redis_status = "unknown"
    try:
        await memory_store._redis.ping()  # type: ignore
        redis_status = "up"
    except Exception:
        redis_status = "down"

    db_health = db_manager.health()
    overall = "ok"
    if redis_status == "down":
        overall = "degraded"

    return HealthResponse(
        status=overall,
        service=settings.app_name,
        env=settings.app_env,
        databases=db_health,
        redis=redis_status,
        scenarios=scenario_registry.all_names(),
        tools=tool_registry.names(),
    )
