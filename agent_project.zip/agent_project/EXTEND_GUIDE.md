# 工具扩展与条件链路指南

## 你的问题：原代码如何支持「查天气→晴天→查酒店」？

### 原代码的问题

原 `HttpApiTool` 只是一个通用骨架：
```python
# ❌ 原代码：通用HTTP工具，LLM根本不知道"天气"和"酒店"是什么
class HttpApiTool(BaseTool):
    async def execute(self, url, method="GET", ...):
        ...
```

LLM 不知道有"查天气"和"查酒店"两个具体能力，
也没有"先查天气，再根据结果决定查不查酒店"的循环机制。

### 解决方案：两个核心改进

**改进1：具体业务 Tool**
```
app/tools/weather_tool.py    → WeatherTool (get_weather)
app/tools/hotel_tool.py      → HotelSearchTool (search_hotels)
```

**改进2：tool_executor → tool_router 的条件循环**

原来：
```
tool_executor → llm_answer  （一次性，不循环）
```

改后：
```
tool_executor → tool_router → tool_executor → ... → llm_answer
                ↑                                        |
                └── LLM看到天气结果，决定要不要查酒店 ────┘
```

---

## 调用流程详解（以「北京天气晴，找酒店」为例）

```
用户输入："今天北京的天气怎么样？如果晴天，帮我找一家性价比高的酒店"

① intent_recognition
   → intent = "multi_step_task"
   → slots = {"city": "北京", "condition": "晴天触发酒店搜索"}

② tool_decision
   → should_use_tool = True

③ tool_router（第1次）
   LLM 看到：意图=multi_step_task，已有结果=空
   → 决策：先查天气，调用 get_weather(city="北京")
   → tool_calls = [{"name": "get_weather", "args": {"city": "北京"}}]

④ tool_executor（第1次）
   → 执行 WeatherTool.execute(city="北京")
   → 返回 {"condition":"晴","temperature_celsius":26,"is_outdoor_friendly":true}
   → tool_results = [{"tool":"get_weather","result":"...","status":"success"}]
   → tool_call_count = 1

⑤ route_after_tool_executor
   → tool_call_count(1) < max_tool_calls(5)
   → 路由回 "tool_router"

⑥ tool_router（第2次）
   LLM 看到：意图=multi_step_task，已有结果=【天气:晴,is_outdoor_friendly:true】
   → LLM判断：天气是晴天，用户要求晴天找酒店，继续调用酒店工具
   → 决策：调用 search_hotels(city="北京")
   → tool_calls = [{"name": "search_hotels", "args": {"city":"北京"}}]

⑦ tool_executor（第2次）
   → 执行 HotelSearchTool.execute(city="北京")
   → 返回 {"hotels": [...]}
   → tool_results = [weather_result, hotel_result]
   → tool_call_count = 2

⑧ route_after_tool_executor
   → 路由回 "tool_router"

⑨ tool_router（第3次）
   LLM 看到：意图=multi_step_task，已有结果=【天气+酒店列表】
   → LLM判断：信息已齐全，不需要再调用工具
   → tool_calls = []（空！）

⑩ route_after_tool_router
   → tool_calls 为空 → 路由到 "llm_answer"

⑪ llm_answer
   → 整合天气结果 + 酒店列表，生成自然语言回答
   → "北京今天天气晴朗，26°C，适合出行！为您推荐以下酒店：..."

⑫ memory_update → END
```

### 天气是阴天的分支

```
⑥ tool_router（第2次）
   LLM 看到：已有结果=【天气:阴,is_outdoor_friendly:false】
   → LLM判断：天气不好，用户条件不满足（要求晴天），不需要查酒店
   → tool_calls = []（空！）
   
→ 直接到 llm_answer，回答"北京今天天气阴，不适合出行..."
```

---

## 如何添加新工具

### 步骤1：创建 Tool 文件

```python
# app/tools/flight_tool.py
from app.tools.base import BaseTool

class FlightSearchTool(BaseTool):
    @property
    def name(self) -> str:
        return "search_flights"   # LLM 用这个名字调用你的工具

    @property
    def description(self) -> str:
        return "搜索从出发城市到目的城市的航班"

    def tool_schema(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": "search_flights",
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "departure_city": {"type": "string", "description": "出发城市"},
                        "arrival_city":   {"type": "string", "description": "目的城市"},
                        "date":           {"type": "string", "description": "日期 YYYY-MM-DD"},
                        "class":          {
                            "type": "string",
                            "enum": ["economy", "business"],
                            "default": "economy"
                        },
                    },
                    "required": ["departure_city", "arrival_city", "date"],
                },
            },
        }

    async def execute(self, departure_city, arrival_city, date, **kwargs) -> dict:
        # 调用真实 API 或 mock
        return {
            "flights": [
                {"flight_no": "CA123", "departure": "08:00", "price_cny": 680},
                {"flight_no": "MU456", "departure": "10:30", "price_cny": 520},
            ]
        }
```

### 步骤2：注册工具

```python
# app/tools/builtin_tools.py 的 register_all_tools() 里加一行
from app.tools.flight_tool import FlightSearchTool
tool_registry.register(FlightSearchTool())
```

### 完成！无需改其他代码

LLM 会自动从 `tool_registry.all_schemas()` 获得新工具的描述，
在 `tool_router` 决策时自动考虑是否调用它。

---

## 常见业务场景扩展参考

| 场景 | 需要的 Tool | 条件链路示例 |
|------|------------|------------|
| 查天气 + 找酒店 | WeatherTool, HotelSearchTool | 晴天→找酒店；阴天→直接回答 |
| 查库存 + 下订单 | InventoryTool, OrderTool | 有库存→下单；无库存→提示 |
| 查汇率 + 换算金额 | ExchangeRateTool, CalculatorTool | 先查汇率，再用计算器换算 |
| 搜索商品 + 查价格 | ProductSearchTool, PriceTool | 找到商品→查实时价格 |
| 查机票 + 查酒店 | FlightSearchTool, HotelSearchTool | 并行或串行均可 |
| 查用户 + 查订单 | DatabaseQueryTool(不同template) | 先查用户ID→再查其订单 |

---

## 数据库扩展

添加新的 SQL 查询能力，只需在 `app/db/query.py` 里：

```python
# 1. 在 _SQL_TEMPLATES 里加模板
_SQL_TEMPLATES["get_inventory"] = """
    SELECT product_id, stock_quantity, warehouse_location
    FROM inventory
    WHERE product_id = :product_id
"""

# 2. 在 _TEMPLATE_PARAM_SCHEMA 里加参数定义
_TEMPLATE_PARAM_SCHEMA["get_inventory"] = {"product_id"}

# 无需修改工具代码！DatabaseQueryTool 自动读取新模板
```

---

## 配置必要的环境变量

```bash
# 天气 API（和风天气）
WEATHER_API_KEY=your_qweather_key
WEATHER_API_URL=https://api.qweather.com/v7/weather/now

# 酒店 API（根据供应商配置）
HOTEL_API_KEY=your_hotel_api_key
HOTEL_API_URL=https://api.your-hotel-provider.com/v1/search
```

不配置 API Key 时，工具自动返回 mock 数据，方便本地开发测试。
