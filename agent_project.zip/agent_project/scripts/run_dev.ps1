<#
.SYNOPSIS
    开发服务器启动脚本 (PowerShell)
.DESCRIPTION
    自动加载 .env 文件中的环境变量（支持行尾注释，自动处理 LOG_LEVEL 大小写），
    并使用 uvicorn 启动 FastAPI 应用，支持代码修改后自动重载。
    适用于 PyCharm 的 PowerShell 终端。
.NOTES
    运行方式：
        .\scripts\run_dev.ps1
    如果遇到执行策略限制，先执行：
        Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
#>

$ErrorActionPreference = "Stop"

# 获取脚本所在目录，并切换到项目根目录
$ScriptDir = $PSScriptRoot
Push-Location "$ScriptDir\.."

# ---------- 加载 .env 文件 ----------
if (Test-Path ".env") {
    Write-Host "Loading .env"
    Get-Content ".env" | ForEach-Object {
        $line = $_.Trim()
        # 跳过空行和以 # 开头的注释行
        if (-not $line -or $line.StartsWith('#')) { return }

        # 按第一个 '=' 分割（最多分两部分）
        $splitIndex = $line.IndexOf('=')
        if ($splitIndex -le 0) { return }

        $key   = $line.Substring(0, $splitIndex).Trim()
        $value = $line.Substring($splitIndex + 1).Trim()

        # ---- 去除值里的行尾注释（兼容常见 .env 格式） ----
        if ($value -notmatch '^["'']') {
            if ($value -match '^(.*?)\s+#') {
                $value = $Matches[1].TrimEnd()
            }
        }

        # 去除值两端的引号（双引号或单引号）
        if ($value -match '^"(.*)"$' -or $value -match "^'(.*)'$") {
            $value = $Matches[1]
        }

        # ---- 特殊处理：uvicorn 要求日志级别为小写，此处统一转换 ----
        if ($key -eq 'LOG_LEVEL') {
            $value = $value.ToLower()
        }

        # 设置为当前进程的环境变量
        [System.Environment]::SetEnvironmentVariable($key, $value, 'Process')
    }
}

# ---------- 设置默认值 ----------
if (-not $env:APP_HOST)   { $env:APP_HOST   = "0.0.0.0" }
if (-not $env:APP_PORT)   { $env:APP_PORT   = "8000" }
if (-not $env:LOG_LEVEL)  { $env:LOG_LEVEL  = "info" }

Write-Host "Starting agent service (development mode)..."

# ---------- 启动 uvicorn ----------
uvicorn app.main:app `
    --host $env:APP_HOST `
    --port $env:APP_PORT `
    --reload `
    --reload-dir app `
    --log-level $env:LOG_LEVEL `
    --workers 1

Pop-Location